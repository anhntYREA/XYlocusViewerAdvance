﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Shinkawa.Monitoring;
using Shinkawa.Monitoring.Formats;

namespace XYZ_LocusViewer
{
    #region Graph definition
    enum WaveformChannel
    {
        WAV_XCMD = 0,       //Channel 1: X command
        WAV_YCMD,           //Channel 2: Y command
        WAV_ZCMD,           //Channel 3: Z command
        WAV_XDEVIATION,     //Channel 4: X Deviation
        WAV_YDEVIATION,     //Channel 5: X Deviation
        WAV_ZDEVIATION,     //Channel 6: X Deviation
        WAV_XVELOCITY,      //Channel 7: X Velocity
        WAV_YVELOCITY,      //Channel 8: Y Velocity
        WAV_ZVELOCITY,      //Channel 9: Z Velocity
        WAV_CH1,            //Channel 10: CH1
        WAV_CH2,            //Channel 11: CH2
        WAV_CH3,            //Channel 12: CH3
        WAV_CH4,            //Channel 13: CH4
        //Define series index for waveforms (measurement)
        WAV_HA,             //Channel 14: Ha
        WAV_HB,             //Channel 15: Hb
        WAV_VA,             //Channel 16: Va
        WAV_VB = 16         //Channel 17: Vb
    };

    enum LocusChannel
    {   //Define series index for locus viewer (XY, XZ, YZ and Radius graph)
        //Because locus viewer graph always have 2 series would be 0 and 1 index, so the measurement will be from 2 index
        LOCUS_CMD = 0,      // Command position
        LOCUS_ENC,          // Encode position
        LOCUS_GEO,          // Geometry position (Radius graph)
        LOCUS_HA,           // Ha
        LOCUS_HB,           // Hb
        LOCUS_VA,           // Va
        LOCUS_VB = 6        // Vb
    };
    enum MeasurementDirection
    {
        HMeasure = 0,           // Horizontal measurement
        VMeasure                // Vertical measurement
    };
    enum MeasurementCursor
    {
        Cursor_0 = 0,        // No1 measurement cursor
        Cursor_1             // No2 measurement cursor
    };

    //Define graph index (Same as Tab index)
    enum GraphID
    {
        XZ = 0,          //XZ
        XY,              //XY
        YZ,              //YZ
        RADIUS,          //Radius
        WAVEFORM = 4     //Waveform
    }
    #endregion

    #region Data structure declaration
    struct MeasurementLimit
    {
        public double VerticalMax;
        public double VerticalMin;
        public double HorizontalMax;
        public double HorizontalMin;
    }
    struct MonitoringDataRow
    {
        public double Time { get; set; }
        public double Xcmd { get; set; }
        public double Ycmd { get; set; }
        public double Zcmd { get; set; }
        public double Xenc { get; set; }
        public double Yenc { get; set; }
        public double Zenc { get; set; }
        public double CH1 { get; set; }
        public double CH2 { get; set; }
        public double CH3 { get; set; }
        public double CH4 { get; set; }
        public MarkerId MarkerID { get; set; }
        public double SamplingRate { get; set; }
    };
    struct RotateData
    {
        public double ThetaCmd { get; set; }
        public double Rcmd { get; set; }
        public double ThetaEnc { get; set; }
        public double Renc { get; set; }
    }
    struct DeviationData
    {
        public double DeltaX { get; set; }
        public double DeltaY { get; set; }
        public double DeltaZ { get; set; }
    }
    struct VelocityData
    {
        public double Vx { get; set; }
        public double Vy { get; set; }
        public double Vz { get; set; }
    }
    struct GeometryData
    {
        public double ThetaG { get; set; }
        public double Rg { get; set; }
    };
    struct GraphCoordData
    {
        public double XaxisDt;
        public double YaxisDt;
    }

    #endregion
    class GlobalVariable
    {
        public const int NumberOfGraphs = 5;            //5 graphs (XZ, XY, YZ, Radius and Waveform)
        public const int NumberOfChannels = 13;         //13 channels
        public const int NumberOfMeasurements = 4;      //4 series (Ha, Hb, Va, Vb)
        public const int NumberOfLocusSeries = 3;       //2 series (cmd, enc, geo)
        //Define waveforms scale
        public const int XAxisStep = 10;       //10ms
        public const int YAxisStep = 1000;     //1000um

        public const int HighSpeedCameraFrameRateDef = 10000;       //High-speed camera frame rate default value(fps)
        public const double WaveformSamplingRateDef = 100000.0;     //Waveform sampling rate (Hz)
        public const int SecondToMiliSecondCof = 1000;              //Convert from second to milisecond (s -> ms)

        //Define measurement limit for waveform
        public const float WaveformHMax = 500;
        public const float WaveformHMin = 0;
        public const float WaveformVMax = 4000;
        public const float WaveformVMin = -4000;
    }
}
