﻿namespace XYZ_LocusViewer
{
    partial class LocusWaveformsViewerAdvanceForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(LocusWaveformsViewerAdvanceForm));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.MonitoringDtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.videoFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.SaveImgToToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportToCSVFileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.playVideoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.framebyFrameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inputFilePathStatusStrip = new System.Windows.Forms.StatusStrip();
            this.InputPathToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.openFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.saveCSVFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.toolStripOpenMonitoringDt = new System.Windows.Forms.ToolStripButton();
            this.toolStripCsv = new System.Windows.Forms.ToolStripButton();
            this.toolStripExportImg = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonOpenVideo = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonPlayVideo = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonFrameByFrame = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonShowSetting = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonHideSetting = new System.Windows.Forms.ToolStripButton();
            this.toolStripButtonExtractVideo = new System.Windows.Forms.ToolStripButton();
            this.saveImgFileDialog = new System.Windows.Forms.SaveFileDialog();
            this.labelVPositionHint = new System.Windows.Forms.Label();
            this.resetGraphbutton = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.HbUnitLabel = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.VbUnitLabel = new System.Windows.Forms.Label();
            this.HorizontalScaleLabel = new System.Windows.Forms.Label();
            this.HaNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.HbNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.VaNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.VbNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.HdeviationLabel = new System.Windows.Forms.Label();
            this.VdeviationLabel = new System.Windows.Forms.Label();
            this.tableLayoutPanelMeasurement = new System.Windows.Forms.TableLayoutPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.HorizontalScaleNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.HistoryNextButton = new System.Windows.Forms.Button();
            this.HistoryBackButton = new System.Windows.Forms.Button();
            this.HorizontalScaleUnitLabel = new System.Windows.Forms.Label();
            this.HCursorCheckBox = new System.Windows.Forms.CheckBox();
            this.VCursorCheckBox = new System.Windows.Forms.CheckBox();
            this.HDistanceUnitLabel = new System.Windows.Forms.Label();
            this.VDistanceUnitLabel = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.VaUnitLabel = new System.Windows.Forms.Label();
            this.HaUnitLabel = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.WaveformSetGroupbox = new System.Windows.Forms.GroupBox();
            this.tableLayoutPanelLocusSetting = new System.Windows.Forms.TableLayoutPanel();
            this.ZopLabel = new System.Windows.Forms.Label();
            this.ZopNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.HornLengthNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.OHNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.CsAngleNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.ZeNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.GeometryTraceComboBox = new System.Windows.Forms.ComboBox();
            this.hornLengthLabel = new System.Windows.Forms.Label();
            this.OHLabel = new System.Windows.Forms.Label();
            this.CsAngleLabel = new System.Windows.Forms.Label();
            this.ZeLabel = new System.Windows.Forms.Label();
            this.Geometrylabel = new System.Windows.Forms.Label();
            this.StartPackageIDLabel = new System.Windows.Forms.Label();
            this.StartPacketIDcomboBox = new System.Windows.Forms.ComboBox();
            this.EndPackageIDLabel = new System.Windows.Forms.Label();
            this.labelGraphLimit = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.numericUpDownHLimit = new System.Windows.Forms.NumericUpDown();
            this.HDetailGraphLabel = new System.Windows.Forms.Label();
            this.VDetailGraphLabel = new System.Windows.Forms.Label();
            this.numericUpDownVLimit = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownVDistance = new System.Windows.Forms.NumericUpDown();
            this.labelGraphPosition2 = new System.Windows.Forms.Label();
            this.labelGraphLimit2 = new System.Windows.Forms.Label();
            this.labelGraphPosition = new System.Windows.Forms.Label();
            this.labelHPositionHint = new System.Windows.Forms.Label();
            this.labelDetailSettingNote = new System.Windows.Forms.Label();
            this.numericUpDownHDistance = new System.Windows.Forms.NumericUpDown();
            this.labelDetailGraphSetting = new System.Windows.Forms.Label();
            this.EndPacketIDcomboBox = new System.Windows.Forms.ComboBox();
            this.comboBoxDetailGraphSetting = new System.Windows.Forms.ComboBox();
            this.tableLayoutPanelWaveformSetting = new System.Windows.Forms.TableLayoutPanel();
            this.ChannelLabel = new System.Windows.Forms.Label();
            this.XcmdCheckBox = new System.Windows.Forms.CheckBox();
            this.YcmdCheckBox = new System.Windows.Forms.CheckBox();
            this.ZcmdCheckBox = new System.Windows.Forms.CheckBox();
            this.ColorLabel = new System.Windows.Forms.Label();
            this.VScaleLabel = new System.Windows.Forms.Label();
            this.PosLabel = new System.Windows.Forms.Label();
            this.XcmdPosNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.YcmdPosNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.ZcmdPosNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.XdeviationPosNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.YdeviationPosNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.ZdeviationPosNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.VxPosNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.VyPosNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.VzPosNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.Ch1PosNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.Ch2PosNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.Ch3PosNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.Ch4PosNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.XcmdScalenumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.YcmdScalenumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.ZcmdScalenumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.XdeviationScalenumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.YdeviationScalenumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.ZdeviationScalenumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.VxScalenumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.VyScalenumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.VzScalenumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.Ch1ScalenumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.Ch2ScalenumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.Ch3ScalenumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.Ch4ScalenumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.XcmdColorButton = new System.Windows.Forms.Button();
            this.YcmdColorButton = new System.Windows.Forms.Button();
            this.ZcmdColorButton = new System.Windows.Forms.Button();
            this.XdeviationColorButton = new System.Windows.Forms.Button();
            this.VxColorButton = new System.Windows.Forms.Button();
            this.VyColorButton = new System.Windows.Forms.Button();
            this.VzColorButton = new System.Windows.Forms.Button();
            this.Ch1ColorButton = new System.Windows.Forms.Button();
            this.Ch2ColorButton = new System.Windows.Forms.Button();
            this.Ch3ColorButton = new System.Windows.Forms.Button();
            this.Ch4ColorButton = new System.Windows.Forms.Button();
            this.XdeviationCheckBox = new System.Windows.Forms.CheckBox();
            this.YdeviationCheckBox = new System.Windows.Forms.CheckBox();
            this.ZdeviationCheckBox = new System.Windows.Forms.CheckBox();
            this.VxCheckBox = new System.Windows.Forms.CheckBox();
            this.VyCheckBox = new System.Windows.Forms.CheckBox();
            this.VzCheckBox = new System.Windows.Forms.CheckBox();
            this.Ch1CheckBox = new System.Windows.Forms.CheckBox();
            this.Ch2CheckBox = new System.Windows.Forms.CheckBox();
            this.Ch3CheckBox = new System.Windows.Forms.CheckBox();
            this.Ch4CheckBox = new System.Windows.Forms.CheckBox();
            this.YdeviationColorButton = new System.Windows.Forms.Button();
            this.ZdeviationColorButton = new System.Windows.Forms.Button();
            this.groupBoxMeasurement = new System.Windows.Forms.GroupBox();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.VideoFileToolStripStatusLabel = new System.Windows.Forms.ToolStripStatusLabel();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.videoOpenFileDialog = new System.Windows.Forms.OpenFileDialog();
            this.LocusTableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.LocusTabControl = new System.Windows.Forms.TabControl();
            this.XZtabPage = new System.Windows.Forms.TabPage();
            this.XZplotView = new OxyPlot.WindowsForms.PlotView();
            this.XYtabPage = new System.Windows.Forms.TabPage();
            this.XYplotView = new OxyPlot.WindowsForms.PlotView();
            this.YZtabPage = new System.Windows.Forms.TabPage();
            this.YZplotView = new OxyPlot.WindowsForms.PlotView();
            this.RadiustabPage = new System.Windows.Forms.TabPage();
            this.RadiusplotView = new OxyPlot.WindowsForms.PlotView();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.waveformsPlotView = new OxyPlot.WindowsForms.PlotView();
            this.labelOperatingProgress = new System.Windows.Forms.Label();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.tableLayoutPanelVideo = new System.Windows.Forms.TableLayoutPanel();
            this.VideoPlayerControl = new AxWMPLib.AxWindowsMediaPlayer();
            this.labelTotalFrameVideo = new System.Windows.Forms.Label();
            this.labelCameraFrameRate = new System.Windows.Forms.Label();
            this.labelVideoPlayerFrameRate = new System.Windows.Forms.Label();
            this.labelCurrentFrameVideo = new System.Windows.Forms.Label();
            this.tableLayoutPanelPictureBox = new System.Windows.Forms.TableLayoutPanel();
            this.pictureBoxFrameByFrame = new System.Windows.Forms.PictureBox();
            this.trackBarPictureBox = new System.Windows.Forms.TrackBar();
            this.labelCurrentFramePicturebox = new System.Windows.Forms.Label();
            this.labelTotalFramePicturebox = new System.Windows.Forms.Label();
            this.menuStrip1.SuspendLayout();
            this.inputFilePathStatusStrip.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HaNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HbNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.VaNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.VbNumericUpDown)).BeginInit();
            this.tableLayoutPanelMeasurement.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HorizontalScaleNumericUpDown)).BeginInit();
            this.WaveformSetGroupbox.SuspendLayout();
            this.tableLayoutPanelLocusSetting.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ZopNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.HornLengthNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OHNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.CsAngleNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ZeNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHLimit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownVLimit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownVDistance)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHDistance)).BeginInit();
            this.tableLayoutPanelWaveformSetting.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.XcmdPosNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YcmdPosNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ZcmdPosNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.XdeviationPosNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YdeviationPosNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ZdeviationPosNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.VxPosNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.VyPosNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.VzPosNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch1PosNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch2PosNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch3PosNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch4PosNumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.XcmdScalenumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YcmdScalenumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ZcmdScalenumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.XdeviationScalenumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.YdeviationScalenumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ZdeviationScalenumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.VxScalenumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.VyScalenumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.VzScalenumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch1ScalenumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch2ScalenumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch3ScalenumericUpDown)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch4ScalenumericUpDown)).BeginInit();
            this.groupBoxMeasurement.SuspendLayout();
            this.statusStrip1.SuspendLayout();
            this.LocusTableLayoutPanel.SuspendLayout();
            this.LocusTabControl.SuspendLayout();
            this.XZtabPage.SuspendLayout();
            this.XYtabPage.SuspendLayout();
            this.YZtabPage.SuspendLayout();
            this.RadiustabPage.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tableLayoutPanelVideo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.VideoPlayerControl)).BeginInit();
            this.tableLayoutPanelPictureBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxFrameByFrame)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarPictureBox)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.toolToolStripMenuItem,
            this.aboutToolStripMenuItem});
            resources.ApplyResources(this.menuStrip1, "menuStrip1");
            this.menuStrip1.Name = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            resources.ApplyResources(this.fileToolStripMenuItem, "fileToolStripMenuItem");
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.MonitoringDtToolStripMenuItem,
            this.videoFileToolStripMenuItem});
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            resources.ApplyResources(this.openToolStripMenuItem, "openToolStripMenuItem");
            // 
            // MonitoringDtToolStripMenuItem
            // 
            this.MonitoringDtToolStripMenuItem.Name = "MonitoringDtToolStripMenuItem";
            resources.ApplyResources(this.MonitoringDtToolStripMenuItem, "MonitoringDtToolStripMenuItem");
            this.MonitoringDtToolStripMenuItem.Click += new System.EventHandler(this.MonitoringDtToolStripMenuItem_Click);
            // 
            // videoFileToolStripMenuItem
            // 
            this.videoFileToolStripMenuItem.Name = "videoFileToolStripMenuItem";
            resources.ApplyResources(this.videoFileToolStripMenuItem, "videoFileToolStripMenuItem");
            this.videoFileToolStripMenuItem.Click += new System.EventHandler(this.videoFileToolStripMenuItem_Click);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            resources.ApplyResources(this.exitToolStripMenuItem, "exitToolStripMenuItem");
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // toolToolStripMenuItem
            // 
            this.toolToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.SaveImgToToolStripMenuItem,
            this.exportToCSVFileToolStripMenuItem,
            this.playVideoToolStripMenuItem,
            this.framebyFrameToolStripMenuItem});
            this.toolToolStripMenuItem.Name = "toolToolStripMenuItem";
            resources.ApplyResources(this.toolToolStripMenuItem, "toolToolStripMenuItem");
            // 
            // SaveImgToToolStripMenuItem
            // 
            this.SaveImgToToolStripMenuItem.Name = "SaveImgToToolStripMenuItem";
            resources.ApplyResources(this.SaveImgToToolStripMenuItem, "SaveImgToToolStripMenuItem");
            this.SaveImgToToolStripMenuItem.Click += new System.EventHandler(this.SaveImgToToolStripMenuItem_Click);
            // 
            // exportToCSVFileToolStripMenuItem
            // 
            this.exportToCSVFileToolStripMenuItem.Name = "exportToCSVFileToolStripMenuItem";
            resources.ApplyResources(this.exportToCSVFileToolStripMenuItem, "exportToCSVFileToolStripMenuItem");
            this.exportToCSVFileToolStripMenuItem.Click += new System.EventHandler(this.exportToCSVFileToolStripMenuItem_Click);
            // 
            // playVideoToolStripMenuItem
            // 
            this.playVideoToolStripMenuItem.Name = "playVideoToolStripMenuItem";
            resources.ApplyResources(this.playVideoToolStripMenuItem, "playVideoToolStripMenuItem");
            this.playVideoToolStripMenuItem.Click += new System.EventHandler(this.playVideoToolStripMenuItem_Click);
            // 
            // framebyFrameToolStripMenuItem
            // 
            this.framebyFrameToolStripMenuItem.Name = "framebyFrameToolStripMenuItem";
            resources.ApplyResources(this.framebyFrameToolStripMenuItem, "framebyFrameToolStripMenuItem");
            this.framebyFrameToolStripMenuItem.Click += new System.EventHandler(this.framebyFrameToolStripMenuItem_Click);
            // 
            // aboutToolStripMenuItem
            // 
            this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
            resources.ApplyResources(this.aboutToolStripMenuItem, "aboutToolStripMenuItem");
            this.aboutToolStripMenuItem.Click += new System.EventHandler(this.aboutToolStripMenuItem_Click);
            // 
            // inputFilePathStatusStrip
            // 
            this.inputFilePathStatusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.InputPathToolStripStatusLabel});
            resources.ApplyResources(this.inputFilePathStatusStrip, "inputFilePathStatusStrip");
            this.inputFilePathStatusStrip.Name = "inputFilePathStatusStrip";
            // 
            // InputPathToolStripStatusLabel
            // 
            this.InputPathToolStripStatusLabel.Name = "InputPathToolStripStatusLabel";
            resources.ApplyResources(this.InputPathToolStripStatusLabel, "InputPathToolStripStatusLabel");
            // 
            // openFileDialog
            // 
            resources.ApplyResources(this.openFileDialog, "openFileDialog");
            // 
            // saveCSVFileDialog
            // 
            resources.ApplyResources(this.saveCSVFileDialog, "saveCSVFileDialog");
            // 
            // toolStrip1
            // 
            this.toolStrip1.ImageScalingSize = new System.Drawing.Size(50, 50);
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripOpenMonitoringDt,
            this.toolStripCsv,
            this.toolStripExportImg,
            this.toolStripButtonOpenVideo,
            this.toolStripButtonPlayVideo,
            this.toolStripButtonFrameByFrame,
            this.toolStripButtonShowSetting,
            this.toolStripButtonHideSetting,
            this.toolStripButtonExtractVideo});
            resources.ApplyResources(this.toolStrip1, "toolStrip1");
            this.toolStrip1.Name = "toolStrip1";
            // 
            // toolStripOpenMonitoringDt
            // 
            this.toolStripOpenMonitoringDt.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.toolStripOpenMonitoringDt, "toolStripOpenMonitoringDt");
            this.toolStripOpenMonitoringDt.Name = "toolStripOpenMonitoringDt";
            this.toolStripOpenMonitoringDt.Click += new System.EventHandler(this.toolStripOpen_Click);
            // 
            // toolStripCsv
            // 
            this.toolStripCsv.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.toolStripCsv, "toolStripCsv");
            this.toolStripCsv.Name = "toolStripCsv";
            this.toolStripCsv.Click += new System.EventHandler(this.toolStripCsv_Click);
            // 
            // toolStripExportImg
            // 
            this.toolStripExportImg.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.toolStripExportImg, "toolStripExportImg");
            this.toolStripExportImg.Name = "toolStripExportImg";
            this.toolStripExportImg.Click += new System.EventHandler(this.toolStripExportImg_Click);
            // 
            // toolStripButtonOpenVideo
            // 
            this.toolStripButtonOpenVideo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.toolStripButtonOpenVideo, "toolStripButtonOpenVideo");
            this.toolStripButtonOpenVideo.Name = "toolStripButtonOpenVideo";
            this.toolStripButtonOpenVideo.Click += new System.EventHandler(this.toolStripButtonOpenVideo_Click);
            // 
            // toolStripButtonPlayVideo
            // 
            this.toolStripButtonPlayVideo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.toolStripButtonPlayVideo, "toolStripButtonPlayVideo");
            this.toolStripButtonPlayVideo.Name = "toolStripButtonPlayVideo";
            this.toolStripButtonPlayVideo.Click += new System.EventHandler(this.toolStripButtonPlayVideo_Click);
            // 
            // toolStripButtonFrameByFrame
            // 
            this.toolStripButtonFrameByFrame.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.toolStripButtonFrameByFrame, "toolStripButtonFrameByFrame");
            this.toolStripButtonFrameByFrame.Name = "toolStripButtonFrameByFrame";
            this.toolStripButtonFrameByFrame.Click += new System.EventHandler(this.frameByFrameToolStripButton_Click);
            // 
            // toolStripButtonShowSetting
            // 
            this.toolStripButtonShowSetting.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.toolStripButtonShowSetting, "toolStripButtonShowSetting");
            this.toolStripButtonShowSetting.Name = "toolStripButtonShowSetting";
            this.toolStripButtonShowSetting.Click += new System.EventHandler(this.ShowToolStripButton_Click);
            // 
            // toolStripButtonHideSetting
            // 
            this.toolStripButtonHideSetting.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.toolStripButtonHideSetting, "toolStripButtonHideSetting");
            this.toolStripButtonHideSetting.Name = "toolStripButtonHideSetting";
            this.toolStripButtonHideSetting.Click += new System.EventHandler(this.HideToolStripButton_Click);
            // 
            // toolStripButtonExtractVideo
            // 
            this.toolStripButtonExtractVideo.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            resources.ApplyResources(this.toolStripButtonExtractVideo, "toolStripButtonExtractVideo");
            this.toolStripButtonExtractVideo.Name = "toolStripButtonExtractVideo";
            this.toolStripButtonExtractVideo.Click += new System.EventHandler(this.toolStripButtonExtractVideo_Click);
            // 
            // saveImgFileDialog
            // 
            resources.ApplyResources(this.saveImgFileDialog, "saveImgFileDialog");
            // 
            // labelVPositionHint
            // 
            resources.ApplyResources(this.labelVPositionHint, "labelVPositionHint");
            this.labelVPositionHint.ForeColor = System.Drawing.Color.Blue;
            this.labelVPositionHint.Name = "labelVPositionHint";
            // 
            // resetGraphbutton
            // 
            resources.ApplyResources(this.resetGraphbutton, "resetGraphbutton");
            this.resetGraphbutton.Name = "resetGraphbutton";
            this.resetGraphbutton.UseVisualStyleBackColor = true;
            this.resetGraphbutton.Click += new System.EventHandler(this.resetGraphbutton_Click);
            // 
            // label7
            // 
            resources.ApplyResources(this.label7, "label7");
            this.label7.Name = "label7";
            // 
            // HbUnitLabel
            // 
            resources.ApplyResources(this.HbUnitLabel, "HbUnitLabel");
            this.HbUnitLabel.Name = "HbUnitLabel";
            // 
            // label9
            // 
            resources.ApplyResources(this.label9, "label9");
            this.label9.Name = "label9";
            // 
            // VbUnitLabel
            // 
            resources.ApplyResources(this.VbUnitLabel, "VbUnitLabel");
            this.VbUnitLabel.Name = "VbUnitLabel";
            // 
            // HorizontalScaleLabel
            // 
            resources.ApplyResources(this.HorizontalScaleLabel, "HorizontalScaleLabel");
            this.HorizontalScaleLabel.Name = "HorizontalScaleLabel";
            // 
            // HaNumericUpDown
            // 
            this.HaNumericUpDown.DecimalPlaces = 2;
            this.HaNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.HaNumericUpDown, "HaNumericUpDown");
            this.HaNumericUpDown.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.HaNumericUpDown.Minimum = new decimal(new int[] {
            500,
            0,
            0,
            -2147483648});
            this.HaNumericUpDown.Name = "HaNumericUpDown";
            this.HaNumericUpDown.ValueChanged += new System.EventHandler(this.HaNumericUpDown_ValueChanged);
            // 
            // HbNumericUpDown
            // 
            this.HbNumericUpDown.DecimalPlaces = 2;
            this.HbNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.HbNumericUpDown, "HbNumericUpDown");
            this.HbNumericUpDown.Maximum = new decimal(new int[] {
            500,
            0,
            0,
            0});
            this.HbNumericUpDown.Minimum = new decimal(new int[] {
            500,
            0,
            0,
            -2147483648});
            this.HbNumericUpDown.Name = "HbNumericUpDown";
            this.HbNumericUpDown.ValueChanged += new System.EventHandler(this.HbNumericUpDown_ValueChanged);
            // 
            // VaNumericUpDown
            // 
            this.VaNumericUpDown.DecimalPlaces = 2;
            this.VaNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.VaNumericUpDown, "VaNumericUpDown");
            this.VaNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.VaNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.VaNumericUpDown.Name = "VaNumericUpDown";
            this.VaNumericUpDown.ValueChanged += new System.EventHandler(this.VaNumericUpDown_ValueChanged);
            // 
            // VbNumericUpDown
            // 
            this.VbNumericUpDown.DecimalPlaces = 2;
            this.VbNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.VbNumericUpDown, "VbNumericUpDown");
            this.VbNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.VbNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.VbNumericUpDown.Name = "VbNumericUpDown";
            this.VbNumericUpDown.ValueChanged += new System.EventHandler(this.VbNumericUpDown_ValueChanged);
            // 
            // label11
            // 
            resources.ApplyResources(this.label11, "label11");
            this.label11.Name = "label11";
            // 
            // label12
            // 
            resources.ApplyResources(this.label12, "label12");
            this.label12.Name = "label12";
            // 
            // HdeviationLabel
            // 
            resources.ApplyResources(this.HdeviationLabel, "HdeviationLabel");
            this.HdeviationLabel.Name = "HdeviationLabel";
            // 
            // VdeviationLabel
            // 
            resources.ApplyResources(this.VdeviationLabel, "VdeviationLabel");
            this.VdeviationLabel.Name = "VdeviationLabel";
            // 
            // tableLayoutPanelMeasurement
            // 
            resources.ApplyResources(this.tableLayoutPanelMeasurement, "tableLayoutPanelMeasurement");
            this.tableLayoutPanelMeasurement.Controls.Add(this.HorizontalScaleLabel, 0, 0);
            this.tableLayoutPanelMeasurement.Controls.Add(this.label1, 0, 1);
            this.tableLayoutPanelMeasurement.Controls.Add(this.HorizontalScaleNumericUpDown, 1, 0);
            this.tableLayoutPanelMeasurement.Controls.Add(this.HistoryNextButton, 2, 1);
            this.tableLayoutPanelMeasurement.Controls.Add(this.resetGraphbutton, 3, 1);
            this.tableLayoutPanelMeasurement.Controls.Add(this.HistoryBackButton, 1, 1);
            this.tableLayoutPanelMeasurement.Controls.Add(this.HorizontalScaleUnitLabel, 2, 0);
            this.tableLayoutPanelMeasurement.Controls.Add(this.HCursorCheckBox, 4, 0);
            this.tableLayoutPanelMeasurement.Controls.Add(this.VCursorCheckBox, 4, 1);
            this.tableLayoutPanelMeasurement.Controls.Add(this.label7, 5, 0);
            this.tableLayoutPanelMeasurement.Controls.Add(this.label9, 5, 1);
            this.tableLayoutPanelMeasurement.Controls.Add(this.HaNumericUpDown, 6, 0);
            this.tableLayoutPanelMeasurement.Controls.Add(this.VaNumericUpDown, 6, 1);
            this.tableLayoutPanelMeasurement.Controls.Add(this.HDistanceUnitLabel, 13, 0);
            this.tableLayoutPanelMeasurement.Controls.Add(this.VDistanceUnitLabel, 13, 1);
            this.tableLayoutPanelMeasurement.Controls.Add(this.HdeviationLabel, 12, 0);
            this.tableLayoutPanelMeasurement.Controls.Add(this.VdeviationLabel, 12, 1);
            this.tableLayoutPanelMeasurement.Controls.Add(this.label11, 11, 0);
            this.tableLayoutPanelMeasurement.Controls.Add(this.label12, 11, 1);
            this.tableLayoutPanelMeasurement.Controls.Add(this.HbUnitLabel, 10, 0);
            this.tableLayoutPanelMeasurement.Controls.Add(this.VbUnitLabel, 10, 1);
            this.tableLayoutPanelMeasurement.Controls.Add(this.HbNumericUpDown, 9, 0);
            this.tableLayoutPanelMeasurement.Controls.Add(this.VbNumericUpDown, 9, 1);
            this.tableLayoutPanelMeasurement.Controls.Add(this.label5, 8, 0);
            this.tableLayoutPanelMeasurement.Controls.Add(this.label6, 8, 1);
            this.tableLayoutPanelMeasurement.Controls.Add(this.VaUnitLabel, 7, 1);
            this.tableLayoutPanelMeasurement.Controls.Add(this.HaUnitLabel, 7, 0);
            this.tableLayoutPanelMeasurement.Controls.Add(this.label4, 3, 0);
            this.tableLayoutPanelMeasurement.Name = "tableLayoutPanelMeasurement";
            // 
            // label1
            // 
            resources.ApplyResources(this.label1, "label1");
            this.label1.Name = "label1";
            // 
            // HorizontalScaleNumericUpDown
            // 
            this.HorizontalScaleNumericUpDown.DecimalPlaces = 2;
            this.HorizontalScaleNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.HorizontalScaleNumericUpDown, "HorizontalScaleNumericUpDown");
            this.HorizontalScaleNumericUpDown.Maximum = new decimal(new int[] {
            500000,
            0,
            0,
            0});
            this.HorizontalScaleNumericUpDown.Name = "HorizontalScaleNumericUpDown";
            this.HorizontalScaleNumericUpDown.ValueChanged += new System.EventHandler(this.HorizontalScaleNumericUpDown_ValueChanged);
            // 
            // HistoryNextButton
            // 
            resources.ApplyResources(this.HistoryNextButton, "HistoryNextButton");
            this.HistoryNextButton.Name = "HistoryNextButton";
            this.HistoryNextButton.UseVisualStyleBackColor = true;
            this.HistoryNextButton.Click += new System.EventHandler(this.HistoryNextButton_Click);
            // 
            // HistoryBackButton
            // 
            resources.ApplyResources(this.HistoryBackButton, "HistoryBackButton");
            this.HistoryBackButton.Name = "HistoryBackButton";
            this.HistoryBackButton.UseVisualStyleBackColor = true;
            this.HistoryBackButton.Click += new System.EventHandler(this.HistoryBackButton_Click);
            // 
            // HorizontalScaleUnitLabel
            // 
            resources.ApplyResources(this.HorizontalScaleUnitLabel, "HorizontalScaleUnitLabel");
            this.HorizontalScaleUnitLabel.Name = "HorizontalScaleUnitLabel";
            // 
            // HCursorCheckBox
            // 
            resources.ApplyResources(this.HCursorCheckBox, "HCursorCheckBox");
            this.HCursorCheckBox.Name = "HCursorCheckBox";
            this.HCursorCheckBox.UseVisualStyleBackColor = true;
            this.HCursorCheckBox.CheckedChanged += new System.EventHandler(this.HMeasureCheckBox_CheckedChanged);
            // 
            // VCursorCheckBox
            // 
            resources.ApplyResources(this.VCursorCheckBox, "VCursorCheckBox");
            this.VCursorCheckBox.Name = "VCursorCheckBox";
            this.VCursorCheckBox.UseVisualStyleBackColor = true;
            this.VCursorCheckBox.CheckedChanged += new System.EventHandler(this.VMeasureCheckBox_CheckedChanged);
            // 
            // HDistanceUnitLabel
            // 
            resources.ApplyResources(this.HDistanceUnitLabel, "HDistanceUnitLabel");
            this.HDistanceUnitLabel.Name = "HDistanceUnitLabel";
            // 
            // VDistanceUnitLabel
            // 
            resources.ApplyResources(this.VDistanceUnitLabel, "VDistanceUnitLabel");
            this.VDistanceUnitLabel.Name = "VDistanceUnitLabel";
            // 
            // label5
            // 
            resources.ApplyResources(this.label5, "label5");
            this.label5.Name = "label5";
            // 
            // label6
            // 
            resources.ApplyResources(this.label6, "label6");
            this.label6.Name = "label6";
            // 
            // VaUnitLabel
            // 
            resources.ApplyResources(this.VaUnitLabel, "VaUnitLabel");
            this.VaUnitLabel.Name = "VaUnitLabel";
            // 
            // HaUnitLabel
            // 
            resources.ApplyResources(this.HaUnitLabel, "HaUnitLabel");
            this.HaUnitLabel.Name = "HaUnitLabel";
            // 
            // label4
            // 
            resources.ApplyResources(this.label4, "label4");
            this.label4.ForeColor = System.Drawing.Color.Red;
            this.label4.Name = "label4";
            // 
            // WaveformSetGroupbox
            // 
            this.WaveformSetGroupbox.Controls.Add(this.tableLayoutPanelLocusSetting);
            this.WaveformSetGroupbox.Controls.Add(this.tableLayoutPanelWaveformSetting);
            resources.ApplyResources(this.WaveformSetGroupbox, "WaveformSetGroupbox");
            this.WaveformSetGroupbox.Name = "WaveformSetGroupbox";
            this.WaveformSetGroupbox.TabStop = false;
            // 
            // tableLayoutPanelLocusSetting
            // 
            this.tableLayoutPanelLocusSetting.AllowDrop = true;
            resources.ApplyResources(this.tableLayoutPanelLocusSetting, "tableLayoutPanelLocusSetting");
            this.tableLayoutPanelLocusSetting.Controls.Add(this.ZopLabel, 0, 5);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.ZopNumericUpDown, 1, 5);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.HornLengthNumericUpDown, 1, 6);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.OHNumericUpDown, 1, 7);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.CsAngleNumericUpDown, 1, 8);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.ZeNumericUpDown, 1, 9);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.GeometryTraceComboBox, 1, 10);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.hornLengthLabel, 0, 6);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.OHLabel, 0, 7);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.CsAngleLabel, 0, 8);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.ZeLabel, 0, 9);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.Geometrylabel, 0, 10);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.StartPackageIDLabel, 0, 12);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.StartPacketIDcomboBox, 1, 12);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.EndPackageIDLabel, 0, 13);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.labelGraphLimit, 1, 15);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.label3, 0, 4);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.label8, 1, 4);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.numericUpDownHLimit, 1, 18);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.HDetailGraphLabel, 0, 18);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.VDetailGraphLabel, 0, 17);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.numericUpDownVLimit, 1, 17);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.numericUpDownVDistance, 2, 17);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.labelGraphPosition2, 2, 16);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.labelGraphLimit2, 1, 16);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.labelGraphPosition, 2, 15);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.labelHPositionHint, 3, 18);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.labelDetailSettingNote, 2, 14);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.numericUpDownHDistance, 2, 18);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.labelVPositionHint, 3, 17);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.labelDetailGraphSetting, 0, 14);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.EndPacketIDcomboBox, 1, 13);
            this.tableLayoutPanelLocusSetting.Controls.Add(this.comboBoxDetailGraphSetting, 1, 14);
            this.tableLayoutPanelLocusSetting.Name = "tableLayoutPanelLocusSetting";
            // 
            // ZopLabel
            // 
            resources.ApplyResources(this.ZopLabel, "ZopLabel");
            this.ZopLabel.Name = "ZopLabel";
            // 
            // ZopNumericUpDown
            // 
            this.ZopNumericUpDown.DecimalPlaces = 2;
            resources.ApplyResources(this.ZopNumericUpDown, "ZopNumericUpDown");
            this.ZopNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.ZopNumericUpDown.Minimum = new decimal(new int[] {
            7000,
            0,
            0,
            0});
            this.ZopNumericUpDown.Name = "ZopNumericUpDown";
            this.ZopNumericUpDown.Value = new decimal(new int[] {
            8187,
            0,
            0,
            0});
            this.ZopNumericUpDown.ValueChanged += new System.EventHandler(this.ZopNumericUpDown_ValueChanged);
            // 
            // HornLengthNumericUpDown
            // 
            this.HornLengthNumericUpDown.DecimalPlaces = 2;
            resources.ApplyResources(this.HornLengthNumericUpDown, "HornLengthNumericUpDown");
            this.HornLengthNumericUpDown.Maximum = new decimal(new int[] {
            120000,
            0,
            0,
            0});
            this.HornLengthNumericUpDown.Minimum = new decimal(new int[] {
            100000,
            0,
            0,
            0});
            this.HornLengthNumericUpDown.Name = "HornLengthNumericUpDown";
            this.HornLengthNumericUpDown.Value = new decimal(new int[] {
            110000,
            0,
            0,
            0});
            this.HornLengthNumericUpDown.ValueChanged += new System.EventHandler(this.HornLengthNumericUpDown_ValueChanged);
            // 
            // OHNumericUpDown
            // 
            this.OHNumericUpDown.DecimalPlaces = 2;
            resources.ApplyResources(this.OHNumericUpDown, "OHNumericUpDown");
            this.OHNumericUpDown.Name = "OHNumericUpDown";
            this.OHNumericUpDown.Value = new decimal(new int[] {
            60,
            0,
            0,
            0});
            this.OHNumericUpDown.ValueChanged += new System.EventHandler(this.OHNumericUpDown_ValueChanged);
            // 
            // CsAngleNumericUpDown
            // 
            this.CsAngleNumericUpDown.DecimalPlaces = 2;
            resources.ApplyResources(this.CsAngleNumericUpDown, "CsAngleNumericUpDown");
            this.CsAngleNumericUpDown.Maximum = new decimal(new int[] {
            360,
            0,
            0,
            0});
            this.CsAngleNumericUpDown.Name = "CsAngleNumericUpDown";
            this.CsAngleNumericUpDown.ValueChanged += new System.EventHandler(this.CsAngleNumericUpDown_ValueChanged);
            // 
            // ZeNumericUpDown
            // 
            this.ZeNumericUpDown.DecimalPlaces = 2;
            resources.ApplyResources(this.ZeNumericUpDown, "ZeNumericUpDown");
            this.ZeNumericUpDown.Maximum = new decimal(new int[] {
            1000,
            0,
            0,
            0});
            this.ZeNumericUpDown.Name = "ZeNumericUpDown";
            this.ZeNumericUpDown.ValueChanged += new System.EventHandler(this.ZeNumericUpDown_ValueChanged);
            // 
            // GeometryTraceComboBox
            // 
            this.GeometryTraceComboBox.DisplayMember = "Oval";
            this.GeometryTraceComboBox.FormattingEnabled = true;
            this.GeometryTraceComboBox.Items.AddRange(new object[] {
            resources.GetString("GeometryTraceComboBox.Items"),
            resources.GetString("GeometryTraceComboBox.Items1")});
            resources.ApplyResources(this.GeometryTraceComboBox, "GeometryTraceComboBox");
            this.GeometryTraceComboBox.Name = "GeometryTraceComboBox";
            this.GeometryTraceComboBox.SelectedIndexChanged += new System.EventHandler(this.GeometryTraceComboBox_SelectedIndexChanged);
            // 
            // hornLengthLabel
            // 
            resources.ApplyResources(this.hornLengthLabel, "hornLengthLabel");
            this.hornLengthLabel.Name = "hornLengthLabel";
            // 
            // OHLabel
            // 
            resources.ApplyResources(this.OHLabel, "OHLabel");
            this.OHLabel.Name = "OHLabel";
            // 
            // CsAngleLabel
            // 
            resources.ApplyResources(this.CsAngleLabel, "CsAngleLabel");
            this.CsAngleLabel.Name = "CsAngleLabel";
            // 
            // ZeLabel
            // 
            resources.ApplyResources(this.ZeLabel, "ZeLabel");
            this.ZeLabel.Name = "ZeLabel";
            // 
            // Geometrylabel
            // 
            resources.ApplyResources(this.Geometrylabel, "Geometrylabel");
            this.Geometrylabel.Name = "Geometrylabel";
            // 
            // StartPackageIDLabel
            // 
            resources.ApplyResources(this.StartPackageIDLabel, "StartPackageIDLabel");
            this.StartPackageIDLabel.Name = "StartPackageIDLabel";
            // 
            // StartPacketIDcomboBox
            // 
            this.StartPacketIDcomboBox.FormattingEnabled = true;
            resources.ApplyResources(this.StartPacketIDcomboBox, "StartPacketIDcomboBox");
            this.StartPacketIDcomboBox.Name = "StartPacketIDcomboBox";
            this.StartPacketIDcomboBox.SelectedIndexChanged += new System.EventHandler(this.StartPacketIDcomboBox_SelectedIndexChanged);
            // 
            // EndPackageIDLabel
            // 
            resources.ApplyResources(this.EndPackageIDLabel, "EndPackageIDLabel");
            this.EndPackageIDLabel.Name = "EndPackageIDLabel";
            // 
            // labelGraphLimit
            // 
            resources.ApplyResources(this.labelGraphLimit, "labelGraphLimit");
            this.labelGraphLimit.Name = "labelGraphLimit";
            // 
            // label3
            // 
            resources.ApplyResources(this.label3, "label3");
            this.label3.Name = "label3";
            // 
            // label8
            // 
            resources.ApplyResources(this.label8, "label8");
            this.label8.Name = "label8";
            // 
            // numericUpDownHLimit
            // 
            resources.ApplyResources(this.numericUpDownHLimit, "numericUpDownHLimit");
            this.numericUpDownHLimit.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownHLimit.Name = "numericUpDownHLimit";
            this.numericUpDownHLimit.ValueChanged += new System.EventHandler(this.DetailGraphNumericUpDown_ValueChanged);
            // 
            // HDetailGraphLabel
            // 
            resources.ApplyResources(this.HDetailGraphLabel, "HDetailGraphLabel");
            this.HDetailGraphLabel.Name = "HDetailGraphLabel";
            // 
            // VDetailGraphLabel
            // 
            resources.ApplyResources(this.VDetailGraphLabel, "VDetailGraphLabel");
            this.VDetailGraphLabel.Name = "VDetailGraphLabel";
            // 
            // numericUpDownVLimit
            // 
            resources.ApplyResources(this.numericUpDownVLimit, "numericUpDownVLimit");
            this.numericUpDownVLimit.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownVLimit.Name = "numericUpDownVLimit";
            this.numericUpDownVLimit.ValueChanged += new System.EventHandler(this.DetailGraphNumericUpDown_ValueChanged);
            // 
            // numericUpDownVDistance
            // 
            resources.ApplyResources(this.numericUpDownVDistance, "numericUpDownVDistance");
            this.numericUpDownVDistance.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownVDistance.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.numericUpDownVDistance.Name = "numericUpDownVDistance";
            this.numericUpDownVDistance.ValueChanged += new System.EventHandler(this.numericUpDownDistance_ValueChanged);
            // 
            // labelGraphPosition2
            // 
            resources.ApplyResources(this.labelGraphPosition2, "labelGraphPosition2");
            this.labelGraphPosition2.Name = "labelGraphPosition2";
            // 
            // labelGraphLimit2
            // 
            resources.ApplyResources(this.labelGraphLimit2, "labelGraphLimit2");
            this.labelGraphLimit2.Name = "labelGraphLimit2";
            // 
            // labelGraphPosition
            // 
            resources.ApplyResources(this.labelGraphPosition, "labelGraphPosition");
            this.labelGraphPosition.Name = "labelGraphPosition";
            // 
            // labelHPositionHint
            // 
            resources.ApplyResources(this.labelHPositionHint, "labelHPositionHint");
            this.labelHPositionHint.ForeColor = System.Drawing.Color.Blue;
            this.labelHPositionHint.Name = "labelHPositionHint";
            // 
            // labelDetailSettingNote
            // 
            resources.ApplyResources(this.labelDetailSettingNote, "labelDetailSettingNote");
            this.labelDetailSettingNote.ForeColor = System.Drawing.Color.Red;
            this.labelDetailSettingNote.Name = "labelDetailSettingNote";
            // 
            // numericUpDownHDistance
            // 
            resources.ApplyResources(this.numericUpDownHDistance, "numericUpDownHDistance");
            this.numericUpDownHDistance.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.numericUpDownHDistance.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.numericUpDownHDistance.Name = "numericUpDownHDistance";
            this.numericUpDownHDistance.ValueChanged += new System.EventHandler(this.numericUpDownDistance_ValueChanged);
            // 
            // labelDetailGraphSetting
            // 
            resources.ApplyResources(this.labelDetailGraphSetting, "labelDetailGraphSetting");
            this.labelDetailGraphSetting.Name = "labelDetailGraphSetting";
            // 
            // EndPacketIDcomboBox
            // 
            resources.ApplyResources(this.EndPacketIDcomboBox, "EndPacketIDcomboBox");
            this.EndPacketIDcomboBox.FormattingEnabled = true;
            this.EndPacketIDcomboBox.Name = "EndPacketIDcomboBox";
            this.EndPacketIDcomboBox.SelectedIndexChanged += new System.EventHandler(this.EndPacketIDcomboBox_SelectedIndexChanged);
            // 
            // comboBoxDetailGraphSetting
            // 
            resources.ApplyResources(this.comboBoxDetailGraphSetting, "comboBoxDetailGraphSetting");
            this.comboBoxDetailGraphSetting.DisplayMember = "Set limit";
            this.comboBoxDetailGraphSetting.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxDetailGraphSetting.FormattingEnabled = true;
            this.comboBoxDetailGraphSetting.Items.AddRange(new object[] {
            resources.GetString("comboBoxDetailGraphSetting.Items"),
            resources.GetString("comboBoxDetailGraphSetting.Items1")});
            this.comboBoxDetailGraphSetting.Name = "comboBoxDetailGraphSetting";
            this.comboBoxDetailGraphSetting.SelectedIndexChanged += new System.EventHandler(this.comboBoxDetailGraphSetting_SelectedIndexChanged);
            // 
            // tableLayoutPanelWaveformSetting
            // 
            this.tableLayoutPanelWaveformSetting.AllowDrop = true;
            resources.ApplyResources(this.tableLayoutPanelWaveformSetting, "tableLayoutPanelWaveformSetting");
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.ChannelLabel, 0, 0);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.XcmdCheckBox, 0, 1);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.YcmdCheckBox, 0, 2);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.ZcmdCheckBox, 0, 3);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.ColorLabel, 1, 0);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.VScaleLabel, 2, 0);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.PosLabel, 3, 0);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.XcmdPosNumericUpDown, 3, 1);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.YcmdPosNumericUpDown, 3, 2);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.ZcmdPosNumericUpDown, 3, 3);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.XdeviationPosNumericUpDown, 3, 4);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.YdeviationPosNumericUpDown, 3, 5);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.ZdeviationPosNumericUpDown, 3, 6);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.VxPosNumericUpDown, 3, 7);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.VyPosNumericUpDown, 3, 8);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.VzPosNumericUpDown, 3, 9);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.Ch1PosNumericUpDown, 3, 10);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.Ch2PosNumericUpDown, 3, 11);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.Ch3PosNumericUpDown, 3, 12);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.Ch4PosNumericUpDown, 3, 13);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.XcmdScalenumericUpDown, 2, 1);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.YcmdScalenumericUpDown, 2, 2);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.ZcmdScalenumericUpDown, 2, 3);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.XdeviationScalenumericUpDown, 2, 4);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.YdeviationScalenumericUpDown, 2, 5);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.ZdeviationScalenumericUpDown, 2, 6);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.VxScalenumericUpDown, 2, 7);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.VyScalenumericUpDown, 2, 8);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.VzScalenumericUpDown, 2, 9);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.Ch1ScalenumericUpDown, 2, 10);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.Ch2ScalenumericUpDown, 2, 11);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.Ch3ScalenumericUpDown, 2, 12);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.Ch4ScalenumericUpDown, 2, 13);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.XcmdColorButton, 1, 1);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.YcmdColorButton, 1, 2);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.ZcmdColorButton, 1, 3);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.XdeviationColorButton, 1, 4);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.VxColorButton, 1, 7);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.VyColorButton, 1, 8);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.VzColorButton, 1, 9);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.Ch1ColorButton, 1, 10);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.Ch2ColorButton, 1, 11);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.Ch3ColorButton, 1, 12);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.Ch4ColorButton, 1, 13);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.XdeviationCheckBox, 0, 4);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.YdeviationCheckBox, 0, 5);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.ZdeviationCheckBox, 0, 6);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.VxCheckBox, 0, 7);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.VyCheckBox, 0, 8);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.VzCheckBox, 0, 9);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.Ch1CheckBox, 0, 10);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.Ch2CheckBox, 0, 11);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.Ch3CheckBox, 0, 12);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.Ch4CheckBox, 0, 13);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.YdeviationColorButton, 1, 5);
            this.tableLayoutPanelWaveformSetting.Controls.Add(this.ZdeviationColorButton, 1, 6);
            this.tableLayoutPanelWaveformSetting.Name = "tableLayoutPanelWaveformSetting";
            // 
            // ChannelLabel
            // 
            resources.ApplyResources(this.ChannelLabel, "ChannelLabel");
            this.ChannelLabel.Name = "ChannelLabel";
            // 
            // XcmdCheckBox
            // 
            resources.ApplyResources(this.XcmdCheckBox, "XcmdCheckBox");
            this.XcmdCheckBox.Name = "XcmdCheckBox";
            this.XcmdCheckBox.UseVisualStyleBackColor = true;
            this.XcmdCheckBox.CheckedChanged += new System.EventHandler(this.XcmdCheckBox_CheckedChanged);
            // 
            // YcmdCheckBox
            // 
            resources.ApplyResources(this.YcmdCheckBox, "YcmdCheckBox");
            this.YcmdCheckBox.Name = "YcmdCheckBox";
            this.YcmdCheckBox.UseVisualStyleBackColor = true;
            this.YcmdCheckBox.CheckedChanged += new System.EventHandler(this.YcmdCheckBox_CheckedChanged);
            // 
            // ZcmdCheckBox
            // 
            resources.ApplyResources(this.ZcmdCheckBox, "ZcmdCheckBox");
            this.ZcmdCheckBox.Name = "ZcmdCheckBox";
            this.ZcmdCheckBox.UseVisualStyleBackColor = true;
            this.ZcmdCheckBox.CheckedChanged += new System.EventHandler(this.ZcmdCheckBox_CheckedChanged);
            // 
            // ColorLabel
            // 
            resources.ApplyResources(this.ColorLabel, "ColorLabel");
            this.ColorLabel.Name = "ColorLabel";
            // 
            // VScaleLabel
            // 
            resources.ApplyResources(this.VScaleLabel, "VScaleLabel");
            this.VScaleLabel.Name = "VScaleLabel";
            // 
            // PosLabel
            // 
            resources.ApplyResources(this.PosLabel, "PosLabel");
            this.PosLabel.Name = "PosLabel";
            // 
            // XcmdPosNumericUpDown
            // 
            this.XcmdPosNumericUpDown.DecimalPlaces = 2;
            this.XcmdPosNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.XcmdPosNumericUpDown, "XcmdPosNumericUpDown");
            this.XcmdPosNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.XcmdPosNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.XcmdPosNumericUpDown.Name = "XcmdPosNumericUpDown";
            this.XcmdPosNumericUpDown.ValueChanged += new System.EventHandler(this.XcmdPosNumericUpDown_ValueChanged);
            // 
            // YcmdPosNumericUpDown
            // 
            this.YcmdPosNumericUpDown.DecimalPlaces = 2;
            this.YcmdPosNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.YcmdPosNumericUpDown, "YcmdPosNumericUpDown");
            this.YcmdPosNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.YcmdPosNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.YcmdPosNumericUpDown.Name = "YcmdPosNumericUpDown";
            this.YcmdPosNumericUpDown.ValueChanged += new System.EventHandler(this.YcmdPosNumericUpDown_ValueChanged);
            // 
            // ZcmdPosNumericUpDown
            // 
            this.ZcmdPosNumericUpDown.DecimalPlaces = 2;
            this.ZcmdPosNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.ZcmdPosNumericUpDown, "ZcmdPosNumericUpDown");
            this.ZcmdPosNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.ZcmdPosNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.ZcmdPosNumericUpDown.Name = "ZcmdPosNumericUpDown";
            this.ZcmdPosNumericUpDown.ValueChanged += new System.EventHandler(this.ZcmdPosNumericUpDown_ValueChanged);
            // 
            // XdeviationPosNumericUpDown
            // 
            this.XdeviationPosNumericUpDown.DecimalPlaces = 2;
            this.XdeviationPosNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.XdeviationPosNumericUpDown, "XdeviationPosNumericUpDown");
            this.XdeviationPosNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.XdeviationPosNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.XdeviationPosNumericUpDown.Name = "XdeviationPosNumericUpDown";
            this.XdeviationPosNumericUpDown.ValueChanged += new System.EventHandler(this.XdeviationPosNumericUpDown_ValueChanged);
            // 
            // YdeviationPosNumericUpDown
            // 
            this.YdeviationPosNumericUpDown.DecimalPlaces = 2;
            this.YdeviationPosNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.YdeviationPosNumericUpDown, "YdeviationPosNumericUpDown");
            this.YdeviationPosNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.YdeviationPosNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.YdeviationPosNumericUpDown.Name = "YdeviationPosNumericUpDown";
            this.YdeviationPosNumericUpDown.ValueChanged += new System.EventHandler(this.YdeviationPosNumericUpDown_ValueChanged);
            // 
            // ZdeviationPosNumericUpDown
            // 
            this.ZdeviationPosNumericUpDown.DecimalPlaces = 2;
            this.ZdeviationPosNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.ZdeviationPosNumericUpDown, "ZdeviationPosNumericUpDown");
            this.ZdeviationPosNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.ZdeviationPosNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.ZdeviationPosNumericUpDown.Name = "ZdeviationPosNumericUpDown";
            this.ZdeviationPosNumericUpDown.ValueChanged += new System.EventHandler(this.ZdeviationPosNumericUpDown_ValueChanged);
            // 
            // VxPosNumericUpDown
            // 
            this.VxPosNumericUpDown.DecimalPlaces = 2;
            this.VxPosNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.VxPosNumericUpDown, "VxPosNumericUpDown");
            this.VxPosNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.VxPosNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.VxPosNumericUpDown.Name = "VxPosNumericUpDown";
            this.VxPosNumericUpDown.ValueChanged += new System.EventHandler(this.VxPosNumericUpDown_ValueChanged);
            // 
            // VyPosNumericUpDown
            // 
            this.VyPosNumericUpDown.DecimalPlaces = 2;
            this.VyPosNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.VyPosNumericUpDown, "VyPosNumericUpDown");
            this.VyPosNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.VyPosNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.VyPosNumericUpDown.Name = "VyPosNumericUpDown";
            this.VyPosNumericUpDown.ValueChanged += new System.EventHandler(this.VyPosNumericUpDown_ValueChanged);
            // 
            // VzPosNumericUpDown
            // 
            this.VzPosNumericUpDown.DecimalPlaces = 2;
            this.VzPosNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.VzPosNumericUpDown, "VzPosNumericUpDown");
            this.VzPosNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.VzPosNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.VzPosNumericUpDown.Name = "VzPosNumericUpDown";
            this.VzPosNumericUpDown.ValueChanged += new System.EventHandler(this.VzPosNumericUpDown_ValueChanged);
            // 
            // Ch1PosNumericUpDown
            // 
            this.Ch1PosNumericUpDown.DecimalPlaces = 2;
            this.Ch1PosNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.Ch1PosNumericUpDown, "Ch1PosNumericUpDown");
            this.Ch1PosNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.Ch1PosNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.Ch1PosNumericUpDown.Name = "Ch1PosNumericUpDown";
            this.Ch1PosNumericUpDown.ValueChanged += new System.EventHandler(this.Ch1PosNumericUpDown_ValueChanged);
            // 
            // Ch2PosNumericUpDown
            // 
            this.Ch2PosNumericUpDown.DecimalPlaces = 2;
            this.Ch2PosNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.Ch2PosNumericUpDown, "Ch2PosNumericUpDown");
            this.Ch2PosNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.Ch2PosNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.Ch2PosNumericUpDown.Name = "Ch2PosNumericUpDown";
            this.Ch2PosNumericUpDown.ValueChanged += new System.EventHandler(this.Ch2PosNumericUpDown_ValueChanged);
            // 
            // Ch3PosNumericUpDown
            // 
            this.Ch3PosNumericUpDown.DecimalPlaces = 2;
            this.Ch3PosNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.Ch3PosNumericUpDown, "Ch3PosNumericUpDown");
            this.Ch3PosNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.Ch3PosNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.Ch3PosNumericUpDown.Name = "Ch3PosNumericUpDown";
            this.Ch3PosNumericUpDown.ValueChanged += new System.EventHandler(this.Ch3PosNumericUpDown_ValueChanged);
            // 
            // Ch4PosNumericUpDown
            // 
            this.Ch4PosNumericUpDown.DecimalPlaces = 2;
            this.Ch4PosNumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.Ch4PosNumericUpDown, "Ch4PosNumericUpDown");
            this.Ch4PosNumericUpDown.Maximum = new decimal(new int[] {
            10000,
            0,
            0,
            0});
            this.Ch4PosNumericUpDown.Minimum = new decimal(new int[] {
            10000,
            0,
            0,
            -2147483648});
            this.Ch4PosNumericUpDown.Name = "Ch4PosNumericUpDown";
            this.Ch4PosNumericUpDown.ValueChanged += new System.EventHandler(this.Ch4PosNumericUpDown_ValueChanged);
            // 
            // XcmdScalenumericUpDown
            // 
            this.XcmdScalenumericUpDown.DecimalPlaces = 2;
            this.XcmdScalenumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.XcmdScalenumericUpDown, "XcmdScalenumericUpDown");
            this.XcmdScalenumericUpDown.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.XcmdScalenumericUpDown.Name = "XcmdScalenumericUpDown";
            this.XcmdScalenumericUpDown.ValueChanged += new System.EventHandler(this.XcmdScalenumericUpDown_ValueChanged);
            // 
            // YcmdScalenumericUpDown
            // 
            this.YcmdScalenumericUpDown.DecimalPlaces = 2;
            this.YcmdScalenumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.YcmdScalenumericUpDown, "YcmdScalenumericUpDown");
            this.YcmdScalenumericUpDown.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.YcmdScalenumericUpDown.Name = "YcmdScalenumericUpDown";
            this.YcmdScalenumericUpDown.ValueChanged += new System.EventHandler(this.YcmdScalenumericUpDown_ValueChanged);
            // 
            // ZcmdScalenumericUpDown
            // 
            this.ZcmdScalenumericUpDown.DecimalPlaces = 2;
            this.ZcmdScalenumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.ZcmdScalenumericUpDown, "ZcmdScalenumericUpDown");
            this.ZcmdScalenumericUpDown.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.ZcmdScalenumericUpDown.Name = "ZcmdScalenumericUpDown";
            this.ZcmdScalenumericUpDown.ValueChanged += new System.EventHandler(this.ZcmdScalenumericUpDown_ValueChanged);
            // 
            // XdeviationScalenumericUpDown
            // 
            this.XdeviationScalenumericUpDown.DecimalPlaces = 2;
            this.XdeviationScalenumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.XdeviationScalenumericUpDown, "XdeviationScalenumericUpDown");
            this.XdeviationScalenumericUpDown.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.XdeviationScalenumericUpDown.Name = "XdeviationScalenumericUpDown";
            this.XdeviationScalenumericUpDown.ValueChanged += new System.EventHandler(this.XdeviationScalenumericUpDown_ValueChanged);
            // 
            // YdeviationScalenumericUpDown
            // 
            this.YdeviationScalenumericUpDown.DecimalPlaces = 3;
            this.YdeviationScalenumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            196608});
            resources.ApplyResources(this.YdeviationScalenumericUpDown, "YdeviationScalenumericUpDown");
            this.YdeviationScalenumericUpDown.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.YdeviationScalenumericUpDown.Name = "YdeviationScalenumericUpDown";
            this.YdeviationScalenumericUpDown.ValueChanged += new System.EventHandler(this.YdeviationScalenumericUpDown_ValueChanged);
            // 
            // ZdeviationScalenumericUpDown
            // 
            this.ZdeviationScalenumericUpDown.DecimalPlaces = 2;
            this.ZdeviationScalenumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.ZdeviationScalenumericUpDown, "ZdeviationScalenumericUpDown");
            this.ZdeviationScalenumericUpDown.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.ZdeviationScalenumericUpDown.Name = "ZdeviationScalenumericUpDown";
            this.ZdeviationScalenumericUpDown.ValueChanged += new System.EventHandler(this.ZdeviationScalenumericUpDown_ValueChanged);
            // 
            // VxScalenumericUpDown
            // 
            this.VxScalenumericUpDown.DecimalPlaces = 2;
            this.VxScalenumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.VxScalenumericUpDown, "VxScalenumericUpDown");
            this.VxScalenumericUpDown.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.VxScalenumericUpDown.Name = "VxScalenumericUpDown";
            this.VxScalenumericUpDown.ValueChanged += new System.EventHandler(this.VxScalenumericUpDown_ValueChanged);
            // 
            // VyScalenumericUpDown
            // 
            this.VyScalenumericUpDown.DecimalPlaces = 2;
            this.VyScalenumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.VyScalenumericUpDown, "VyScalenumericUpDown");
            this.VyScalenumericUpDown.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.VyScalenumericUpDown.Name = "VyScalenumericUpDown";
            this.VyScalenumericUpDown.ValueChanged += new System.EventHandler(this.VyScalenumericUpDown_ValueChanged);
            // 
            // VzScalenumericUpDown
            // 
            this.VzScalenumericUpDown.DecimalPlaces = 2;
            this.VzScalenumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.VzScalenumericUpDown, "VzScalenumericUpDown");
            this.VzScalenumericUpDown.Maximum = new decimal(new int[] {
            5000,
            0,
            0,
            0});
            this.VzScalenumericUpDown.Name = "VzScalenumericUpDown";
            this.VzScalenumericUpDown.ValueChanged += new System.EventHandler(this.VzScalenumericUpDown_ValueChanged);
            // 
            // Ch1ScalenumericUpDown
            // 
            this.Ch1ScalenumericUpDown.DecimalPlaces = 2;
            this.Ch1ScalenumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.Ch1ScalenumericUpDown, "Ch1ScalenumericUpDown");
            this.Ch1ScalenumericUpDown.Maximum = new decimal(new int[] {
            20000,
            0,
            0,
            0});
            this.Ch1ScalenumericUpDown.Name = "Ch1ScalenumericUpDown";
            this.Ch1ScalenumericUpDown.ValueChanged += new System.EventHandler(this.Ch1ScalenumericUpDown_ValueChanged);
            // 
            // Ch2ScalenumericUpDown
            // 
            this.Ch2ScalenumericUpDown.DecimalPlaces = 2;
            this.Ch2ScalenumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.Ch2ScalenumericUpDown, "Ch2ScalenumericUpDown");
            this.Ch2ScalenumericUpDown.Maximum = new decimal(new int[] {
            20000,
            0,
            0,
            0});
            this.Ch2ScalenumericUpDown.Name = "Ch2ScalenumericUpDown";
            this.Ch2ScalenumericUpDown.ValueChanged += new System.EventHandler(this.Ch2ScalenumericUpDown_ValueChanged);
            // 
            // Ch3ScalenumericUpDown
            // 
            this.Ch3ScalenumericUpDown.DecimalPlaces = 2;
            this.Ch3ScalenumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.Ch3ScalenumericUpDown, "Ch3ScalenumericUpDown");
            this.Ch3ScalenumericUpDown.Maximum = new decimal(new int[] {
            20000,
            0,
            0,
            0});
            this.Ch3ScalenumericUpDown.Name = "Ch3ScalenumericUpDown";
            this.Ch3ScalenumericUpDown.ValueChanged += new System.EventHandler(this.Ch3ScalenumericUpDown_ValueChanged);
            // 
            // Ch4ScalenumericUpDown
            // 
            this.Ch4ScalenumericUpDown.DecimalPlaces = 2;
            this.Ch4ScalenumericUpDown.Increment = new decimal(new int[] {
            1,
            0,
            0,
            131072});
            resources.ApplyResources(this.Ch4ScalenumericUpDown, "Ch4ScalenumericUpDown");
            this.Ch4ScalenumericUpDown.Maximum = new decimal(new int[] {
            20000,
            0,
            0,
            0});
            this.Ch4ScalenumericUpDown.Name = "Ch4ScalenumericUpDown";
            this.Ch4ScalenumericUpDown.ValueChanged += new System.EventHandler(this.Ch4ScalenumericUpDown_ValueChanged);
            // 
            // XcmdColorButton
            // 
            this.XcmdColorButton.BackColor = System.Drawing.Color.Red;
            resources.ApplyResources(this.XcmdColorButton, "XcmdColorButton");
            this.XcmdColorButton.Name = "XcmdColorButton";
            this.XcmdColorButton.UseVisualStyleBackColor = false;
            this.XcmdColorButton.Click += new System.EventHandler(this.XcmdColorButton_Click);
            // 
            // YcmdColorButton
            // 
            this.YcmdColorButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            resources.ApplyResources(this.YcmdColorButton, "YcmdColorButton");
            this.YcmdColorButton.Name = "YcmdColorButton";
            this.YcmdColorButton.UseVisualStyleBackColor = false;
            this.YcmdColorButton.Click += new System.EventHandler(this.YcmdColorButton_Click);
            // 
            // ZcmdColorButton
            // 
            this.ZcmdColorButton.BackColor = System.Drawing.Color.Yellow;
            resources.ApplyResources(this.ZcmdColorButton, "ZcmdColorButton");
            this.ZcmdColorButton.Name = "ZcmdColorButton";
            this.ZcmdColorButton.UseVisualStyleBackColor = false;
            this.ZcmdColorButton.Click += new System.EventHandler(this.ZcmdColorButton_Click);
            // 
            // XdeviationColorButton
            // 
            this.XdeviationColorButton.BackColor = System.Drawing.Color.Lime;
            resources.ApplyResources(this.XdeviationColorButton, "XdeviationColorButton");
            this.XdeviationColorButton.Name = "XdeviationColorButton";
            this.XdeviationColorButton.UseVisualStyleBackColor = false;
            this.XdeviationColorButton.Click += new System.EventHandler(this.XdeviationColorButton_Click);
            // 
            // VxColorButton
            // 
            this.VxColorButton.BackColor = System.Drawing.Color.Fuchsia;
            resources.ApplyResources(this.VxColorButton, "VxColorButton");
            this.VxColorButton.Name = "VxColorButton";
            this.VxColorButton.UseVisualStyleBackColor = false;
            this.VxColorButton.Click += new System.EventHandler(this.VxColorButton_Click);
            // 
            // VyColorButton
            // 
            this.VyColorButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            resources.ApplyResources(this.VyColorButton, "VyColorButton");
            this.VyColorButton.Name = "VyColorButton";
            this.VyColorButton.UseVisualStyleBackColor = false;
            this.VyColorButton.Click += new System.EventHandler(this.VyColorButton_Click);
            // 
            // VzColorButton
            // 
            this.VzColorButton.BackColor = System.Drawing.Color.Green;
            resources.ApplyResources(this.VzColorButton, "VzColorButton");
            this.VzColorButton.Name = "VzColorButton";
            this.VzColorButton.UseVisualStyleBackColor = false;
            this.VzColorButton.Click += new System.EventHandler(this.VzColorButton_Click);
            // 
            // Ch1ColorButton
            // 
            this.Ch1ColorButton.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.Ch1ColorButton, "Ch1ColorButton");
            this.Ch1ColorButton.Name = "Ch1ColorButton";
            this.Ch1ColorButton.UseVisualStyleBackColor = false;
            this.Ch1ColorButton.Click += new System.EventHandler(this.Ch1ColorButton_Click);
            // 
            // Ch2ColorButton
            // 
            this.Ch2ColorButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.Ch2ColorButton.ForeColor = System.Drawing.Color.White;
            resources.ApplyResources(this.Ch2ColorButton, "Ch2ColorButton");
            this.Ch2ColorButton.Name = "Ch2ColorButton";
            this.Ch2ColorButton.UseVisualStyleBackColor = false;
            this.Ch2ColorButton.Click += new System.EventHandler(this.Ch2ColorButton_Click);
            // 
            // Ch3ColorButton
            // 
            this.Ch3ColorButton.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            resources.ApplyResources(this.Ch3ColorButton, "Ch3ColorButton");
            this.Ch3ColorButton.Name = "Ch3ColorButton";
            this.Ch3ColorButton.UseVisualStyleBackColor = false;
            this.Ch3ColorButton.Click += new System.EventHandler(this.Ch3ColorButton_Click);
            // 
            // Ch4ColorButton
            // 
            this.Ch4ColorButton.BackColor = System.Drawing.Color.Red;
            resources.ApplyResources(this.Ch4ColorButton, "Ch4ColorButton");
            this.Ch4ColorButton.Name = "Ch4ColorButton";
            this.Ch4ColorButton.UseVisualStyleBackColor = false;
            this.Ch4ColorButton.Click += new System.EventHandler(this.Ch4ColorButton_Click);
            // 
            // XdeviationCheckBox
            // 
            resources.ApplyResources(this.XdeviationCheckBox, "XdeviationCheckBox");
            this.XdeviationCheckBox.Name = "XdeviationCheckBox";
            this.XdeviationCheckBox.UseVisualStyleBackColor = true;
            this.XdeviationCheckBox.CheckedChanged += new System.EventHandler(this.XdeviationCheckBox_CheckedChanged);
            // 
            // YdeviationCheckBox
            // 
            resources.ApplyResources(this.YdeviationCheckBox, "YdeviationCheckBox");
            this.YdeviationCheckBox.Name = "YdeviationCheckBox";
            this.YdeviationCheckBox.UseVisualStyleBackColor = true;
            this.YdeviationCheckBox.CheckedChanged += new System.EventHandler(this.YdeviationCheckBox_CheckedChanged);
            // 
            // ZdeviationCheckBox
            // 
            resources.ApplyResources(this.ZdeviationCheckBox, "ZdeviationCheckBox");
            this.ZdeviationCheckBox.Name = "ZdeviationCheckBox";
            this.ZdeviationCheckBox.UseVisualStyleBackColor = true;
            this.ZdeviationCheckBox.CheckedChanged += new System.EventHandler(this.ZdeviationCheckBox_CheckedChanged);
            // 
            // VxCheckBox
            // 
            resources.ApplyResources(this.VxCheckBox, "VxCheckBox");
            this.VxCheckBox.Name = "VxCheckBox";
            this.VxCheckBox.UseVisualStyleBackColor = true;
            this.VxCheckBox.CheckedChanged += new System.EventHandler(this.VxCheckBox_CheckedChanged);
            // 
            // VyCheckBox
            // 
            resources.ApplyResources(this.VyCheckBox, "VyCheckBox");
            this.VyCheckBox.Name = "VyCheckBox";
            this.VyCheckBox.UseVisualStyleBackColor = true;
            this.VyCheckBox.CheckedChanged += new System.EventHandler(this.VyCheckBox_CheckedChanged);
            // 
            // VzCheckBox
            // 
            resources.ApplyResources(this.VzCheckBox, "VzCheckBox");
            this.VzCheckBox.Name = "VzCheckBox";
            this.VzCheckBox.UseVisualStyleBackColor = true;
            this.VzCheckBox.CheckedChanged += new System.EventHandler(this.VzCheckBox_CheckedChanged);
            // 
            // Ch1CheckBox
            // 
            resources.ApplyResources(this.Ch1CheckBox, "Ch1CheckBox");
            this.Ch1CheckBox.Name = "Ch1CheckBox";
            this.Ch1CheckBox.UseVisualStyleBackColor = true;
            this.Ch1CheckBox.CheckedChanged += new System.EventHandler(this.Ch1CheckBox_CheckedChanged);
            // 
            // Ch2CheckBox
            // 
            resources.ApplyResources(this.Ch2CheckBox, "Ch2CheckBox");
            this.Ch2CheckBox.Name = "Ch2CheckBox";
            this.Ch2CheckBox.UseVisualStyleBackColor = true;
            this.Ch2CheckBox.CheckedChanged += new System.EventHandler(this.Ch2CheckBox_CheckedChanged);
            // 
            // Ch3CheckBox
            // 
            resources.ApplyResources(this.Ch3CheckBox, "Ch3CheckBox");
            this.Ch3CheckBox.Name = "Ch3CheckBox";
            this.Ch3CheckBox.UseVisualStyleBackColor = true;
            this.Ch3CheckBox.CheckedChanged += new System.EventHandler(this.Ch3CheckBox_CheckedChanged);
            // 
            // Ch4CheckBox
            // 
            resources.ApplyResources(this.Ch4CheckBox, "Ch4CheckBox");
            this.Ch4CheckBox.Name = "Ch4CheckBox";
            this.Ch4CheckBox.UseVisualStyleBackColor = true;
            this.Ch4CheckBox.CheckedChanged += new System.EventHandler(this.Ch4CheckBox_CheckedChanged);
            // 
            // YdeviationColorButton
            // 
            this.YdeviationColorButton.BackColor = System.Drawing.Color.Aqua;
            resources.ApplyResources(this.YdeviationColorButton, "YdeviationColorButton");
            this.YdeviationColorButton.Name = "YdeviationColorButton";
            this.YdeviationColorButton.UseVisualStyleBackColor = false;
            this.YdeviationColorButton.Click += new System.EventHandler(this.YdeviationColorButton_Click);
            // 
            // ZdeviationColorButton
            // 
            this.ZdeviationColorButton.BackColor = System.Drawing.Color.Blue;
            resources.ApplyResources(this.ZdeviationColorButton, "ZdeviationColorButton");
            this.ZdeviationColorButton.Name = "ZdeviationColorButton";
            this.ZdeviationColorButton.UseVisualStyleBackColor = false;
            this.ZdeviationColorButton.Click += new System.EventHandler(this.ZdeviationColorButton_Click);
            // 
            // groupBoxMeasurement
            // 
            this.groupBoxMeasurement.Controls.Add(this.tableLayoutPanelMeasurement);
            resources.ApplyResources(this.groupBoxMeasurement, "groupBoxMeasurement");
            this.groupBoxMeasurement.Name = "groupBoxMeasurement";
            this.groupBoxMeasurement.TabStop = false;
            // 
            // statusStrip1
            // 
            resources.ApplyResources(this.statusStrip1, "statusStrip1");
            this.statusStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.VideoFileToolStripStatusLabel});
            this.statusStrip1.Name = "statusStrip1";
            // 
            // VideoFileToolStripStatusLabel
            // 
            this.VideoFileToolStripStatusLabel.Name = "VideoFileToolStripStatusLabel";
            resources.ApplyResources(this.VideoFileToolStripStatusLabel, "VideoFileToolStripStatusLabel");
            // 
            // timer1
            // 
            this.timer1.Interval = 1;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // videoOpenFileDialog
            // 
            resources.ApplyResources(this.videoOpenFileDialog, "videoOpenFileDialog");
            // 
            // LocusTableLayoutPanel
            // 
            resources.ApplyResources(this.LocusTableLayoutPanel, "LocusTableLayoutPanel");
            this.LocusTableLayoutPanel.Controls.Add(this.LocusTabControl, 0, 0);
            this.LocusTableLayoutPanel.Name = "LocusTableLayoutPanel";
            // 
            // LocusTabControl
            // 
            this.LocusTabControl.AllowDrop = true;
            this.LocusTabControl.Controls.Add(this.XZtabPage);
            this.LocusTabControl.Controls.Add(this.XYtabPage);
            this.LocusTabControl.Controls.Add(this.YZtabPage);
            this.LocusTabControl.Controls.Add(this.RadiustabPage);
            this.LocusTabControl.Controls.Add(this.tabPage1);
            resources.ApplyResources(this.LocusTabControl, "LocusTabControl");
            this.LocusTabControl.Name = "LocusTabControl";
            this.LocusTabControl.SelectedIndex = 0;
            this.LocusTabControl.SelectedIndexChanged += new System.EventHandler(this.LocusTabControl_SelectedIndexChanged);
            // 
            // XZtabPage
            // 
            this.XZtabPage.AllowDrop = true;
            this.XZtabPage.Controls.Add(this.XZplotView);
            resources.ApplyResources(this.XZtabPage, "XZtabPage");
            this.XZtabPage.Name = "XZtabPage";
            this.XZtabPage.UseVisualStyleBackColor = true;
            // 
            // XZplotView
            // 
            this.XZplotView.AllowDrop = true;
            this.XZplotView.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.XZplotView, "XZplotView");
            this.XZplotView.Name = "XZplotView";
            this.XZplotView.PanCursor = System.Windows.Forms.Cursors.Hand;
            this.XZplotView.ZoomHorizontalCursor = System.Windows.Forms.Cursors.SizeWE;
            this.XZplotView.ZoomRectangleCursor = System.Windows.Forms.Cursors.SizeNWSE;
            this.XZplotView.ZoomVerticalCursor = System.Windows.Forms.Cursors.SizeNS;
            this.XZplotView.Click += new System.EventHandler(this.XZplotView_Click);
            // 
            // XYtabPage
            // 
            this.XYtabPage.AllowDrop = true;
            this.XYtabPage.Controls.Add(this.XYplotView);
            resources.ApplyResources(this.XYtabPage, "XYtabPage");
            this.XYtabPage.Name = "XYtabPage";
            this.XYtabPage.UseVisualStyleBackColor = true;
            // 
            // XYplotView
            // 
            this.XYplotView.AllowDrop = true;
            this.XYplotView.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.XYplotView, "XYplotView");
            this.XYplotView.Name = "XYplotView";
            this.XYplotView.PanCursor = System.Windows.Forms.Cursors.Hand;
            this.XYplotView.ZoomHorizontalCursor = System.Windows.Forms.Cursors.SizeWE;
            this.XYplotView.ZoomRectangleCursor = System.Windows.Forms.Cursors.SizeNWSE;
            this.XYplotView.ZoomVerticalCursor = System.Windows.Forms.Cursors.SizeNS;
            this.XYplotView.Click += new System.EventHandler(this.XYplotView_Click);
            // 
            // YZtabPage
            // 
            this.YZtabPage.AllowDrop = true;
            this.YZtabPage.Controls.Add(this.YZplotView);
            resources.ApplyResources(this.YZtabPage, "YZtabPage");
            this.YZtabPage.Name = "YZtabPage";
            this.YZtabPage.UseVisualStyleBackColor = true;
            // 
            // YZplotView
            // 
            this.YZplotView.AllowDrop = true;
            this.YZplotView.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.YZplotView, "YZplotView");
            this.YZplotView.Name = "YZplotView";
            this.YZplotView.PanCursor = System.Windows.Forms.Cursors.Hand;
            this.YZplotView.ZoomHorizontalCursor = System.Windows.Forms.Cursors.SizeWE;
            this.YZplotView.ZoomRectangleCursor = System.Windows.Forms.Cursors.SizeNWSE;
            this.YZplotView.ZoomVerticalCursor = System.Windows.Forms.Cursors.SizeNS;
            this.YZplotView.Click += new System.EventHandler(this.YZplotView_Click);
            // 
            // RadiustabPage
            // 
            this.RadiustabPage.AllowDrop = true;
            this.RadiustabPage.Controls.Add(this.RadiusplotView);
            resources.ApplyResources(this.RadiustabPage, "RadiustabPage");
            this.RadiustabPage.Name = "RadiustabPage";
            this.RadiustabPage.UseVisualStyleBackColor = true;
            // 
            // RadiusplotView
            // 
            this.RadiusplotView.AllowDrop = true;
            this.RadiusplotView.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.RadiusplotView, "RadiusplotView");
            this.RadiusplotView.Name = "RadiusplotView";
            this.RadiusplotView.PanCursor = System.Windows.Forms.Cursors.Hand;
            this.RadiusplotView.ZoomHorizontalCursor = System.Windows.Forms.Cursors.SizeWE;
            this.RadiusplotView.ZoomRectangleCursor = System.Windows.Forms.Cursors.SizeNWSE;
            this.RadiusplotView.ZoomVerticalCursor = System.Windows.Forms.Cursors.SizeNS;
            this.RadiusplotView.Click += new System.EventHandler(this.RadiusplotView_Click);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.waveformsPlotView);
            resources.ApplyResources(this.tabPage1, "tabPage1");
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // waveformsPlotView
            // 
            this.waveformsPlotView.AllowDrop = true;
            this.waveformsPlotView.BackColor = System.Drawing.Color.White;
            resources.ApplyResources(this.waveformsPlotView, "waveformsPlotView");
            this.waveformsPlotView.Name = "waveformsPlotView";
            this.waveformsPlotView.PanCursor = System.Windows.Forms.Cursors.Hand;
            this.waveformsPlotView.ZoomHorizontalCursor = System.Windows.Forms.Cursors.SizeWE;
            this.waveformsPlotView.ZoomRectangleCursor = System.Windows.Forms.Cursors.SizeNWSE;
            this.waveformsPlotView.ZoomVerticalCursor = System.Windows.Forms.Cursors.SizeNS;
            this.waveformsPlotView.Click += new System.EventHandler(this.waveformsPlotView_Click);
            // 
            // labelOperatingProgress
            // 
            resources.ApplyResources(this.labelOperatingProgress, "labelOperatingProgress");
            this.labelOperatingProgress.ForeColor = System.Drawing.Color.Blue;
            this.labelOperatingProgress.Name = "labelOperatingProgress";
            // 
            // progressBar
            // 
            resources.ApplyResources(this.progressBar, "progressBar");
            this.progressBar.Name = "progressBar";
            // 
            // tableLayoutPanelVideo
            // 
            resources.ApplyResources(this.tableLayoutPanelVideo, "tableLayoutPanelVideo");
            this.tableLayoutPanelVideo.Controls.Add(this.VideoPlayerControl, 0, 4);
            this.tableLayoutPanelVideo.Controls.Add(this.labelTotalFrameVideo, 0, 0);
            this.tableLayoutPanelVideo.Controls.Add(this.labelCameraFrameRate, 0, 1);
            this.tableLayoutPanelVideo.Controls.Add(this.labelVideoPlayerFrameRate, 0, 2);
            this.tableLayoutPanelVideo.Controls.Add(this.labelCurrentFrameVideo, 0, 3);
            this.tableLayoutPanelVideo.Name = "tableLayoutPanelVideo";
            // 
            // VideoPlayerControl
            // 
            resources.ApplyResources(this.VideoPlayerControl, "VideoPlayerControl");
            this.VideoPlayerControl.Name = "VideoPlayerControl";
            this.VideoPlayerControl.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("VideoPlayerControl.OcxState")));
            this.VideoPlayerControl.PlayStateChange += new AxWMPLib._WMPOCXEvents_PlayStateChangeEventHandler(this.VideoPlayerControl_PlayStateChange);
            this.VideoPlayerControl.PositionChange += new AxWMPLib._WMPOCXEvents_PositionChangeEventHandler(this.VideoPlayerControl_PositionChange);
            // 
            // labelTotalFrameVideo
            // 
            resources.ApplyResources(this.labelTotalFrameVideo, "labelTotalFrameVideo");
            this.labelTotalFrameVideo.Name = "labelTotalFrameVideo";
            // 
            // labelCameraFrameRate
            // 
            resources.ApplyResources(this.labelCameraFrameRate, "labelCameraFrameRate");
            this.labelCameraFrameRate.Name = "labelCameraFrameRate";
            // 
            // labelVideoPlayerFrameRate
            // 
            resources.ApplyResources(this.labelVideoPlayerFrameRate, "labelVideoPlayerFrameRate");
            this.labelVideoPlayerFrameRate.Name = "labelVideoPlayerFrameRate";
            // 
            // labelCurrentFrameVideo
            // 
            resources.ApplyResources(this.labelCurrentFrameVideo, "labelCurrentFrameVideo");
            this.labelCurrentFrameVideo.Name = "labelCurrentFrameVideo";
            // 
            // tableLayoutPanelPictureBox
            // 
            resources.ApplyResources(this.tableLayoutPanelPictureBox, "tableLayoutPanelPictureBox");
            this.tableLayoutPanelPictureBox.Controls.Add(this.pictureBoxFrameByFrame, 0, 0);
            this.tableLayoutPanelPictureBox.Controls.Add(this.trackBarPictureBox, 0, 3);
            this.tableLayoutPanelPictureBox.Controls.Add(this.labelCurrentFramePicturebox, 0, 2);
            this.tableLayoutPanelPictureBox.Controls.Add(this.labelTotalFramePicturebox, 0, 1);
            this.tableLayoutPanelPictureBox.Name = "tableLayoutPanelPictureBox";
            // 
            // pictureBoxFrameByFrame
            // 
            resources.ApplyResources(this.pictureBoxFrameByFrame, "pictureBoxFrameByFrame");
            this.pictureBoxFrameByFrame.Name = "pictureBoxFrameByFrame";
            this.pictureBoxFrameByFrame.TabStop = false;
            // 
            // trackBarPictureBox
            // 
            resources.ApplyResources(this.trackBarPictureBox, "trackBarPictureBox");
            this.trackBarPictureBox.Name = "trackBarPictureBox";
            this.trackBarPictureBox.Scroll += new System.EventHandler(this.trackBarPictureBox_Scroll);
            // 
            // labelCurrentFramePicturebox
            // 
            resources.ApplyResources(this.labelCurrentFramePicturebox, "labelCurrentFramePicturebox");
            this.labelCurrentFramePicturebox.Name = "labelCurrentFramePicturebox";
            // 
            // labelTotalFramePicturebox
            // 
            resources.ApplyResources(this.labelTotalFramePicturebox, "labelTotalFramePicturebox");
            this.labelTotalFramePicturebox.Name = "labelTotalFramePicturebox";
            // 
            // LocusWaveformsViewerAdvanceForm
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Inherit;
            resources.ApplyResources(this, "$this");
            this.BackColor = System.Drawing.Color.LightSteelBlue;
            this.Controls.Add(this.labelOperatingProgress);
            this.Controls.Add(this.tableLayoutPanelPictureBox);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.tableLayoutPanelVideo);
            this.Controls.Add(this.LocusTableLayoutPanel);
            this.Controls.Add(this.WaveformSetGroupbox);
            this.Controls.Add(this.groupBoxMeasurement);
            this.Controls.Add(this.inputFilePathStatusStrip);
            this.Controls.Add(this.statusStrip1);
            this.Controls.Add(this.toolStrip1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "LocusWaveformsViewerAdvanceForm";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.SizeChanged += new System.EventHandler(this.XYZLocusWaveformsViewerForm_SizeChanged);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.inputFilePathStatusStrip.ResumeLayout(false);
            this.inputFilePathStatusStrip.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HaNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HbNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.VaNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.VbNumericUpDown)).EndInit();
            this.tableLayoutPanelMeasurement.ResumeLayout(false);
            this.tableLayoutPanelMeasurement.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.HorizontalScaleNumericUpDown)).EndInit();
            this.WaveformSetGroupbox.ResumeLayout(false);
            this.tableLayoutPanelLocusSetting.ResumeLayout(false);
            this.tableLayoutPanelLocusSetting.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ZopNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.HornLengthNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OHNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.CsAngleNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ZeNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHLimit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownVLimit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownVDistance)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownHDistance)).EndInit();
            this.tableLayoutPanelWaveformSetting.ResumeLayout(false);
            this.tableLayoutPanelWaveformSetting.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.XcmdPosNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YcmdPosNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ZcmdPosNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.XdeviationPosNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YdeviationPosNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ZdeviationPosNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.VxPosNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.VyPosNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.VzPosNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch1PosNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch2PosNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch3PosNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch4PosNumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.XcmdScalenumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YcmdScalenumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ZcmdScalenumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.XdeviationScalenumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.YdeviationScalenumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ZdeviationScalenumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.VxScalenumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.VyScalenumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.VzScalenumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch1ScalenumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch2ScalenumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch3ScalenumericUpDown)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Ch4ScalenumericUpDown)).EndInit();
            this.groupBoxMeasurement.ResumeLayout(false);
            this.statusStrip1.ResumeLayout(false);
            this.statusStrip1.PerformLayout();
            this.LocusTableLayoutPanel.ResumeLayout(false);
            this.LocusTabControl.ResumeLayout(false);
            this.XZtabPage.ResumeLayout(false);
            this.XYtabPage.ResumeLayout(false);
            this.YZtabPage.ResumeLayout(false);
            this.RadiustabPage.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tableLayoutPanelVideo.ResumeLayout(false);
            this.tableLayoutPanelVideo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.VideoPlayerControl)).EndInit();
            this.tableLayoutPanelPictureBox.ResumeLayout(false);
            this.tableLayoutPanelPictureBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxFrameByFrame)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.trackBarPictureBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.StatusStrip inputFilePathStatusStrip;
        private System.Windows.Forms.OpenFileDialog openFileDialog;
        private System.Windows.Forms.SaveFileDialog saveCSVFileDialog;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton toolStripExportImg;
        private System.Windows.Forms.ToolStripButton toolStripOpenMonitoringDt;
        private System.Windows.Forms.ToolStripButton toolStripCsv;
        private System.Windows.Forms.ToolStripMenuItem toolToolStripMenuItem;
        private System.Windows.Forms.ToolStripStatusLabel InputPathToolStripStatusLabel;
        private System.Windows.Forms.ToolStripMenuItem SaveImgToToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportToCSVFileToolStripMenuItem;
        private System.Windows.Forms.SaveFileDialog saveImgFileDialog;
        private System.Windows.Forms.Button resetGraphbutton;
        private System.Windows.Forms.Label HorizontalScaleLabel;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label HbUnitLabel;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label VbUnitLabel;
        private System.Windows.Forms.NumericUpDown HaNumericUpDown;
        private System.Windows.Forms.NumericUpDown HbNumericUpDown;
        private System.Windows.Forms.NumericUpDown VaNumericUpDown;
        private System.Windows.Forms.NumericUpDown VbNumericUpDown;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label HdeviationLabel;
        private System.Windows.Forms.Label VdeviationLabel;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelMeasurement;
        private System.Windows.Forms.GroupBox WaveformSetGroupbox;
        private System.Windows.Forms.GroupBox groupBoxMeasurement;
        private System.Windows.Forms.Button HistoryBackButton;
        private System.Windows.Forms.Button HistoryNextButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckBox HCursorCheckBox;
        private System.Windows.Forms.CheckBox VCursorCheckBox;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.NumericUpDown HorizontalScaleNumericUpDown;
        private System.Windows.Forms.Label HorizontalScaleUnitLabel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label HDistanceUnitLabel;
        private System.Windows.Forms.Label VDistanceUnitLabel;
        private System.Windows.Forms.Label VaUnitLabel;
        private System.Windows.Forms.Label HaUnitLabel;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ToolStripButton toolStripButtonOpenVideo;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.ToolStripButton toolStripButtonPlayVideo;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private System.Windows.Forms.ToolStripStatusLabel VideoFileToolStripStatusLabel;
        private System.Windows.Forms.ToolStripMenuItem MonitoringDtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem videoFileToolStripMenuItem;
        private System.Windows.Forms.OpenFileDialog videoOpenFileDialog;
        private System.Windows.Forms.ToolStripMenuItem playVideoToolStripMenuItem;
        private System.Windows.Forms.ToolStripButton toolStripButtonShowSetting;
        private System.Windows.Forms.ToolStripButton toolStripButtonHideSetting;
        private System.Windows.Forms.TableLayoutPanel LocusTableLayoutPanel;
        private System.Windows.Forms.TabControl LocusTabControl;
        private System.Windows.Forms.TabPage XZtabPage;
        private OxyPlot.WindowsForms.PlotView XZplotView;
        private System.Windows.Forms.TabPage XYtabPage;
        private OxyPlot.WindowsForms.PlotView XYplotView;
        private System.Windows.Forms.TabPage YZtabPage;
        private OxyPlot.WindowsForms.PlotView YZplotView;
        private System.Windows.Forms.TabPage RadiustabPage;
        private OxyPlot.WindowsForms.PlotView RadiusplotView;
        private System.Windows.Forms.TabPage tabPage1;
        private OxyPlot.WindowsForms.PlotView waveformsPlotView;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelVideo;
        private System.Windows.Forms.ToolStripButton toolStripButtonFrameByFrame;
        private System.Windows.Forms.Label labelTotalFrameVideo;
        private System.Windows.Forms.Label labelCameraFrameRate;
        private System.Windows.Forms.Label labelVideoPlayerFrameRate;
        private System.Windows.Forms.Label labelCurrentFrameVideo;
        private AxWMPLib.AxWindowsMediaPlayer VideoPlayerControl;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelPictureBox;
        private System.Windows.Forms.PictureBox pictureBoxFrameByFrame;
        private System.Windows.Forms.Label labelTotalFramePicturebox;
        private System.Windows.Forms.Label labelCurrentFramePicturebox;
        private System.Windows.Forms.TrackBar trackBarPictureBox;
        private System.Windows.Forms.ToolStripMenuItem framebyFrameToolStripMenuItem;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.Label labelOperatingProgress;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelLocusSetting;
        private System.Windows.Forms.Label ZopLabel;
        private System.Windows.Forms.NumericUpDown ZopNumericUpDown;
        private System.Windows.Forms.Label hornLengthLabel;
        private System.Windows.Forms.NumericUpDown HornLengthNumericUpDown;
        private System.Windows.Forms.Label OHLabel;
        private System.Windows.Forms.Label CsAngleLabel;
        private System.Windows.Forms.Label ZeLabel;
        private System.Windows.Forms.Label Geometrylabel;
        private System.Windows.Forms.NumericUpDown OHNumericUpDown;
        private System.Windows.Forms.NumericUpDown CsAngleNumericUpDown;
        private System.Windows.Forms.NumericUpDown ZeNumericUpDown;
        private System.Windows.Forms.ComboBox GeometryTraceComboBox;
        private System.Windows.Forms.ComboBox StartPacketIDcomboBox;
        private System.Windows.Forms.Label StartPackageIDLabel;
        private System.Windows.Forms.Label EndPackageIDLabel;
        private System.Windows.Forms.ComboBox EndPacketIDcomboBox;
        private System.Windows.Forms.NumericUpDown numericUpDownHLimit;
        private System.Windows.Forms.NumericUpDown numericUpDownVLimit;
        private System.Windows.Forms.Label HDetailGraphLabel;
        private System.Windows.Forms.Label VDetailGraphLabel;
        private System.Windows.Forms.Label labelGraphLimit;
        private System.Windows.Forms.Label labelGraphPosition;
        private System.Windows.Forms.NumericUpDown numericUpDownVDistance;
        private System.Windows.Forms.NumericUpDown numericUpDownHDistance;
        private System.Windows.Forms.NumericUpDown XcmdScalenumericUpDown;
        private System.Windows.Forms.Button XcmdColorButton;
        private System.Windows.Forms.NumericUpDown XcmdPosNumericUpDown;
        private System.Windows.Forms.CheckBox XcmdCheckBox;
        private System.Windows.Forms.Label ChannelLabel;
        private System.Windows.Forms.Button YcmdColorButton;
        private System.Windows.Forms.Label ColorLabel;
        private System.Windows.Forms.CheckBox YcmdCheckBox;
        private System.Windows.Forms.NumericUpDown XdeviationScalenumericUpDown;
        private System.Windows.Forms.Label VScaleLabel;
        private System.Windows.Forms.NumericUpDown YdeviationScalenumericUpDown;
        private System.Windows.Forms.NumericUpDown ZdeviationScalenumericUpDown;
        private System.Windows.Forms.NumericUpDown VzPosNumericUpDown;
        private System.Windows.Forms.NumericUpDown VyPosNumericUpDown;
        private System.Windows.Forms.NumericUpDown VxPosNumericUpDown;
        private System.Windows.Forms.NumericUpDown ZdeviationPosNumericUpDown;
        private System.Windows.Forms.NumericUpDown Ch4PosNumericUpDown;
        private System.Windows.Forms.NumericUpDown Ch4ScalenumericUpDown;
        private System.Windows.Forms.NumericUpDown Ch3PosNumericUpDown;
        private System.Windows.Forms.Button Ch4ColorButton;
        private System.Windows.Forms.NumericUpDown Ch2PosNumericUpDown;
        private System.Windows.Forms.CheckBox Ch4CheckBox;
        private System.Windows.Forms.NumericUpDown Ch1PosNumericUpDown;
        private System.Windows.Forms.NumericUpDown Ch3ScalenumericUpDown;
        private System.Windows.Forms.NumericUpDown YdeviationPosNumericUpDown;
        private System.Windows.Forms.NumericUpDown Ch2ScalenumericUpDown;
        private System.Windows.Forms.NumericUpDown XdeviationPosNumericUpDown;
        private System.Windows.Forms.NumericUpDown Ch1ScalenumericUpDown;
        private System.Windows.Forms.Button Ch3ColorButton;
        private System.Windows.Forms.NumericUpDown ZcmdPosNumericUpDown;
        private System.Windows.Forms.Button Ch2ColorButton;
        private System.Windows.Forms.NumericUpDown YcmdPosNumericUpDown;
        private System.Windows.Forms.Button Ch1ColorButton;
        private System.Windows.Forms.CheckBox Ch3CheckBox;
        private System.Windows.Forms.NumericUpDown VxScalenumericUpDown;
        private System.Windows.Forms.CheckBox Ch2CheckBox;
        private System.Windows.Forms.NumericUpDown ZcmdScalenumericUpDown;
        private System.Windows.Forms.CheckBox Ch1CheckBox;
        private System.Windows.Forms.NumericUpDown YcmdScalenumericUpDown;
        private System.Windows.Forms.Label PosLabel;
        private System.Windows.Forms.CheckBox ZcmdCheckBox;
        private System.Windows.Forms.CheckBox XdeviationCheckBox;
        private System.Windows.Forms.CheckBox YdeviationCheckBox;
        private System.Windows.Forms.NumericUpDown VzScalenumericUpDown;
        private System.Windows.Forms.NumericUpDown VyScalenumericUpDown;
        private System.Windows.Forms.CheckBox ZdeviationCheckBox;
        private System.Windows.Forms.CheckBox VxCheckBox;
        private System.Windows.Forms.CheckBox VyCheckBox;
        private System.Windows.Forms.CheckBox VzCheckBox;
        private System.Windows.Forms.Button ZcmdColorButton;
        private System.Windows.Forms.Button XdeviationColorButton;
        private System.Windows.Forms.Button YdeviationColorButton;
        private System.Windows.Forms.Button ZdeviationColorButton;
        private System.Windows.Forms.Button VxColorButton;
        private System.Windows.Forms.Button VyColorButton;
        private System.Windows.Forms.Button VzColorButton;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanelWaveformSetting;
        private System.Windows.Forms.Label labelGraphPosition2;
        private System.Windows.Forms.Label labelGraphLimit2;
        private System.Windows.Forms.Label labelHPositionHint;
        private System.Windows.Forms.Label labelVPositionHint;
        private System.Windows.Forms.Label labelDetailGraphSetting;
        private System.Windows.Forms.ComboBox comboBoxDetailGraphSetting;
        private System.Windows.Forms.Label labelDetailSettingNote;
        private System.Windows.Forms.ToolStripButton toolStripButtonExtractVideo;
    }
}

