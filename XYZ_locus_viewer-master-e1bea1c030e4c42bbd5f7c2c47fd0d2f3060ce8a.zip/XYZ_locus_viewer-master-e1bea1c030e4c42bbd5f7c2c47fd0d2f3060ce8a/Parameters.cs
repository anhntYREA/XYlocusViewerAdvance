﻿using System;
using System.Configuration;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization;
using System.Xml;

namespace XYZ_LocusViewer
{
    public partial class Parameters
    {
        //Paramters
        public float Zop { get; set; }
        public float HornLength { get; set; }
        public float OH { get; set; }
        public float CSAngle { get; set; }
        public float Ze { get; set; }
        public ushort StartPackageID { get; set; }
        public ushort EndPackageID { get; set; }
        public int GeometryTrace { get; set; }

        public Parameters()
        {
            InitializeParameters();
        }
        public void InitializeParameters()
        {
            //Initialize values
            Zop = 8187.0f;
            HornLength = 110000.0f;
            OH = 60.0f;
            CSAngle = 0.0f;
            Ze = 0.0f;
            StartPackageID = 0x60;
            EndPackageID = 0;
            GeometryTrace = 0;
        }
        public void ReadConfigFile()
        {
            FileStream stream;
            try
            {
                stream = new FileStream("Parameters.xml", FileMode.Open);
            }
            catch
            {
                return;
            }
            var reader = XmlDictionaryReader.CreateTextReader(stream, new XmlDictionaryReaderQuotas());
            var serializer = new DataContractSerializer(typeof(Parameters));

            // Deserialize the data and read it from the instance.
            var deserializedPara = (Parameters)serializer.ReadObject(reader, true);
            reader.Close();
            stream.Close();
            this.CSAngle = deserializedPara.CSAngle;
            this.OH = deserializedPara.OH;
            this.Zop = deserializedPara.Zop;
            this.HornLength = deserializedPara.HornLength;
            this.Ze = deserializedPara.Ze;
            this.StartPackageID = deserializedPara.StartPackageID;
            this.EndPackageID = deserializedPara.EndPackageID;
            this.GeometryTrace = deserializedPara.GeometryTrace;
        }
        public void WriteConfigFile()
        {
            var setting = new XmlWriterSettings {Indent = true };                    
            var serializer = new DataContractSerializer(typeof(Parameters));
            using (var writer = XmlWriter.Create("Parameters.xml", setting))
            {
                serializer.WriteObject(writer, this);
                writer.Close();
            }
        }
    }
}
