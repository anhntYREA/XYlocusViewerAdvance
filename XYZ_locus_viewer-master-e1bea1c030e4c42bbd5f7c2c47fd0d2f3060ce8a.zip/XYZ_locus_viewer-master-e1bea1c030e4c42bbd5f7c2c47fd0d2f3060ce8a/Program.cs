﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace XYZ_LocusViewer
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            //Define config file's name and its path
            string configPath = Directory.GetCurrentDirectory() + "\\Parameters.config";
            AppDomain.CurrentDomain.SetData("APP_CONFIG_FILE", configPath);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new LocusWaveformsViewerAdvanceForm());
        }
    }
}
