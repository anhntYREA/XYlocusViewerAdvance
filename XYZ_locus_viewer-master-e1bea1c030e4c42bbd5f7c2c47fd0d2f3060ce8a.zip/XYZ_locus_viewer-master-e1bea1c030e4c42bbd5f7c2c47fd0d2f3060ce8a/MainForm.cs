﻿using Shinkawa.Monitoring;
using Shinkawa.Monitoring.Formats;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using OxyPlot;
using OxyPlot.Axes;
using OxyPlot.Series;
using System.Configuration;
using OxyPlot.WindowsForms;
using System.Text.RegularExpressions;
using WMPLib;
using AForge;
using AForge.Video.FFMPEG;
using System.Threading;

namespace XYZ_LocusViewer
{
    public partial class LocusWaveformsViewerAdvanceForm : Form
    {
        #region Global variables declaration
        private Parameters                  parameters;                   //Parameters setting
        private string                      inputFilePath;                //Input file name                
        private string                      videoFilePath;                //Video file name                             
        private double                      timeStamp;                    //Current time stamp
        private int                         cameraFrameRate;              //Frame rate of high-speed camera        
        private int                         numberOfFrame;                //Number of frames
        private int                         currentFrameIndex;            //Current frame index
        private bool                        historyBackBtnState;          //Backup state for [History back] button
        private bool                        historyNextBtnState;          //Backup state for [History next] button

        private List<MonitoringDataRow>     monitoringData;
        private List<MonitoringDataRow>     monitoringContractDt;
        private List<RotateData>            rotateData;
        private List<DeviationData>         deviationData;
        private List<VelocityData>          velocityData;
        private List<GeometryData>          geometryData;    

        private MeasurementLimit[]          measurementLmt;               // Measurement limit for XZ, XY, YZ, Radius and Waveform graph
        private NumericUpDown[]             waveformChannelScale;         // Scale for each waveform channel (13 channels ~ 13 scales )        
        private CheckBox[]                  waveformChannelCheckbox;      // Checkbox for each waveform channel (13 channels ~ 13 checkboxes )        
        private Button[]                    waveformChannelColor;         // Color button for each waveform channel (13 channels ~ 13 checkboxes )
        private NumericUpDown[]             waveformChannelPos;           // Channel position for each waveform channel (13 channels ~ 13 checkboxes )
        private CheckBox[]                  measurementCheckbox;          // Checkbox for each measurement cursor (4 cursors~ 4 checkboxes )        
        private string[]                    extractedFrameImage;          // Array of images which are extracted from video (1 image/1 frame)
        #endregion
        #region Contructor
        public LocusWaveformsViewerAdvanceForm()
        {
            InitializeComponent();
            InitializeData();
            InitializeControls();                   
        }
        #endregion
        #region Initialization
        private void InitMeasurementSetting(LineSeries[] LSeries, int StartIndex, int NumOfSeries)
        {
            var LineColor = (StartIndex == (int)LocusChannel.LOCUS_HA) ? OxyColors.Black : OxyColors.White;
            for (var index = StartIndex; index < NumOfSeries + GlobalVariable.NumberOfMeasurements; index++)
            {
                LSeries[index].Color = LineColor;
                LSeries[index].StrokeThickness = 0.1;
                LSeries[index].IsVisible = false;
                LSeries[index].LineStyle = LineStyle.Dot;
            }
        }
        private void InitializeControls()
        {
            GeometryTraceComboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            StartPacketIDcomboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            EndPacketIDcomboBox.DropDownStyle = ComboBoxStyle.DropDownList;
            //New PlotController
            var NewController = new PlotController();
            NewController.UnbindMouseWheel();

            XZplotView.Controller = NewController;
            XYplotView.Controller = NewController;
            YZplotView.Controller = NewController;
            RadiusplotView.Controller = NewController;
            waveformsPlotView.Controller = NewController;

            DisableAllControls();
            //Enable open file controls
            toolStripOpenMonitoringDt.Enabled = true;
            fileToolStripMenuItem.Enabled = true;
            InitMeasurementSetting();
            //Initialize waveform channel scale                  
            HideWaveformSetting();
            InitWaveformChannelControls();            
            //Show/Hide setting (default : Hide)
            HideSetting();
            tableLayoutPanelPictureBox.Visible = false; // Only shown with Frame-by-Frame function
            //Progress controls
            progressBar.Visible = false;
            this.Enabled = true;
            labelOperatingProgress.Visible = false;
            tableLayoutPanelVideo.Enabled = false;

            comboBoxDetailGraphSetting.SelectedIndex = 0;
        }
        private void InitWaveformChannelControls()
        {
            //Channel checkbox
            waveformChannelCheckbox = new CheckBox[GlobalVariable.NumberOfChannels];
            waveformChannelCheckbox[(int)WaveformChannel.WAV_XCMD] = XcmdCheckBox;
            waveformChannelCheckbox[(int)WaveformChannel.WAV_YCMD] = YcmdCheckBox;
            waveformChannelCheckbox[(int)WaveformChannel.WAV_ZCMD] = ZcmdCheckBox;
            waveformChannelCheckbox[(int)WaveformChannel.WAV_XDEVIATION] = XdeviationCheckBox;
            waveformChannelCheckbox[(int)WaveformChannel.WAV_YDEVIATION] = YdeviationCheckBox;
            waveformChannelCheckbox[(int)WaveformChannel.WAV_ZDEVIATION] = ZdeviationCheckBox;
            waveformChannelCheckbox[(int)WaveformChannel.WAV_XVELOCITY] = VxCheckBox;
            waveformChannelCheckbox[(int)WaveformChannel.WAV_YVELOCITY] = VyCheckBox;
            waveformChannelCheckbox[(int)WaveformChannel.WAV_ZVELOCITY] = VzCheckBox;
            waveformChannelCheckbox[(int)WaveformChannel.WAV_CH1] = Ch1CheckBox;
            waveformChannelCheckbox[(int)WaveformChannel.WAV_CH2] = Ch2CheckBox;
            waveformChannelCheckbox[(int)WaveformChannel.WAV_CH3] = Ch3CheckBox;
            waveformChannelCheckbox[(int)WaveformChannel.WAV_CH4] = Ch4CheckBox;
            //Channel color
            waveformChannelColor = new Button[GlobalVariable.NumberOfChannels];
            waveformChannelColor[(int)WaveformChannel.WAV_XCMD] = XcmdColorButton;
            waveformChannelColor[(int)WaveformChannel.WAV_YCMD] = YcmdColorButton;
            waveformChannelColor[(int)WaveformChannel.WAV_ZCMD] = ZcmdColorButton;
            waveformChannelColor[(int)WaveformChannel.WAV_XDEVIATION] = XdeviationColorButton;
            waveformChannelColor[(int)WaveformChannel.WAV_YDEVIATION] = YdeviationColorButton;
            waveformChannelColor[(int)WaveformChannel.WAV_ZDEVIATION] = ZdeviationColorButton;
            waveformChannelColor[(int)WaveformChannel.WAV_XVELOCITY] = VxColorButton;
            waveformChannelColor[(int)WaveformChannel.WAV_YVELOCITY] = VyColorButton;
            waveformChannelColor[(int)WaveformChannel.WAV_ZVELOCITY] = VzColorButton;
            waveformChannelColor[(int)WaveformChannel.WAV_CH1] = Ch1ColorButton;
            waveformChannelColor[(int)WaveformChannel.WAV_CH2] = Ch2ColorButton;
            waveformChannelColor[(int)WaveformChannel.WAV_CH3] = Ch3ColorButton;
            waveformChannelColor[(int)WaveformChannel.WAV_CH4] = Ch4ColorButton;
            //Channel scale
            waveformChannelScale = new NumericUpDown[GlobalVariable.NumberOfChannels];
            waveformChannelScale[(int)WaveformChannel.WAV_XCMD]       = XcmdScalenumericUpDown;
            waveformChannelScale[(int)WaveformChannel.WAV_YCMD]       = YcmdScalenumericUpDown;
            waveformChannelScale[(int)WaveformChannel.WAV_ZCMD]       = ZcmdScalenumericUpDown;
            waveformChannelScale[(int)WaveformChannel.WAV_XDEVIATION] = XdeviationScalenumericUpDown;
            waveformChannelScale[(int)WaveformChannel.WAV_YDEVIATION] = YdeviationScalenumericUpDown;
            waveformChannelScale[(int)WaveformChannel.WAV_ZDEVIATION] = ZdeviationScalenumericUpDown;
            waveformChannelScale[(int)WaveformChannel.WAV_XVELOCITY]  = VxScalenumericUpDown;
            waveformChannelScale[(int)WaveformChannel.WAV_YVELOCITY]  = VyScalenumericUpDown;
            waveformChannelScale[(int)WaveformChannel.WAV_ZVELOCITY]  = VzScalenumericUpDown;
            waveformChannelScale[(int)WaveformChannel.WAV_CH1] = Ch1ScalenumericUpDown;
            waveformChannelScale[(int)WaveformChannel.WAV_CH2] = Ch2ScalenumericUpDown;
            waveformChannelScale[(int)WaveformChannel.WAV_CH3] = Ch3ScalenumericUpDown;
            waveformChannelScale[(int)WaveformChannel.WAV_CH4] = Ch4ScalenumericUpDown;
            //Channel position
            waveformChannelPos = new NumericUpDown[GlobalVariable.NumberOfChannels];
            waveformChannelPos[(int)WaveformChannel.WAV_XCMD] = XcmdPosNumericUpDown;
            waveformChannelPos[(int)WaveformChannel.WAV_YCMD] = YcmdPosNumericUpDown;
            waveformChannelPos[(int)WaveformChannel.WAV_ZCMD] = ZcmdPosNumericUpDown;
            waveformChannelPos[(int)WaveformChannel.WAV_XDEVIATION] = XdeviationPosNumericUpDown;
            waveformChannelPos[(int)WaveformChannel.WAV_YDEVIATION] = YdeviationPosNumericUpDown;
            waveformChannelPos[(int)WaveformChannel.WAV_ZDEVIATION] = ZdeviationPosNumericUpDown;
            waveformChannelPos[(int)WaveformChannel.WAV_XVELOCITY] = VxPosNumericUpDown;
            waveformChannelPos[(int)WaveformChannel.WAV_YVELOCITY] = VyPosNumericUpDown;
            waveformChannelPos[(int)WaveformChannel.WAV_ZVELOCITY] = VzPosNumericUpDown;
            waveformChannelPos[(int)WaveformChannel.WAV_CH1] = Ch1PosNumericUpDown;
            waveformChannelPos[(int)WaveformChannel.WAV_CH2] = Ch2PosNumericUpDown;
            waveformChannelPos[(int)WaveformChannel.WAV_CH3] = Ch3PosNumericUpDown;
            waveformChannelPos[(int)WaveformChannel.WAV_CH4] = Ch4PosNumericUpDown;
            for (var idx = 0; idx < GlobalVariable.NumberOfChannels; idx++)
            {
                //Default: Z command position, X velocity, y velocity and z velocity are checked.
                if( (idx == (int)WaveformChannel.WAV_ZCMD) || 
                    (idx == (int)WaveformChannel.WAV_XVELOCITY) || 
                    (idx == (int)WaveformChannel.WAV_YVELOCITY) || 
                    (idx == (int)WaveformChannel.WAV_ZVELOCITY))
                {
                    waveformChannelCheckbox[idx].Checked = true;
                    waveformChannelColor[idx].Enabled = true;
                    waveformChannelScale[idx].Value = GlobalVariable.YAxisStep;
                    waveformChannelScale[idx].Enabled = true;
                    waveformChannelPos[idx].Value = 0.0M;
                    waveformChannelPos[idx].Enabled = true;
                }
                else
                {
                    waveformChannelCheckbox[idx].Checked = false;
                    waveformChannelColor[idx].Enabled = false;
                    waveformChannelScale[idx].Value = GlobalVariable.YAxisStep;
                    waveformChannelScale[idx].Enabled = false;
                    waveformChannelPos[idx].Value = 0.0M;
                    waveformChannelPos[idx].Enabled = false;
                }
            }
        }
        private void InitializeData()
        {
            monitoringData = new List<MonitoringDataRow>();
            monitoringContractDt = new List<MonitoringDataRow>();
            rotateData = new List<RotateData>();
            velocityData = new List<VelocityData>();
            deviationData = new List<DeviationData>();
            geometryData = new List<GeometryData>();
            parameters = new Parameters();
            try
            {
                parameters.ReadConfigFile();//Read parameters from configuration file
            }
            catch
            {
                MessageBox.Show("Can not read Parameters.config file!\nParameters will reset to default values.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            ShowParameters();
            inputFilePath = "C:\\input.monitoringdata";
            videoFilePath = "C:\\video.wmv";
            //Initialize measurement data
            measurementLmt = new MeasurementLimit[GlobalVariable.NumberOfGraphs];
            for (var index = 0; index < GlobalVariable.NumberOfGraphs; index++)
            {
                measurementLmt[index].HorizontalMax = 0.0;
                measurementLmt[index].HorizontalMin = 0.0;
                measurementLmt[index].VerticalMax = 0.0;
                measurementLmt[index].VerticalMin = 0.0;
            }
            numericUpDownHLimit.Value = 0;
            numericUpDownVLimit.Value = 0;
            numericUpDownHDistance.Value = 0;
            numericUpDownVDistance.Value = 0;
            timeStamp = 0.0;
            cameraFrameRate = GlobalVariable.HighSpeedCameraFrameRateDef;
            numberOfFrame = 0;
            currentFrameIndex = 0;
            extractedFrameImage = null;
            historyBackBtnState = false;
            historyNextBtnState = false;
        }
        private PlotModel InitializeGraphModel()
        {
            var plotModel = new PlotModel();
            //X axis
            var xAxis = new LinearAxis();
            xAxis.Position = AxisPosition.Bottom;
            xAxis.MajorGridlineColor = OxyColor.FromArgb(40, 0, 0, 139);
            xAxis.MajorGridlineStyle = LineStyle.Solid;
            xAxis.MinorGridlineColor = OxyColor.FromArgb(20, 0, 0, 139);
            xAxis.MinorGridlineStyle = LineStyle.Solid;
            xAxis.MinimumPadding = 0.1;
            xAxis.MaximumPadding = 0.1;
            plotModel.Axes.Add(xAxis);
            //Y axis
            var yAxis = new LinearAxis();
            yAxis.MajorGridlineColor = OxyColor.FromArgb(40, 0, 0, 139);
            yAxis.MajorGridlineStyle = LineStyle.Solid;
            yAxis.MinorGridlineColor = OxyColor.FromArgb(20, 0, 0, 139);
            yAxis.MinorGridlineStyle = LineStyle.Solid;
            yAxis.MinimumPadding = 0.1;
            yAxis.MaximumPadding = 0.1;
            plotModel.Axes.Add(yAxis);
            //Exchange right and left click operation of mouse
            plotModel.MouseDown += (s, e) =>
            {
                if (e.ChangedButton == OxyMouseButton.Left)
                {
                    e.ChangedButton = OxyMouseButton.Right;
                }
                else
                {
                    e.ChangedButton = OxyMouseButton.Left;
                }
            };
            return plotModel;
        }
        private void InitMeasurementSetting()
        {
            //Measurement
            HCursorCheckBox.Checked = false;
            VCursorCheckBox.Checked = false;
            //Measurement checkboxes status
            measurementCheckbox = new CheckBox[GlobalVariable.NumberOfMeasurements];
            measurementCheckbox[(int)MeasurementDirection.HMeasure] = HCursorCheckBox;
            measurementCheckbox[(int)MeasurementDirection.VMeasure] = VCursorCheckBox;

        }
        private void DisplayGraphSetting()
        {
            var currentPlotView = GetCurrentPlotView();
            if (currentPlotView == waveformsPlotView)
            {
                HideDetailGraphSetting();
                HideLocusSetting();
                ShowWaveformSetting();
            }
            else {
                ShowLocusSetting();
                HideWaveformSetting();
                if (currentPlotView == RadiusplotView)
                {
                    HideDetailGraphSetting();                    
                }
                else
                {
                    ShowDetailGraphSetting();                    
                }
            }
        }
        private void InitializeWaveforms()
        {
            waveformsPlotView.Model = InitializeGraphModel();
            waveformsPlotView.Model.Title = "Waveforms";
            waveformsPlotView.Model.TextColor = OxyColors.White;
            waveformsPlotView.Model.PlotType = PlotType.XY;
            waveformsPlotView.Model.Background = OxyColors.Black;

            var xaxis = waveformsPlotView.Model.Axes[0];
            var yaxis = waveformsPlotView.Model.Axes[1];

            xaxis.MajorGridlineColor = OxyColors.Green;
            xaxis.MajorGridlineStyle = LineStyle.Dot;
            xaxis.AxislineColor = OxyColors.Green;
            xaxis.TicklineColor = OxyColors.Green;
            xaxis.TitleColor = OxyColors.White;
            xaxis.TextColor = OxyColors.Black;

            yaxis.MajorGridlineColor = OxyColors.Green;
            yaxis.MajorGridlineStyle = LineStyle.Dot;
            yaxis.AxislineColor = OxyColors.Green;
            yaxis.TicklineColor = OxyColors.Green;
            yaxis.TitleColor = OxyColors.White;
            yaxis.TextColor = OxyColors.White;            

            xaxis.Title = "Time (ms)";
            yaxis.Title = "Deviation (\u00B5m)";
            xaxis.MajorStep = GlobalVariable.XAxisStep;
            xaxis.Maximum = 100;
            yaxis.MajorStep = GlobalVariable.YAxisStep;
            yaxis.Maximum = 4000;
            yaxis.Minimum = -4000;
            HorizontalScaleNumericUpDown.Value = GlobalVariable.XAxisStep;            
        }
        private void InitializeLocusSeries(LineSeries[] LocusSeries, int graphID)
        {
            for (var index = 0; index < LocusSeries.Count(); index++)
            {
                LocusSeries[index] = new LineSeries();
            }
            
            LocusSeries[(int)LocusChannel.LOCUS_CMD].Color = OxyColors.Blue;
            LocusSeries[(int)LocusChannel.LOCUS_CMD].Title = "Command";

            LocusSeries[(int)LocusChannel.LOCUS_ENC].Color = OxyColors.Red;
            LocusSeries[(int)LocusChannel.LOCUS_ENC].Title = "Actual";
            //Show geometry graph for only Radius graph

            if (graphID == (int)GraphID.RADIUS)
            {
                LocusSeries[(int)LocusChannel.LOCUS_GEO].IsVisible = true;
                LocusSeries[(int)LocusChannel.LOCUS_GEO].Color = OxyColors.Green;
                LocusSeries[(int)LocusChannel.LOCUS_GEO].Title = "Geometry";
            }
            else
            {
                LocusSeries[(int)LocusChannel.LOCUS_GEO].IsVisible = false;
            }
        }
        private void InitLocusTitle(int graphID, PlotView plotV)
        {
            var GraphTitle = "XZ";
            var XaxisTitle = "X axis (\u00B5m)";
            var YaxisTitle = "Y axis (\u00B5m)";                        
            switch (graphID)
            {
                case (int)GraphID.XZ:
                    GraphTitle = "XZ";
                    XaxisTitle = "X axis (\u00B5m)";
                    YaxisTitle = "Z axis (\u00B5m)";
                    break;
                case (int)GraphID.XY:
                    GraphTitle = "XY";
                    XaxisTitle = "X axis (\u00B5m)";
                    YaxisTitle = "Y axis (\u00B5m)";
                    break;
                case (int)GraphID.YZ:
                    GraphTitle = "YZ";
                    XaxisTitle = "Y axis (\u00B5m)";
                    YaxisTitle = "Z axis (\u00B5m)";
                    break;
                default:
                    break;
            }
            var NewModel = InitializeGraphModel();
            var Xaxis = NewModel.Axes[0];
            var Yaxis = NewModel.Axes[1];

            NewModel.Title = GraphTitle;            
            plotV.Model = NewModel;
            Xaxis.Title = XaxisTitle;
            Yaxis.Title = YaxisTitle;            
        }
        #endregion
        #region Read and collect data
        private bool CheckInputPacketID(ushort startPacketID, ushort endPacketID)
        {
            return (startPacketID <= endPacketID) ? true : false;
        }
        private void ReadInputFile(string fileName)
        {
            try
            {
                this.Enabled = false;
                progressBar.Enabled = true;
                progressBar.Visible = true;
                labelOperatingProgress.Visible = true;
                labelOperatingProgress.Enabled = true;

                var waveforms = new List<Waveform>();
                using (var stream = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    //Read file relied on format
                    IWaveformFormat format;
                    FormatFactory.Default.TryGetFormat(stream, out format);
                    waveforms.AddRange(format.Read(stream));
                }
                InputPathToolStripStatusLabel.Text = fileName;               //Show input filepath on status bar
                inputFilePath = fileName;
                CollectData(waveforms);                                      //Convert monitoring data to tool (software) coordinate data
                CollectPacketID();                                           //Collect packet ID
                EnableAllControls();
                DisplayGraphSetting();
                //History button status
                var currentDirectory = Path.GetDirectoryName(inputFilePath);
                var inputFiles = Directory.GetFiles(currentDirectory,"*.monitoringdata",SearchOption.TopDirectoryOnly);
                var currentFileIndex = Array.IndexOf(inputFiles, inputFilePath);
                var openFileIndex = currentFileIndex;

                if( inputFiles.Count() == 1)
                {
                    HistoryNextButton.Enabled = false;
                    HistoryBackButton.Enabled = false;
                }
                else if (openFileIndex == (inputFiles.Count() - 1))
                {
                    HistoryNextButton.Enabled = false;
                    HistoryBackButton.Enabled = true;
                }
                else if (openFileIndex == 0)
                {
                    HistoryNextButton.Enabled = true;
                    HistoryBackButton.Enabled = false;
                }
                else
                {
                    HistoryNextButton.Enabled = true;
                    HistoryBackButton.Enabled = true;
                }
                historyNextBtnState = HistoryNextButton.Enabled;
                historyBackBtnState = HistoryBackButton.Enabled;
            }
            catch
            { 
                MessageBox.Show("Can not read input file!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            finally
            {
                this.Enabled = true;                
                progressBar.Visible = false;
                labelOperatingProgress.Visible = false;
            }
        }
        private void CollectData(List<Waveform> waveforms)
        {
            //Clear old locus data
            if (this.monitoringData.Count != 0)
            {
                this.monitoringData.Clear();
            }
            //Get marker data
            var markerWaveforms = waveforms.SingleOrDefault(waveform => waveform.MeasuringObject == MeasuringObjects.MarkerData);
            if (markerWaveforms == null)
            {
                MessageBox.Show("Can not get marker data from input file!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            var markerData = markerWaveforms.GetView<MarkerData>();
            var targetObjects = new[]
            {
                MeasuringObjects.XPositionReference,
                MeasuringObjects.YPositionReference,
                MeasuringObjects.ZPositionReference,
                MeasuringObjects.XPositionCurrent,
                MeasuringObjects.YPositionCurrent,
                MeasuringObjects.ZPositionCurrent
            };
            //XYZ
            var viewWaveforms = targetObjects
                .Select(targetObject => waveforms.Single(waveform => waveform.MeasuringObject == targetObject))
                .Select(waveform => new { View = waveform.GetView<double>(), Multiplier = waveform.MeasurementUnit.ScalingMultiplier, Divider = waveform.MeasurementUnit.ScalingDivider, SamplingRate = waveform.SamplingRate })
                .ToArray();

            //User defined channels (4 channels: CH1, CH2, CH3, CH4)
            var userDefinedChannels = new[]
            {
                "CH1",
                "CH2",
                "CH3",
                "CH4"
            };

            var userDefinedWaveforms = new[]
            {
                viewWaveforms[0],  //CH1
                viewWaveforms[0],  //CH2
                viewWaveforms[0],  //CH3
                viewWaveforms[0]   //CH4
            };
            //User defined channel using flag (true: used, false: not used) - default = false
            var userDefinedFlag = new bool[userDefinedChannels.Count()];
            for ( int idx = 0; idx < userDefinedChannels.Count(); idx++)
            {
                userDefinedFlag[idx] = false;
            }

            for ( int idx = 0; idx < userDefinedChannels.Count(); idx++)
            {
                try
                {
                    userDefinedWaveforms[idx] = waveforms
                                                .Where(waveform => waveform.ChannelName.Equals(userDefinedChannels[idx]) == true)
                                                .Select(waveform => new { View = waveform.GetView<double>(), Multiplier = waveform.MeasurementUnit.ScalingMultiplier, Divider = waveform.MeasurementUnit.ScalingDivider, SamplingRate = waveform.SamplingRate }).FirstOrDefault();
                    if( userDefinedWaveforms[idx] != null)
                    {
                        userDefinedFlag[idx] = true;
                    }
                }
                catch
                {
                    userDefinedFlag[idx] = false;
                }
            }

            var monitoringData = Enumerable
                .Range(0, viewWaveforms.First().View.Count)
                .Select(index => new MonitoringDataRow()
                {
                    Xcmd = viewWaveforms[0].View[index] * viewWaveforms[0].Multiplier / viewWaveforms[0].Divider,
                    Ycmd = viewWaveforms[1].View[index] * viewWaveforms[1].Multiplier / viewWaveforms[1].Divider,
                    Zcmd = viewWaveforms[2].View[index] * viewWaveforms[2].Multiplier / viewWaveforms[2].Divider,
                    Xenc = viewWaveforms[3].View[index] * viewWaveforms[3].Multiplier / viewWaveforms[3].Divider,
                    Yenc = viewWaveforms[4].View[index] * viewWaveforms[4].Multiplier / viewWaveforms[4].Divider,
                    Zenc = viewWaveforms[5].View[index] * viewWaveforms[5].Multiplier / viewWaveforms[5].Divider,
                    //Other channels
                    CH1 = (userDefinedFlag[0] == true) ? userDefinedWaveforms[0].View[index] * userDefinedWaveforms[0].Multiplier / userDefinedWaveforms[0].Divider : 0,
                    CH2 = (userDefinedFlag[1] == true) ? userDefinedWaveforms[1].View[index] * userDefinedWaveforms[1].Multiplier / userDefinedWaveforms[1].Divider : 0,
                    CH3 = (userDefinedFlag[2] == true) ? userDefinedWaveforms[2].View[index] * userDefinedWaveforms[2].Multiplier / userDefinedWaveforms[2].Divider : 0,
                    CH4 = (userDefinedFlag[3] == true) ? userDefinedWaveforms[3].View[index] * userDefinedWaveforms[3].Multiplier / userDefinedWaveforms[3].Divider : 0,

                    MarkerID = markerData[index].MarkerId,
                    SamplingRate = viewWaveforms[0].SamplingRate
                })
                .ToArray();

            //Convert and 1st normalize monitoring data  
            var monitorDt0 = new MonitoringDataRow();
            monitorDt0.Time = 0.0;
            monitorDt0.Xcmd = 0.0;
            monitorDt0.Ycmd = 0.0;
            monitorDt0.Zcmd = 0.0;
            monitorDt0.Xenc = 0.0;
            monitorDt0.Yenc = 0.0;
            monitorDt0.Zenc = 0.0;
            monitorDt0.CH1 = 0.0;
            monitorDt0.CH2 = 0.0;
            monitorDt0.CH3 = 0.0;
            monitorDt0.CH4 = 0.0;
            for (var index = 0; index < monitoringData.Length; index++)
            {
                var monitorDt = monitoringData[index];
                var samplingRate = monitorDt.SamplingRate;

                if(samplingRate != 0.0)
                {
                    monitorDt.Time = index / samplingRate;
                }
                else
                {
                    monitorDt.Time = index / GlobalVariable.WaveformSamplingRateDef;
                }
                
                monitorDt.Time *= GlobalVariable.SecondToMiliSecondCof;  //Change s -> ms
                ConvertToToolCoordinate(ref monitorDt);
                if (index == 0)
                {
                    monitorDt0 = monitorDt;
                }
                Normalization1stStep(monitorDt0, ref monitorDt);
                monitoringData[index] = monitorDt;
            }

            this.monitoringData.AddRange(monitoringData);
        }
        private void DragDropFile(DragEventArgs e)
        {
            //Check if any file drop exist
            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                //Get files drop
                var targetPaths = e.Data.GetData(DataFormats.FileDrop) as string[];
                if ((targetPaths != null) && (targetPaths.Length == 1))
                {
                    e.Effect = DragDropEffects.Copy;
                }
            }
        }
        private void DragEnterFile(DragEventArgs e)
        {
            var targetPaths = e.Data.GetData(DataFormats.FileDrop) as string[];
            var targetPath = targetPaths.Single();
            var extension = Path.GetExtension(targetPath);
            if ((extension == ".monitoringdata") && (File.Exists(targetPath)))
            {
                ReadInputFile(targetPath);
                DrawNewXYZLocus();
            }
            else
            {
                MessageBox.Show("File type is invalid! Please input .monitoringdata file.", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void AddLocusCoordDt(GraphCoordData[] CoordDt, MonitoringDataRow Row, int graphID)
        {
            switch (graphID)
            {
                case (int)GraphID.XZ:
                    CoordDt[(int)LocusChannel.LOCUS_CMD].XaxisDt = Row.Xcmd;
                    CoordDt[(int)LocusChannel.LOCUS_CMD].YaxisDt = Row.Zcmd;

                    CoordDt[(int)LocusChannel.LOCUS_ENC].XaxisDt = Row.Xenc;
                    CoordDt[(int)LocusChannel.LOCUS_ENC].YaxisDt = Row.Zenc;
                    break;
                case (int)GraphID.XY:
                    CoordDt[(int)LocusChannel.LOCUS_CMD].XaxisDt = Row.Xcmd;
                    CoordDt[(int)LocusChannel.LOCUS_CMD].YaxisDt = Row.Ycmd;

                    CoordDt[(int)LocusChannel.LOCUS_ENC].XaxisDt = Row.Xenc;
                    CoordDt[(int)LocusChannel.LOCUS_ENC].YaxisDt = Row.Yenc;
                    break;
                case (int)GraphID.YZ:
                    CoordDt[(int)LocusChannel.LOCUS_CMD].XaxisDt = Row.Ycmd;
                    CoordDt[(int)LocusChannel.LOCUS_CMD].YaxisDt = Row.Zcmd;

                    CoordDt[(int)LocusChannel.LOCUS_ENC].XaxisDt = Row.Yenc;
                    CoordDt[(int)LocusChannel.LOCUS_ENC].YaxisDt = Row.Zenc;
                    break;
                default:
                    break;
            }

        }
        private void SaveGraphImage()
        {
            if (monitoringContractDt.Count == 0)
            {
                MessageBox.Show("Input file not found!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            //Determine current graph
            var imageName = "Radius";
            var currentPlotView = RadiusplotView;
            var currentPlotViewIndex = LocusTabControl.SelectedIndex;
            switch (currentPlotViewIndex)
            {
                case (int)GraphID.XZ: //XZ
                    imageName = "XZ";
                    currentPlotView = XZplotView;
                    break;
                case (int)GraphID.XY: //XY
                    imageName = "XY";
                    currentPlotView = XYplotView;
                    break;
                case (int)GraphID.YZ: //YZ
                    imageName = "YZ";
                    currentPlotView = YZplotView;
                    break;
                case (int)GraphID.RADIUS: //Radius
                    imageName = "Radius";
                    currentPlotView = RadiusplotView;
                    break;
                case (int)GraphID.WAVEFORM: //Waveforms
                    imageName = "Waveforms";
                    currentPlotView = waveformsPlotView;
                    break;
                default:
                    break;
            }

            DialogResult result = DialogResult.No;
            var inputFileDirectory = Path.GetDirectoryName(inputFilePath);

            var horizontalDetailMax = double.Parse(numericUpDownHLimit.Value.ToString("G"));
            var verticalDetailMax = double.Parse(numericUpDownVLimit.Value.ToString("G"));
            var imageFileName = imageName + "_H" + horizontalDetailMax + "_V" + verticalDetailMax + ".png";
            var imageFilePath = Path.Combine(inputFileDirectory, imageFileName);
            saveImgFileDialog.FileName = imageFileName;
            try
            {
                result = saveImgFileDialog.ShowDialog();
                imageFilePath = saveImgFileDialog.FileName;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex}", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (result == DialogResult.OK)
            {
                try
                {
                    var brushColor = Brushes.White;
                    if (currentPlotViewIndex == (int)GraphID.WAVEFORM)
                    {
                        brushColor = Brushes.Black;
                    }
                    PngExporter.Export(currentPlotView.Model, imageFilePath, 800, 800, brushColor);
                }
                catch (Exception except)
                {
                    MessageBox.Show("Can not save file!\n" + $"{except}", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
        private void SaveCSVFile()
        {
            if (monitoringContractDt.Count == 0)
            {
                MessageBox.Show("Input file not found!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            DialogResult result = DialogResult.No;
            var outputFileDirectory = Path.GetDirectoryName(inputFilePath);
            var outputFileName = Path.GetFileNameWithoutExtension(inputFilePath) + ".csv";
            var outputPath = Path.Combine(outputFileDirectory, outputFileName);
            saveCSVFileDialog.FileName = outputFileName;
            try
            {
                result = saveCSVFileDialog.ShowDialog();
                outputPath = saveCSVFileDialog.FileName;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"{ex}", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            if (result == DialogResult.OK)
            {
                try
                {
                    using (var writer = new StreamWriter(new FileStream(outputPath, FileMode.Create, FileAccess.Write, FileShare.None), Encoding.UTF8))
                    {
                        const string TimeColumnName = "Time";

                        const string XCmdColumnName = "Xcmd (\u00B5m)";
                        const string YCmdColumnName = "Ycmd (\u00B5m)";
                        const string ZCmdColumnName = "Zcmd (\u00B5m)";

                        const string XEncodeColumnName = "Xenc (\u00B5m)";
                        const string YEncodeColumnName = "Yenc (\u00B5m)";
                        const string ZEncodeColumnName = "Zenc (\u00B5m)";

                        const string CH1ColumnName = "CH1 (\u00B5m)";
                        const string CH2ColumnName = "CH2 (\u00B5m)";
                        const string CH3ColumnName = "CH3 (\u00B5m)";
                        const string CH4ColumnName = "CH4 (\u00B5m)";

                        const string ThetaCmdColumnName = "\u03B8cmd (\u00B5m)";
                        const string RCmdColumnName = "Rcmd (\u00B5m)";

                        const string ThetaEncodeColumnName = "\u03B8enc (\u00B5m)";
                        const string REncodeColumnName = "Renc (\u00B5m)";

                        const string ThetaGeographyColumnName = "\u03B8g";
                        const string RGeographyColumnName = "Rg";

                        const string DeltaXColumnName = "\u0394x (\u00B5m)";
                        const string DeltaYColumnName = "\u0394y (\u00B5m)";
                        const string DeltaZColumnName = "\u0394z (\u00B5m)";

                        const string VxColumnName = "Vx";
                        const string VyColumnName = "Vy";
                        const string VzColumnName = "Vz";

                        var headerTitle = TimeColumnName + "," + " " + ","
                                        + XCmdColumnName + "," + YCmdColumnName + "," + ZCmdColumnName + "," + " " + ","
                                        + XEncodeColumnName + "," + YEncodeColumnName + "," + ZEncodeColumnName + "," + " " + ","
                                        + CH1ColumnName + CH2ColumnName + CH3ColumnName + CH4ColumnName + "," + " " + ","
                                        + ThetaCmdColumnName + "," + RCmdColumnName + "," + " " + ","
                                        + ThetaEncodeColumnName + "," + REncodeColumnName + "," + " " + ","
                                        + DeltaXColumnName + "," + DeltaYColumnName + "," + DeltaZColumnName + "," + VxColumnName + "," + VyColumnName + "," + VzColumnName + "," + " " + "," + " " + ","
                                        + ThetaGeographyColumnName + "," + RGeographyColumnName;
                        writer.WriteLine(headerTitle);
                        for (var index = 0; index < monitoringContractDt.Count; index++)
                        {
                            var monitorDt = monitoringContractDt[index];
                            var rotateDt = rotateData[index];
                            var deviationDt = deviationData[index];
                            var velocityDt = velocityData[index];
                            var geometryDt = geometryData[index];

                            string csvData = monitorDt.Time.ToString() + "," + " " + ","
                                           + monitorDt.Xcmd + "," + monitorDt.Ycmd + "," + monitorDt.Zcmd + "," + " " + ","
                                           + monitorDt.Xenc + "," + monitorDt.Yenc + "," + monitorDt.Zenc + "," + " " + ","
                                           + monitorDt.CH1 + monitorDt.CH2 + monitorDt.CH3 + monitorDt.CH4 + "," + " " + ","
                                           + rotateDt.ThetaCmd + "," + rotateDt.Rcmd + "," + " " + ","
                                           + rotateDt.ThetaEnc + "," + rotateDt.Renc + "," + " " + ","
                                           + deviationDt.DeltaX + "," + deviationDt.DeltaY + "," + deviationDt.DeltaZ + "," + velocityDt.Vx + "," + velocityDt.Vy + "," + velocityDt.Vz + "," + " " + "," + " " + ","
                                           + geometryDt.ThetaG + "," + geometryDt.Rg;
                            writer.WriteLine(csvData);
                        }
                    }
                }
                catch
                {
                    MessageBox.Show("Can not save file!\n" + "Please close file before exporting!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

        }
        private void OpenFile()
        {
            openFileDialog.FileName = inputFilePath;
            //Open input file (.MonitoringData file)
            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                ReadInputFile(openFileDialog.FileName);
                DrawNewXYZLocus();                
            }
        }
        private void CollectPacketID()
        {
            //Collect packetID
            List<string> startPacketIDList = new List<string>();
            List<string> endPacketIDList2 = new List<string>();

            var packetIDs = monitoringData
                .Select(monitorDt => "0x" + monitorDt.MarkerID.Index.ToString("X"))
                .Distinct()
                .ToList();

            startPacketIDList.AddRange(packetIDs);
            endPacketIDList2.AddRange(packetIDs);

            var curStartPacketID = StartPacketIDcomboBox.SelectedValue;
            var curEndPacketID = EndPacketIDcomboBox.SelectedValue;
            var curStartPacketIDPos = StartPacketIDcomboBox.SelectedIndex;
            var curEndPacketIDPos = EndPacketIDcomboBox.SelectedIndex;
            //Add to combobox            
            StartPacketIDcomboBox.DataSource = startPacketIDList;
            EndPacketIDcomboBox.DataSource = endPacketIDList2;

            if (startPacketIDList.Contains(curStartPacketID))
            {
                StartPacketIDcomboBox.SelectedIndex = StartPacketIDcomboBox.FindString($"{curStartPacketID}");
            }
            else
            {
                StartPacketIDcomboBox.SelectedIndex = 0;
            }

            if (endPacketIDList2.Contains(curEndPacketID))
            {
                EndPacketIDcomboBox.SelectedIndex = EndPacketIDcomboBox.FindString($"{curEndPacketID}");
            }
            else
            {
                EndPacketIDcomboBox.SelectedIndex = endPacketIDList2.Count() - 1;
            }
        }
        #endregion
        #region Convert and normalization
        private void DataContraction()
        {
            var startPacketID = parameters.StartPackageID;
            var endPacketID = parameters.EndPackageID;
            //Copy to contracted data
            var contractData = monitoringData
                .SkipWhile(data => !((data.MarkerID.Group == MarkerGroup.PacketStart) && (data.MarkerID.Index == startPacketID)))
                .TakeWhile(data => !((data.MarkerID.Group == MarkerGroup.PacketEnd) && (data.MarkerID.Index == endPacketID)));
            var endData = monitoringData
                .SkipWhile(data => !((data.MarkerID.Group == MarkerGroup.PacketEnd) && (data.MarkerID.Index == endPacketID)))
                .TakeWhile(data => (data.MarkerID.Group == MarkerGroup.PacketEnd) && (data.MarkerID.Index == endPacketID));

            monitoringContractDt.AddRange(contractData);
            monitoringContractDt.AddRange(endData);
        }
        private void ConvertToToolCoordinate(ref MonitoringDataRow monitorDt)
        {
            var hornLength = parameters.HornLength;
            var zHeight = 900;                   //Horizontal height of horn (TCS)
            var zOp = parameters.Zop;
            //Encode data
            var ztEnc = monitorDt.Zenc + zOp;
            var ytEnc = monitorDt.Yenc - (Math.Sqrt(Math.Pow(hornLength, 2) - Math.Pow((ztEnc - zHeight), 2)) - hornLength);
            monitorDt.Yenc = ytEnc;
            monitorDt.Zenc = ztEnc;
            //command data
            var ztCmd = monitorDt.Zcmd + zOp;
            var ytCmd = monitorDt.Ycmd - (Math.Sqrt(Math.Pow(hornLength, 2) - Math.Pow((ztEnc - zHeight), 2)) - hornLength);
            monitorDt.Ycmd = ytCmd;
            monitorDt.Zcmd = ztCmd;
        }
        private void Normalization1stStep(MonitoringDataRow monitorDt0, ref MonitoringDataRow monitorDt)
        {
            monitorDt.Xcmd -= monitorDt0.Xcmd;
            monitorDt.Ycmd -= monitorDt0.Ycmd;
            monitorDt.Zcmd -= monitorDt0.Zenc;            //note: use encode z data

            monitorDt.Xenc -= monitorDt0.Xcmd;
            monitorDt.Yenc -= monitorDt0.Ycmd;
            monitorDt.Zenc -= monitorDt0.Zenc;

            monitorDt.CH1 -= monitorDt0.CH1;
            monitorDt.CH2 -= monitorDt0.CH2;
            monitorDt.CH3 -= monitorDt0.CH3;
            monitorDt.CH4 -= monitorDt0.CH4;
        }

        private void Normalization2ndStep(MonitoringDataRow monitorDt0, ref MonitoringDataRow monitorDt)
        {
            var zP = 0.0;
            var startPacketID = parameters.StartPackageID;
            var endPacketID = parameters.EndPackageID;

            if ((startPacketID >= 0x60) && (startPacketID <= 0x7F) && (endPacketID >= 0x60) && (endPacketID <= 0x7F))
            {
                zP = monitorDt0.Zcmd;
            }

            monitorDt.Xcmd -= monitorDt0.Xcmd;
            monitorDt.Ycmd -= monitorDt0.Ycmd;
            monitorDt.Zcmd -= zP;

            monitorDt.Xenc -= monitorDt0.Xcmd;
            monitorDt.Yenc -= monitorDt0.Ycmd;
            monitorDt.Zenc -= zP;

            monitorDt.CH1 -= monitorDt0.CH1;
            monitorDt.CH2 -= monitorDt0.CH2;
            monitorDt.CH3 -= monitorDt0.CH3;
            monitorDt.CH4 -= monitorDt0.CH4;
        }
        private double ConvertDeg2Rad(double deg)
        {
            return (deg * Math.PI) / 180.0;
        }
        private double ConvertRad2Deg(double rad)
        {
            return (rad * 180.0) / Math.PI;
        }
        private void RotateCoordinateSystem(ref MonitoringDataRow monitorDt)
        {
            var theta = parameters.CSAngle;
            var thetaRad = ConvertDeg2Rad(theta);
            var monitorDt_Bk = monitorDt;
            monitorDt.Xcmd = monitorDt_Bk.Xcmd * Math.Cos(thetaRad) + monitorDt_Bk.Ycmd * Math.Sin(thetaRad);
            monitorDt.Ycmd = -monitorDt_Bk.Xcmd * Math.Sin(thetaRad) + monitorDt_Bk.Ycmd * Math.Cos(thetaRad);

            monitorDt.Xenc = monitorDt_Bk.Xenc * Math.Cos(thetaRad) + monitorDt_Bk.Yenc * Math.Sin(thetaRad);
            monitorDt.Yenc = -monitorDt_Bk.Xenc * Math.Sin(thetaRad) + monitorDt_Bk.Yenc * Math.Cos(thetaRad);
        }
        #endregion
        #region Calculation 
        private void CalcDeviationData()
        {
            var deviationDt = monitoringContractDt
                .Select(contractDt => new DeviationData
                {
                    DeltaX = contractDt.Xenc - contractDt.Xcmd,
                    DeltaY = contractDt.Yenc - contractDt.Ycmd,
                    DeltaZ = contractDt.Zenc - contractDt.Zcmd
                });
            if (deviationData.Count != 0)
            {
                deviationData.Clear();
            }
            deviationData.AddRange(deviationDt);
        }
        private void CalcRadiusRotateAngle(MonitoringDataRow monitorDt)
        {
            var neckHeight = parameters.OH;
            var startPacketID = parameters.StartPackageID;
            var endPacketID = parameters.EndPackageID;

            if ((startPacketID >= 0x60) && (startPacketID <= 0x7F) && (endPacketID >= 0x60) && (endPacketID <= 0x7F))
            {
                neckHeight = 0.0f;
            }
            //Command data                            
            var Rcmd = Math.Sqrt(Math.Pow(monitorDt.Xcmd, 2) + Math.Pow(monitorDt.Ycmd, 2) + Math.Pow((monitorDt.Zcmd - neckHeight), 2));
            var thetaCmd = Math.Acos((monitorDt.Zcmd - neckHeight) / Rcmd);
            //Encoded data
            var Renc = Math.Sqrt(Math.Pow(monitorDt.Xenc, 2) + Math.Pow(monitorDt.Yenc, 2) + Math.Pow((monitorDt.Zenc - neckHeight), 2));
            var angleenc = ((monitorDt.Zenc - neckHeight) / Renc);

            var rotateDt = new RotateData
            {
                Rcmd = Rcmd,
                ThetaCmd = ConvertRad2Deg(thetaCmd),
                Renc = Renc,
                ThetaEnc = ConvertRad2Deg(Math.Acos(angleenc))
            };
            rotateData.Add(rotateDt);
        }
        private void CalcVelocity(int index, MonitoringDataRow monitorDt)
        {
            double Vx = 0.0, Vy = 0.0, Vz = 0.0;
            var Ts = 0.01f; //ms
            if (index > 0)
            {
                MonitoringDataRow preMonitorDt = monitoringContractDt[index - 1];
                //Velocity                
                if(monitorDt.Xcmd == preMonitorDt.Xcmd)
                {
                    Vx = velocityData[index - 1].Vx;
                }
                else
                {
                    Vx = (monitorDt.Xcmd - preMonitorDt.Xcmd) / (Ts);
                }
                if (monitorDt.Ycmd == preMonitorDt.Ycmd)
                {
                    Vy = velocityData[index - 1].Vy;
                }
                else
                {
                    Vy = (monitorDt.Ycmd - preMonitorDt.Ycmd) / (Ts);
                }
                if (monitorDt.Zcmd == preMonitorDt.Zcmd)
                {
                    Vz = velocityData[index - 1].Vz;
                }
                else
                {
                    Vz = (monitorDt.Zcmd - preMonitorDt.Zcmd) / (Ts);
                }
            }
            var velocityDt = new VelocityData
            {
                Vx = Vx,
                Vy = Vy,
                Vz = Vz
            };
            velocityData.Add(velocityDt);
        }
        private void CalcGeometryLocus(ref double Rv, ref double Rh)
        {
            //parameters from parameters setting dialog
            var Ze = parameters.Ze;
            var OH = parameters.OH;
            //Find the limit values of command data
            var xCmdMax = monitoringContractDt
                       .Max(row => row.Xcmd);

            var xCmdMin = monitoringContractDt
                       .Min(row => row.Xcmd);

            var yCmdMax = monitoringContractDt
                       .Max(row => row.Ycmd);

            var yCmdMin = monitoringContractDt
                       .Min(row => row.Ycmd);

            var zCmdMax = monitoringContractDt
                       .Max(row => row.Zcmd);

            //Calculation
            var xdt = xCmdMax - xCmdMin;
            var ydt = yCmdMax - yCmdMin;
            double zdt = 0;
            Rv = 0.0;
            Rh = 0.0;

            var WL = Math.Sqrt(Math.Pow(xdt, 2) + Math.Pow(ydt, 2));
            var L = Math.Sqrt(Math.Pow(Ze, 2) + Math.Pow(WL, 2));

            var xg = 0.0;

            var startPacketID = parameters.StartPackageID;
            var endPacketID = parameters.EndPackageID;

            if ((startPacketID >= 0x60) && (startPacketID <= 0x7F) && (endPacketID >= 0x60) && (endPacketID <= 0x7F))
            {
                OH = 0.0f;
            }
            zdt = zCmdMax - OH;
            if (parameters.GeometryTrace == 0)//Oval geometry
            {
                Rv = zdt;
                Rh = Math.Sqrt((Math.Pow(Rv, 2) * Math.Pow(WL, 2)) / (Math.Pow(Rv, 2) - Math.Pow(L, 2) + Math.Pow(WL, 2)));
            }
            else //Circle geometry
            {
                Rv = Rh = zdt;
            }

            for (var index = 0; index < monitoringContractDt.Count; index++)
            {
                var row = monitoringContractDt[index];

                xg = row.Xcmd;
                //Add Geometry to data table
                var yg = Math.Sqrt(Math.Pow(Rv, 2) * (1.0 - (Math.Pow(xg, 2) / Math.Pow(Rh, 2))));
                var Rg = Math.Sqrt(Math.Pow(xg, 2) + Math.Pow(yg, 2));
                var thetag = Math.Acos(yg / Rg);
                var geometryDt = new GeometryData
                {
                    Rg = Rg,
                    ThetaG = ConvertRad2Deg(thetag)
                };
                geometryData.Add(geometryDt);
            }
        }
        private void CalcForDrawing(ref double Rv, ref double Rh)
        {
            if (monitoringContractDt.Count != 0)
            {
                monitoringContractDt.Clear();
                rotateData.Clear();
                velocityData.Clear();
                deviationData.Clear();
                geometryData.Clear();
            }
            //Show all waveforms
            var currentGraphID = LocusTabControl.SelectedIndex;
            if (currentGraphID == (int)GraphID.WAVEFORM)
            {
                monitoringContractDt.AddRange(monitoringData);
            }
            else
            {
                try
                {
                    DataContraction();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.ToString(), "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            //2nd normalization and coordinate rotation
            var monitorContractDt0 = monitoringContractDt[0];
            for (var index = 0; index < monitoringContractDt.Count; index++)
            {
                var monitorDt = monitoringContractDt[index];
                Normalization2ndStep(monitorContractDt0, ref monitorDt);
                RotateCoordinateSystem(ref monitorDt);
                monitoringContractDt[index] = monitorDt;
                //Radius and rotate calculation
                CalcRadiusRotateAngle(monitorDt);
                CalcVelocity(index, monitorDt);
            }
            //Deviation data
            CalcDeviationData();
            //Geometry data
            CalcGeometryLocus(ref Rv, ref Rh);
        }
        #endregion
        #region Draw locus viewer
        private void DrawNewXYZLocus()
        {
            if (monitoringData.Count == 0)
            {                
                return;
            }
            var Rv = 0.0;
            var Rh = 0.0;
            //Calculation
            CalcForDrawing(ref Rv, ref Rh);
            //Draw
            DrawRadiusGraph(Rv, Rh);
            DrawWaveforms();
            DrawLocus((int)GraphID.XZ, XZplotView);      
            DrawLocus((int)GraphID.XY, XYplotView);
            DrawLocus((int)GraphID.YZ, YZplotView);            
            ResetDetailGraphSetting();
            //Load all graphs for first time
            for(int idx = 0; idx < LocusTabControl.TabCount; idx++)
            {
                LocusTabControl.SelectedIndex = idx;
            }
            LocusTabControl.SelectedIndex = (int)GraphID.XZ;
        }
        private void UpdateXYZLocus()
        {
            if (monitoringData.Count == 0)
            {
                return;
            }
            var Rv = 0.0;
            var Rh = 0.0;
            //Calculation
            CalcForDrawing(ref Rv, ref Rh);
            //Draw
            var CurGraphId = LocusTabControl.SelectedIndex;
            switch (CurGraphId)
            {
                case (int)GraphID.XZ:
                case (int)GraphID.XY:
                case (int)GraphID.YZ:
                    UpdateLocusGraph();                    
                    break;
                case (int)GraphID.RADIUS:
                    UpdateRadiusGraph();
                    break;
                case (int)GraphID.WAVEFORM:
                    for (var index = 0; index < GlobalVariable.NumberOfChannels; index++)
                    {
                        if (waveformChannelCheckbox[index].Checked == true)
                        {
                            UpdateWaveformViewerData(index);
                        }
                    }
                    break;
                default:
                    break;
            }
        }
        private void DrawRadiusGraph(double Rv, double Rh)
        {
            RadiusplotView.Model = InitializeGraphModel();
            RadiusplotView.Model.PlotType = PlotType.XY;
            RadiusplotView.Model.Title = "Radius";
            //Setting for axes
            var xaxis = RadiusplotView.Model.Axes[0];
            var yaxis = RadiusplotView.Model.Axes[1];

            //Set limit
            xaxis.Minimum = 0;
            xaxis.Maximum = 105;
            if (Rv >= Rh)
            {
                yaxis.Minimum = Rh - 100.0f;
                yaxis.Maximum = Rv + 100.0f;
            }
            else
            {
                yaxis.Minimum = Rv - 100.0f;
                yaxis.Maximum = Rh + 100.0f;
            }

            xaxis.Title = "Angle (deg)";
            yaxis.Title = "r (\u00B5m)";

            //Graph settings
            var Series = new LineSeries[GlobalVariable.NumberOfLocusSeries + GlobalVariable.NumberOfMeasurements];
            InitializeLocusSeries(Series, (int)GraphID.RADIUS);
            //Get data
            var CoordDt = new List<GraphCoordData>[GlobalVariable.NumberOfLocusSeries + GlobalVariable.NumberOfMeasurements];
            for (var index = 0; index < GlobalVariable.NumberOfLocusSeries + GlobalVariable.NumberOfMeasurements; index++)
            {
                CoordDt[index] = new List<GraphCoordData>();
            }
            //Initialize limit for measurement
            InitMeasurementSetting(Series, (int)LocusChannel.LOCUS_HA, GlobalVariable.NumberOfLocusSeries);

            var idx = 0;
            foreach (var row in rotateData)
            {
                var time = monitoringContractDt[idx].Time;
                if ((time > timeStamp) && (timeStamp != 0.0))
                {
                    break;
                }
                var thetaCmd = row.ThetaCmd;
                var Rcmd = row.Rcmd;

                var GraphCoordDt = new GraphCoordData[GlobalVariable.NumberOfLocusSeries];
                GraphCoordDt[(int)LocusChannel.LOCUS_CMD].XaxisDt = row.ThetaCmd;
                GraphCoordDt[(int)LocusChannel.LOCUS_CMD].YaxisDt = row.Rcmd;

                GraphCoordDt[(int)LocusChannel.LOCUS_ENC].XaxisDt = row.ThetaEnc;
                GraphCoordDt[(int)LocusChannel.LOCUS_ENC].YaxisDt = row.Renc;

                for (var index = 0; index < GlobalVariable.NumberOfLocusSeries - 1; index++)
                {
                    CoordDt[index].Add(GraphCoordDt[index]);
                }
                //Determine limit for measurement
                var XaxisDt = GraphCoordDt.Select(graphDt => graphDt.XaxisDt);
                var YaxisDt = GraphCoordDt.Select(graphDt => graphDt.YaxisDt);

                UpdateMeasurementLimit(XaxisDt, YaxisDt, (int)GraphID.RADIUS);
                idx++;
            }
            idx = 0;
            foreach (var row in geometryData)
            {
                var time = monitoringContractDt[idx].Time;
                if ((time > timeStamp) && (timeStamp != 0.0))
                {
                    break;
                }
                GraphCoordData GraphCoordDt;
                GraphCoordDt.XaxisDt = row.ThetaG;
                GraphCoordDt.YaxisDt = row.Rg;

                CoordDt[(int)LocusChannel.LOCUS_GEO].Add(GraphCoordDt);
                //Determine limit for measurement
                var XaxisDt = new double[1];
                XaxisDt[0] = GraphCoordDt.XaxisDt;

                var YaxisDt = new double[1];
                YaxisDt[0] = GraphCoordDt.YaxisDt;

                UpdateMeasurementLimit(XaxisDt.AsEnumerable(), YaxisDt.AsEnumerable(), (int)GraphID.RADIUS);
                idx++;
            }
            AddMeasurementDtToGraph(CoordDt, (int)LocusChannel.LOCUS_HA, (int)LocusChannel.LOCUS_HB, (int)LocusChannel.LOCUS_VA, (int)LocusChannel.LOCUS_VB, (int)GraphID.RADIUS);
            //Add to graph
            AddDtToGraph(RadiusplotView, Series, CoordDt);
        }
        private void DrawDetailGraph()
        {
            DrawLocus((int)GraphID.XZ, XZplotView);
            DrawLocus((int)GraphID.XY, XYplotView);
            DrawLocus((int)GraphID.YZ, YZplotView);
            //Update measurement values                       
            UpdateMeasurement();
        }
        private void DrawLocus(int graphID, PlotView plotV)
        {
            InitLocusTitle(graphID, plotV);     //Initialize title for graph            
            DetailGraphSet(plotV);              //Detail graph setting            
            //Series settings
            var Series = new LineSeries[GlobalVariable.NumberOfLocusSeries + GlobalVariable.NumberOfMeasurements];
            InitializeLocusSeries(Series, graphID);
            //Get data
            var CoordDt = new List<GraphCoordData>[GlobalVariable.NumberOfLocusSeries + GlobalVariable.NumberOfMeasurements];
            for (var index = 0; index < CoordDt.Count(); index++)
            {
                CoordDt[index] = new List<GraphCoordData>();
            }
            //Initialize limit for measurement
            InitMeasurementSetting(Series, (int)LocusChannel.LOCUS_HA, GlobalVariable.NumberOfLocusSeries);
            foreach (var row in monitoringContractDt)
            {
                var GraphCoordDt = new GraphCoordData[GlobalVariable.NumberOfLocusSeries];
                AddLocusCoordDt(GraphCoordDt, row, graphID);
                for (var index = 0; index < GlobalVariable.NumberOfLocusSeries - 1; index++)
                {
                    CoordDt[index].Add(GraphCoordDt[index]);
                }
                //Determine limit for measurement
                var XaxisDt = GraphCoordDt.Select(graphDt => graphDt.XaxisDt);
                var YaxisDt = GraphCoordDt.Select(graphDt => graphDt.YaxisDt);

                UpdateMeasurementLimit( XaxisDt, YaxisDt, graphID);
            }
            AddMeasurementDtToGraph(CoordDt, (int)LocusChannel.LOCUS_HA, (int)LocusChannel.LOCUS_HB, (int)LocusChannel.LOCUS_VA, (int)LocusChannel.LOCUS_VB, graphID);
            //Add to graph
            AddDtToGraph(plotV, Series, CoordDt);
        }
        #endregion
        #region Draw waveforms viewer
        private void WaveformsChannelsColorSet(LineSeries[] ChannelSeries)
        {
            //13 Channels             
            ChannelSeries[(int)WaveformChannel.WAV_XCMD].Color = XcmdColorButton.BackColor.ToOxyColor();
            ChannelSeries[(int)WaveformChannel.WAV_YCMD].Color = YcmdColorButton.BackColor.ToOxyColor();
            ChannelSeries[(int)WaveformChannel.WAV_ZCMD].Color = ZcmdColorButton.BackColor.ToOxyColor();
            ChannelSeries[(int)WaveformChannel.WAV_XDEVIATION].Color = XdeviationColorButton.BackColor.ToOxyColor();
            ChannelSeries[(int)WaveformChannel.WAV_YDEVIATION].Color = YdeviationColorButton.BackColor.ToOxyColor();
            ChannelSeries[(int)WaveformChannel.WAV_ZDEVIATION].Color = ZdeviationColorButton.BackColor.ToOxyColor();
            ChannelSeries[(int)WaveformChannel.WAV_XVELOCITY].Color = VxColorButton.BackColor.ToOxyColor();
            ChannelSeries[(int)WaveformChannel.WAV_YVELOCITY].Color = VyColorButton.BackColor.ToOxyColor();
            ChannelSeries[(int)WaveformChannel.WAV_ZVELOCITY].Color = VzColorButton.BackColor.ToOxyColor();
            ChannelSeries[(int)WaveformChannel.WAV_CH1].Color = Ch1ColorButton.BackColor.ToOxyColor();
            ChannelSeries[(int)WaveformChannel.WAV_CH2].Color = Ch2ColorButton.BackColor.ToOxyColor();
            ChannelSeries[(int)WaveformChannel.WAV_CH3].Color = Ch3ColorButton.BackColor.ToOxyColor();
            ChannelSeries[(int)WaveformChannel.WAV_CH4].Color = Ch4ColorButton.BackColor.ToOxyColor();
        }
        private void GetCoordData(List<GraphCoordData>[] CoordDt, int graphID)
        {
            for (var index = 0; index < monitoringContractDt.Count; index++)
            {
                var time                = monitoringContractDt[index].Time;
                if ((time > timeStamp) && (timeStamp != 0.0))
                {
                    break;
                }
                var velocityDt          = velocityData[index];
                var deviationDt         = deviationData[index];
                var monitorContractDt   = monitoringData[index];
                //10 channels
                //command position
                var GraphCoordDt = new GraphCoordData[GlobalVariable.NumberOfChannels];
                GraphCoordDt[(int)WaveformChannel.WAV_XCMD].YaxisDt       = monitorContractDt.Xcmd;
                GraphCoordDt[(int)WaveformChannel.WAV_YCMD].YaxisDt       = monitorContractDt.Ycmd;
                GraphCoordDt[(int)WaveformChannel.WAV_ZCMD].YaxisDt       = monitorContractDt.Zcmd;
                GraphCoordDt[(int)WaveformChannel.WAV_XDEVIATION].YaxisDt = deviationDt.DeltaX;
                GraphCoordDt[(int)WaveformChannel.WAV_YDEVIATION].YaxisDt = deviationDt.DeltaY;
                GraphCoordDt[(int)WaveformChannel.WAV_ZDEVIATION].YaxisDt = deviationDt.DeltaZ;
                GraphCoordDt[(int)WaveformChannel.WAV_XVELOCITY].YaxisDt  = velocityDt.Vx;
                GraphCoordDt[(int)WaveformChannel.WAV_YVELOCITY].YaxisDt  = velocityDt.Vy;
                GraphCoordDt[(int)WaveformChannel.WAV_ZVELOCITY].YaxisDt  = velocityDt.Vz;
                GraphCoordDt[(int)WaveformChannel.WAV_CH1].YaxisDt = monitorContractDt.CH1;
                GraphCoordDt[(int)WaveformChannel.WAV_CH2].YaxisDt = monitorContractDt.CH2;
                GraphCoordDt[(int)WaveformChannel.WAV_CH3].YaxisDt = monitorContractDt.CH3;
                GraphCoordDt[(int)WaveformChannel.WAV_CH4].YaxisDt = monitorContractDt.CH4;

                for (var idx = 0; idx < GraphCoordDt.Count(); idx++)
                {
                    GraphCoordDt[idx].XaxisDt = time;
                    CoordDt[idx].Add(GraphCoordDt[idx]);
                }

                CoordDt[(int)WaveformChannel.WAV_XCMD].Add(GraphCoordDt[(int)WaveformChannel.WAV_XCMD]);

                var XaxisDt = GraphCoordDt.Select(graph => graph.XaxisDt);
                var YaxisDt = GraphCoordDt.Select(graph => graph.YaxisDt);

                UpdateMeasurementLimit(XaxisDt, YaxisDt, graphID);
            }
            AddMeasurementDtToGraph(CoordDt, (int)WaveformChannel.WAV_HA, (int)WaveformChannel.WAV_HB, (int)WaveformChannel.WAV_VA, (int)WaveformChannel.WAV_VB, graphID);
        }
        private void DrawWaveforms()
        {
            InitializeWaveforms();
            LineSeries[] series = new LineSeries[GlobalVariable.NumberOfChannels + GlobalVariable.NumberOfMeasurements];  // 13 channels + 4 measurement = 13 series
            for (var index = 0; index < GlobalVariable.NumberOfChannels + GlobalVariable.NumberOfMeasurements; index++)
            {
                series[index] = new LineSeries();
            }
            WaveformsChannelsColorSet(series);              //Setting for channel series (13 channels)            
            //Get coordinate data
            List<GraphCoordData>[] CoordDt = new List<GraphCoordData>[GlobalVariable.NumberOfChannels + GlobalVariable.NumberOfMeasurements];
            for (var index = 0; index < GlobalVariable.NumberOfChannels + GlobalVariable.NumberOfMeasurements; index++)
            {
                CoordDt[index] = new List<GraphCoordData>();
            }
            InitMeasurementSetting(series, (int)WaveformChannel.WAV_HA, GlobalVariable.NumberOfChannels);            //Initialize limit for measurement
            GetCoordData(CoordDt, (int)GraphID.WAVEFORM);
            AddDtToGraph(waveformsPlotView, series, CoordDt);            //Add data to waveforms
            //Disable channels on waveforms
            foreach (var ser in series)
            {
                ser.IsVisible = false;
            }
        }
        #endregion
        #region Show information
        private void ShowParameters()
        {
            ZopNumericUpDown.Value = Decimal.Parse($"{parameters.Zop}");
            HornLengthNumericUpDown.Value = Decimal.Parse($"{parameters.HornLength}");
            OHNumericUpDown.Value = Decimal.Parse($"{parameters.OH}");
            CsAngleNumericUpDown.Value = Decimal.Parse($"{parameters.CSAngle}");
            ZeNumericUpDown.Value = Decimal.Parse($"{parameters.Ze}");
            GeometryTraceComboBox.SelectedIndex = parameters.GeometryTrace;
            var StartIDText = "0x" + parameters.StartPackageID.ToString("X");
            var EndIDText = "0x" + parameters.EndPackageID.ToString("X");
            StartPacketIDcomboBox.DataSource = new List<string>() { StartIDText };
            EndPacketIDcomboBox.DataSource = new List<string>() { EndIDText };
        }
        private void ShowSetting()
        {
            toolStripButtonShowSetting.Enabled = false;
            toolStripButtonHideSetting.Enabled = true;
            WaveformSetGroupbox.Visible = true;
            groupBoxMeasurement.Visible = true;
            //tableLayoutPanelVideo.Visible = false;
        }
        private void HideSetting()
        {
            toolStripButtonShowSetting.Enabled = true;
            toolStripButtonHideSetting.Enabled = false;
            WaveformSetGroupbox.Visible = false;
            groupBoxMeasurement.Visible = false;
        }
        #endregion
        #region Event
        private void XYZLocusWaveformsViewerForm_SizeChanged(object sender, EventArgs e)
        {
            var W_Adjust = this.Width - tableLayoutPanelVideo.Width;
            var H_Adjust = this.Height - 200;
            if (W_Adjust < H_Adjust)
            {
                LocusTabControl.Width = W_Adjust;
                LocusTabControl.Height = LocusTabControl.Width + 18;
            }
            else if (H_Adjust != 0.0F)
            {
                LocusTabControl.Width = H_Adjust;
                LocusTabControl.Width = LocusTabControl.Height - 18;
            }
        }
        private void HistoryNextButton_Click(object sender, EventArgs e)
        {
            HistoryOpenFile(true);
        }
        private void HistoryBackButton_Click(object sender, EventArgs e)
        {
            HistoryOpenFile(false);
        }
        protected override void OnClosed(EventArgs e)
        {
            if (parameters != null)
            {
                try
                {
                    parameters.WriteConfigFile();
                }
                catch
                {
                    MessageBox.Show("Can not write file!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
            base.OnClosed(e);
        }
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void aboutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            new AboutDlg().ShowDialog();
        }
        private void toolStripOpen_Click(object sender, EventArgs e)
        {
            OpenFile();            
        }
        private void toolStripCsv_Click(object sender, EventArgs e)
        {
            SaveCSVFile();
        }
        private void toolStripExportImg_Click(object sender, EventArgs e)
        {
            SaveGraphImage();
        }
        private void exportToCSVFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveCSVFile();
        }
        private void SaveImgToToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveGraphImage();
        }
        private void resetGraphbutton_Click(object sender, EventArgs e)
        {
            var currentPlotView = GetCurrentPlotView();
            currentPlotView.Model.ResetAllAxes();
            currentPlotView.InvalidatePlot(true);            
            ResetDetailGraphSetting();
        }
        private void DetailGraphNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            DrawDetailGraph();
        }
        private void LocusTabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            if ((monitoringContractDt == null) || (monitoringContractDt.Count() == 0))
            {
                return;
            }
            UpdateXYZLocus();
            DisplayGraphSetting();
            UpdateAxisUnitLabel();
            //Update measurement values                       
            UpdateMeasurement();
            UpdateWaveformStatus();
        }
        private void MonitoringDtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFile();
        }
        private void videoFileToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenVideo();
        }
        private void toolStripButtonOpenVideo_Click(object sender, EventArgs e)
        {
            OpenVideo();
        }
        private void toolStripButtonPlayVideo_Click(object sender, EventArgs e)
        {
            PlayVideo();
        }
        private void playVideoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PlayVideo();
        }
        private void ShowToolStripButton_Click(object sender, EventArgs e)
        {
            ShowSetting();
        }
        private void HideToolStripButton_Click(object sender, EventArgs e)
        {
            HideSetting();
        }
        private void VideoPlayerControl_PositionChange(object sender, AxWMPLib._WMPOCXEvents_PositionChangeEvent e)
        {
            VideoSeek();
        }
        private void frameByFrameToolStripButton_Click(object sender, EventArgs e)
        {
            FrameByFrameProc();
        }
        private void VideoPlayerControl_PlayStateChange(object sender, AxWMPLib._WMPOCXEvents_PlayStateChangeEvent e)
        {
            switch (e.newState)
            {
                case 0:    // Undefined
                    break;

                case 1:    // Stopped
                case 2:    // Paused   
                    toolStripButtonOpenVideo.Enabled = true;
                    toolStripOpenMonitoringDt.Enabled = true;                    
                    toolStripButtonFrameByFrame.Enabled = true;
                    toolStripButtonPlayVideo.Enabled = true;
                    toolStripButtonExtractVideo.Enabled = true;
                    tableLayoutPanelWaveformSetting.Enabled = true;
                    tableLayoutPanelLocusSetting.Enabled = true;
                    tableLayoutPanelMeasurement.Enabled = true;
                    toolStripOpenMonitoringDt.Enabled = true;
                    toolStripButtonOpenVideo.Enabled = true;
                    toolStripCsv.Enabled = true;
                    toolStripExportImg.Enabled = true;
                    timer1.Stop();
                    break;

                case 3:    // Playing                    
                    DisableAllControls();
                    toolStripOpenMonitoringDt.Enabled = false;
                    toolStripButtonOpenVideo.Enabled = false;
                    timer1.Start();
                    break;

                case 4:    // ScanForward
                    break;

                case 5:    // ScanReverse
                    break;

                case 6:    // Buffering
                    break;

                case 7:    // Waiting
                    break;

                case 8:    // MediaEnded
                    break;

                case 9:    // Transitioning
                    break;

                case 10:   // Ready
                    break;

                case 11:   // Reconnecting
                    break;

                case 12:   // Last
                    break;

                default:
                    break;
            }
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            UpdateViewerSyncVideo();
        }
        private void trackBarPictureBox_Scroll(object sender, EventArgs e)
        {
            currentFrameIndex = trackBarPictureBox.Value;
            UpdateViewerSyncPictureBox();
            UpdateXYZLocus();
        }
        private void framebyFrameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrameByFrameProc();
        }
        private void XZplotView_Click(object sender, EventArgs e)
        {
            DisplayGraphPositionSetting(sender, e);
        }

        private void XYplotView_Click(object sender, EventArgs e)
        {
            DisplayGraphPositionSetting(sender, e);
        }

        private void YZplotView_Click(object sender, EventArgs e)
        {
            DisplayGraphPositionSetting(sender, e);
        }

        private void RadiusplotView_Click(object sender, EventArgs e)
        {
            DisplayGraphPositionSetting(sender, e);
        }

        private void waveformsPlotView_Click(object sender, EventArgs e)
        {
            DisplayGraphPositionSetting(sender, e);
        }
        
        #endregion
        #region Locus Parameter event
        private void ZopNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            parameters.Zop = float.Parse($"{ZopNumericUpDown.Value}");
            UpdateXYZLocus();
        }
        private void HornLengthNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            parameters.HornLength = float.Parse($"{HornLengthNumericUpDown.Value}");
            UpdateXYZLocus();
        }
        private void OHNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            parameters.OH = float.Parse($"{OHNumericUpDown.Value}");
            UpdateXYZLocus();
        }
        private void CsAngleNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            parameters.CSAngle = float.Parse($"{CsAngleNumericUpDown.Value}");
            UpdateXYZLocus();
        }
        private void ZeNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            parameters.Ze = float.Parse($"{ZeNumericUpDown.Value}");
            UpdateXYZLocus();
        }
        private void StartPacketIDcomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var startPacketId = ushort.Parse($"{StartPacketIDcomboBox.SelectedValue}".Remove(0, 2), NumberStyles.HexNumber);
                var endPacketId = parameters.EndPackageID;
                parameters.StartPackageID = startPacketId;
                if (!CheckInputPacketID(startPacketId, endPacketId))
                {
                    var text = parameters.StartPackageID.ToString("X");
                    EndPacketIDcomboBox.SelectedIndex = EndPacketIDcomboBox.FindString(String.Concat("0x", text));
                    parameters.EndPackageID = startPacketId;
                }
                UpdateXYZLocus();
                UpdateWaveformStatus();
            }
            catch
            {

            }
        }
        private void EndPacketIDcomboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                var endPacketId = ushort.Parse($"{EndPacketIDcomboBox.SelectedValue}".Remove(0, 2), NumberStyles.HexNumber);
                var startPacketId = parameters.StartPackageID;
                parameters.EndPackageID = endPacketId;
                if (!CheckInputPacketID(startPacketId, endPacketId))
                {
                    var text = parameters.EndPackageID.ToString("X");
                    StartPacketIDcomboBox.SelectedIndex = StartPacketIDcomboBox.FindString(String.Concat("0x", text));
                    parameters.StartPackageID = endPacketId;
                }
                UpdateXYZLocus();
                UpdateWaveformStatus();
            }
            catch
            {

            }
        }
        private void comboBoxDetailGraphSetting_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBoxDetailGraphSetting.SelectedIndex == 0)
            {
                //Graph limit setting
                numericUpDownHLimit.Visible = true;
                numericUpDownVLimit.Visible = true;
                labelGraphLimit.Visible = true;
                labelGraphLimit2.Visible = true;

                //Graph position setting
                numericUpDownHDistance.Visible = false;
                numericUpDownVDistance.Visible = false;
                labelGraphPosition.Visible = false;
                labelGraphPosition2.Visible = false;
                labelHPositionHint.Visible = false;
                labelVPositionHint.Visible = false;
            }
            else
            {
                //Graph limit setting
                numericUpDownHLimit.Visible = false;
                numericUpDownVLimit.Visible = false;
                labelGraphLimit.Visible = false;
                labelGraphLimit2.Visible = false;

                //Graph position setting
                numericUpDownHDistance.Visible = true;
                numericUpDownVDistance.Visible = true;
                labelGraphPosition.Visible = true;
                labelGraphPosition2.Visible = true;
                labelHPositionHint.Visible = true;
                labelVPositionHint.Visible = true;
            }
            ResetDetailGraphSetting();
        }
        private void GeometryTraceComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            var text = GeometryTraceComboBox.Text;
            parameters.GeometryTrace = String.Equals("Oval", text, StringComparison.Ordinal) ? 0 : 1;
            UpdateXYZLocus();
        }
        #endregion
        #region Update data
        private void UpdateMeasurementSetting(int measurementAxis)
        {
            if ((monitoringContractDt == null) || (monitoringContractDt.Count() == 0))
            {
                return;
            }
            var status = HCursorCheckBox.Checked;
            var measurementStartID = (int)LocusChannel.LOCUS_HA;

            if (measurementAxis == (int)MeasurementDirection.HMeasure)
            {
                //status = HCursorCheckBox.Checked;
                //MeasurementStartID = (int)LocusChannel.LOCUS_HA;
            }
            else if (measurementAxis == (int)MeasurementDirection.VMeasure)
            {
                status = VCursorCheckBox.Checked;
                measurementStartID = (int)LocusChannel.LOCUS_VA;
            }
            else
            {
                return;
            }
            var currentPlotView = GetCurrentPlotView();
            if( currentPlotView == waveformsPlotView)
            {
                if (measurementAxis == (int)MeasurementDirection.HMeasure)
                {
                    measurementStartID = (int)WaveformChannel.WAV_HA;
                }
                else if (measurementAxis == (int)MeasurementDirection.VMeasure)
                {
                    measurementStartID = (int)WaveformChannel.WAV_VA;
                }
            }
            //Enable measurement controls
            if (measurementAxis == (int)MeasurementDirection.HMeasure)
            {
                HaNumericUpDown.Enabled = status;
                HbNumericUpDown.Enabled = status;
            }
            else if (measurementAxis == (int)MeasurementDirection.VMeasure)
            {
                VaNumericUpDown.Enabled = status;
                VbNumericUpDown.Enabled = status;
            }
            //Show measurement cursor on waveform
            var Index = measurementStartID;
            if (currentPlotView.Model != null)
            {
                for (var Idx = 0; Idx < GlobalVariable.NumberOfMeasurements / 2; Index++, Idx++) //Update horizontal axis only NUMBER_OF_MEASUREMENT/2
                {
                    currentPlotView.Model.Series[Index].IsVisible = status;
                }
                currentPlotView.InvalidatePlot(true);
            }
        }
        private void UpdateMeasurementData(int measurementAxis, int measurementCursor)
        {            
            //Determine current cursor ID (Ha, Hb, Va, Vb) and plot view (XZ, XY, YZ , Radius or waveform)
            if ((monitoringContractDt == null) || (monitoringContractDt.Count() == 0))
            {
                return;
            }
            var cursorID = (int)LocusChannel.LOCUS_HA;
            var val = double.Parse(HaNumericUpDown.Value.ToString("G"));
            if ( measurementAxis == (int)MeasurementDirection.HMeasure)
            {
                if( measurementCursor == (int)MeasurementCursor.Cursor_0)
                {
                    //CursorID = (int)LocusChannel.LOCUS_HA;
                    //Val = double.Parse(HaNumericUpDown.Value.ToString("G"));
                }
                else if (measurementCursor == (int)MeasurementCursor.Cursor_1)
                {
                    cursorID = (int)LocusChannel.LOCUS_HB;
                    val = double.Parse(HbNumericUpDown.Value.ToString("G"));
                }
            }
            else if (measurementAxis == (int)MeasurementDirection.VMeasure)
            {
                if (measurementCursor == (int)MeasurementCursor.Cursor_0)
                {
                    cursorID = (int)LocusChannel.LOCUS_VA;
                    val = double.Parse(VaNumericUpDown.Value.ToString("G"));
                }
                else if (measurementCursor == (int)MeasurementCursor.Cursor_1)
                {
                    cursorID = (int)LocusChannel.LOCUS_VB;
                    val = double.Parse(VbNumericUpDown.Value.ToString("G"));
                }
            }

            var currentPlotView = GetCurrentPlotView();
            if( currentPlotView == waveformsPlotView)
            {
                if (measurementAxis == (int)MeasurementDirection.HMeasure)
                {
                    if (measurementCursor == (int)MeasurementCursor.Cursor_0)
                    {
                        cursorID = (int)WaveformChannel.WAV_HA;
                    }
                    else if (measurementCursor == (int)MeasurementCursor.Cursor_1)
                    {
                        cursorID = (int)WaveformChannel.WAV_HB;
                    }
                }
                else if (measurementAxis == (int)MeasurementDirection.VMeasure)
                {
                    if (measurementCursor == (int)MeasurementCursor.Cursor_0)
                    {
                        cursorID = (int)WaveformChannel.WAV_VA;
                    }
                    else if (measurementCursor == (int)MeasurementCursor.Cursor_1)
                    {
                        cursorID = (int)WaveformChannel.WAV_VB;
                    }
                }
            }
            var currentGraphID = LocusTabControl.SelectedIndex;
            //Update measurement data
            var timeSeriesNew = new LineSeries();
            var listCoordData = new List<GraphCoordData>();
            var cursorMin = measurementLmt[currentGraphID].VerticalMin;
            var cursorMax = measurementLmt[currentGraphID].VerticalMax;
            if ( measurementAxis == (int)MeasurementDirection.HMeasure)
            {
                //CursorMin = measurementLmt[CurGraphID].VerticalMin;
                //CursorMax = measurementLmt[CurGraphID].VerticalMax;
            }
            else if (measurementAxis == (int)MeasurementDirection.VMeasure)
            {
                cursorMin = measurementLmt[currentGraphID].HorizontalMin;
                cursorMax = measurementLmt[currentGraphID].HorizontalMax;
            }

            timeSeriesNew.Color = ((LineSeries)currentPlotView.Model.Series[cursorID]).Color;
            timeSeriesNew.StrokeThickness = 0.1;
            timeSeriesNew.LineStyle = LineStyle.Dot;

            GraphCoordData coordData;
            for (var index = cursorMin; index < cursorMax + 0.1;)
            {
                coordData.XaxisDt = val;
                coordData.YaxisDt = index;
                if ( measurementAxis == (int)MeasurementDirection.HMeasure)
                {
                    //CoordDt.XaxisDt = Val;
                    //CoordDt.YaxisDt = index;
                }
                else if (measurementAxis == (int)MeasurementDirection.VMeasure)
                {
                    coordData.XaxisDt = index;
                    coordData.YaxisDt = val;
                }
                listCoordData.Add(coordData);
                index += 0.1;
            }

            foreach (var dt in listCoordData)
            {
                OxyPlot.DataPoint actualPoint = new OxyPlot.DataPoint(dt.XaxisDt, dt.YaxisDt);
                timeSeriesNew.Points.Add(actualPoint);
            }
            currentPlotView.Model.Series[cursorID] = timeSeriesNew;
            currentPlotView.InvalidatePlot(true);
            //Update Hb-Ha or Vb-Va
            if( measurementAxis == (int)MeasurementDirection.HMeasure)
            {
                HdeviationLabel.Text = (HbNumericUpDown.Value - HaNumericUpDown.Value).ToString("F3");
            }
            else if(measurementAxis == (int)MeasurementDirection.VMeasure)
            {
                VdeviationLabel.Text = (VbNumericUpDown.Value - VaNumericUpDown.Value).ToString("F3");
            }
        }
        private void UpdateWaveformState(int LineSeriesID)
        {
            var status = waveformChannelCheckbox[LineSeriesID].Checked;
            //controls
            waveformChannelColor[LineSeriesID].Enabled = status;
            waveformChannelScale[LineSeriesID].Enabled = status;
            waveformChannelPos[LineSeriesID].Enabled = status;
            //channel on waveform
            if ((monitoringContractDt != null) && (monitoringContractDt.Count != 0))
            {
                waveformsPlotView.Model.Series[LineSeriesID].IsVisible = status;
                waveformsPlotView.InvalidatePlot(true);
            }
        }    
        private void UpdateWaveformViewerData(int LineSeriesID)
        {
            if ((monitoringContractDt == null) || (monitoringContractDt.Count() == 0) ||(waveformsPlotView == null) || (waveformsPlotView.Model == null))
            {
                return;
            }
            var seriesNew = new LineSeries();
            var dataList = new List<GraphCoordData>();

            seriesNew.Color = waveformChannelColor[LineSeriesID].BackColor.ToOxyColor();

            for (var index = 0; index < monitoringContractDt.Count; index++)
            {
                GraphCoordData coordData;

                var deviationCoef = double.Parse(waveformChannelScale[LineSeriesID].Value.ToString("G"));
                deviationCoef /= GlobalVariable.YAxisStep;
                var movementDistance = double.Parse(waveformChannelPos[LineSeriesID].Value.ToString("G"));
                var monitoringContractData = monitoringContractDt[index];
                var deviationData = this.deviationData[index];
                var velocityData = this.velocityData[index];

                var timeCoef = double.Parse(HorizontalScaleNumericUpDown.Value.ToString("G"));                                
                timeCoef /= GlobalVariable.XAxisStep;
                
                coordData.XaxisDt = (monitoringContractData.Time) / timeCoef;
                if ((monitoringContractData.Time > timeStamp) && (timeStamp != 0.0))
                {
                    break;
                }

                var yAxisData = monitoringContractData.Xcmd;
                switch (LineSeriesID)
                {
                    case (int)WaveformChannel.WAV_XCMD:
                        yAxisData = monitoringContractData.Xcmd;
                        break;
                    case (int)WaveformChannel.WAV_YCMD:
                        yAxisData = monitoringContractData.Ycmd;
                        break;
                    case (int)WaveformChannel.WAV_ZCMD:
                        yAxisData = monitoringContractData.Zcmd;
                        break;
                    case (int)WaveformChannel.WAV_XDEVIATION:
                        yAxisData = deviationData.DeltaX;
                        break;
                    case (int)WaveformChannel.WAV_YDEVIATION:
                        yAxisData = deviationData.DeltaY;
                        break;
                    case (int)WaveformChannel.WAV_ZDEVIATION:
                        yAxisData = deviationData.DeltaZ;
                        break;
                    case (int)WaveformChannel.WAV_XVELOCITY:
                        yAxisData = velocityData.Vx;
                        break;
                    case (int)WaveformChannel.WAV_YVELOCITY:
                        yAxisData = velocityData.Vy;
                        break;
                    case (int)WaveformChannel.WAV_ZVELOCITY:
                        yAxisData = velocityData.Vz;
                        break;
                    case (int)WaveformChannel.WAV_CH1:
                        yAxisData = monitoringContractData.CH1;
                        break;
                    case (int)WaveformChannel.WAV_CH2:
                        yAxisData = monitoringContractData.CH3;
                        break;
                    case (int)WaveformChannel.WAV_CH3:
                        yAxisData = monitoringContractData.CH3;
                        break;
                    case (int)WaveformChannel.WAV_CH4:
                        yAxisData = monitoringContractData.CH4;
                        break;
                    default:
                        break;
                }
                coordData.YaxisDt = yAxisData/deviationCoef;
                coordData.YaxisDt += movementDistance;

                dataList.Add(coordData);
            }

            foreach (var dt in dataList)
            {
                OxyPlot.DataPoint actualPoint = new OxyPlot.DataPoint(dt.XaxisDt, dt.YaxisDt);
                seriesNew.Points.Add(actualPoint);
            }
            waveformsPlotView.Model.Series[LineSeriesID] = seriesNew;
            waveformsPlotView.InvalidatePlot(true);
        }
        private void UpdateRadiusGraph()
        {
            if ((monitoringContractDt == null) || (monitoringContractDt.Count() == 0) || (RadiusplotView == null) || (RadiusplotView.Model == null))
            {
                return;
            }
            for (var idx = 0; idx < GlobalVariable.NumberOfLocusSeries; idx++)
            {
                var seriesNew = new LineSeries();
                var dataList = new List<GraphCoordData>();
                GraphCoordData coordData;
                var index = 0;
                switch (idx)
                {                    
                    case (int)LocusChannel.LOCUS_CMD:
                    case (int)LocusChannel.LOCUS_ENC:
                        coordData.XaxisDt = rotateData[0].ThetaCmd;
                        coordData.YaxisDt = rotateData[0].Rcmd;
                        foreach (var row in rotateData)
                        {
                            var time = monitoringContractDt[index].Time;
                            if ((time > timeStamp) && (timeStamp != 0.0))
                            {
                                break;
                            }
                            coordData.XaxisDt = row.ThetaCmd;
                            coordData.YaxisDt = row.Rcmd;

                            if( idx == (int)LocusChannel.LOCUS_CMD)
                            {
                                seriesNew.Color = OxyColors.Blue;
                                seriesNew.Title = "Command";
                                coordData.XaxisDt = row.ThetaCmd;
                                coordData.YaxisDt = row.Rcmd;
                            }
                            else if (idx == (int)LocusChannel.LOCUS_ENC)
                            {
                                seriesNew.Color = OxyColors.Red;
                                seriesNew.Title = "Actual";
                                coordData.XaxisDt = row.ThetaEnc;
                                coordData.YaxisDt = row.Renc;
                            }
                            dataList.Add(coordData);
                            index++;
                        }                        
                        break;
                    case (int)LocusChannel.LOCUS_GEO:                        
                        coordData.XaxisDt = geometryData[0].ThetaG;
                        coordData.YaxisDt = geometryData[0].Rg;
                        foreach (var row in geometryData)
                        {
                            var time = monitoringContractDt[index].Time;
                            if ((time > timeStamp) && (timeStamp != 0.0))
                            {
                                break;
                            }
                            if (idx == (int)LocusChannel.LOCUS_GEO)
                            {                               
                                seriesNew.IsVisible = true;
                                seriesNew.Color = OxyColors.Green;
                                seriesNew.Title = "Geometry";
                                coordData.XaxisDt = row.ThetaG;
                                coordData.YaxisDt = row.Rg;
                            }
                            dataList.Add(coordData);
                            index++;
                        }                        
                        break;
                    default:
                        break;
                }

                foreach (var dt in dataList)
                {
                    OxyPlot.DataPoint actualPoint = new OxyPlot.DataPoint(dt.XaxisDt, dt.YaxisDt);
                    seriesNew.Points.Add(actualPoint);
                }
                RadiusplotView.Model.Series[idx] = seriesNew;
            }
            RadiusplotView.InvalidatePlot(true);
        }
        private void UpdateLocusGraph()
        {
            if ((monitoringContractDt == null) || (monitoringContractDt.Count() == 0))
            {
                return;
            }
            var PlotV = GetCurrentPlotView();
            if( (PlotV == null) || (PlotV.Model == null) )
            {
                return;
            }

            for (var idx = 0; idx < GlobalVariable.NumberOfLocusSeries; idx++)
            {
                var seriresNew = new LineSeries();
                var dataList = new List<GraphCoordData>();
                if (idx == (int)LocusChannel.LOCUS_CMD)
                {
                    seriresNew.Color = OxyColors.Blue;
                    seriresNew.Title = "Command";
                }
                else if (idx == (int)LocusChannel.LOCUS_ENC)
                {
                    seriresNew.Color = OxyColors.Red;
                    seriresNew.Title = "Actual";
                }
                else if (idx == (int)LocusChannel.LOCUS_GEO)
                {
                   seriresNew.IsVisible = false;
                }
                var currentGraphID = LocusTabControl.SelectedIndex;
                for (var index = 0; index < monitoringContractDt.Count; index++)
                {
                    GraphCoordData CoordDt;
                    var MonitorContractDt = monitoringContractDt[index];
                    if ((MonitorContractDt.Time > timeStamp) && (timeStamp != 0.0))
                    {
                        break;
                    }
                    CoordDt.XaxisDt = MonitorContractDt.Xcmd;
                    CoordDt.YaxisDt = MonitorContractDt.Zcmd;

                    switch (currentGraphID)
                    {
                        case (int)GraphID.XZ:
                            if (idx == (int)LocusChannel.LOCUS_CMD)
                            {
                                CoordDt.XaxisDt = MonitorContractDt.Xcmd;
                                CoordDt.YaxisDt = MonitorContractDt.Zcmd;
                            }
                            else if (idx == (int)LocusChannel.LOCUS_ENC)
                            {
                                CoordDt.XaxisDt = MonitorContractDt.Xenc;
                                CoordDt.YaxisDt = MonitorContractDt.Zenc;
                            }

                            break;
                        case (int)GraphID.XY:
                            if (idx == (int)LocusChannel.LOCUS_CMD)
                            {
                                CoordDt.XaxisDt = MonitorContractDt.Xcmd;
                                CoordDt.YaxisDt = MonitorContractDt.Ycmd;
                            }
                            else if (idx == (int)LocusChannel.LOCUS_ENC)
                            {
                                CoordDt.XaxisDt = MonitorContractDt.Xenc;
                                CoordDt.YaxisDt = MonitorContractDt.Yenc;
                            }
                            break;
                        case (int)GraphID.YZ:
                            if (idx == (int)LocusChannel.LOCUS_CMD)
                            {
                                CoordDt.XaxisDt = MonitorContractDt.Ycmd;
                                CoordDt.YaxisDt = MonitorContractDt.Zcmd;
                            }
                            else if (idx == (int)LocusChannel.LOCUS_ENC)
                            {
                                CoordDt.XaxisDt = MonitorContractDt.Yenc;
                                CoordDt.YaxisDt = MonitorContractDt.Zenc;
                            }
                            break;
                        default:
                            break;
                    }

                    dataList.Add(CoordDt);                    
                }

                var XaxisDt = dataList.Select(graphDt => graphDt.XaxisDt);
                var YaxisDt = dataList.Select(graphDt => graphDt.YaxisDt);
                UpdateMeasurementLimit(XaxisDt, YaxisDt, currentGraphID);

                foreach (var dt in dataList)
                {
                    OxyPlot.DataPoint actualPoint = new OxyPlot.DataPoint(dt.XaxisDt, dt.YaxisDt);
                    seriresNew.Points.Add(actualPoint);
                }
                PlotV.Model.Series[idx] = seriresNew;
            }
            PlotV.InvalidatePlot(true);
        }
        private void UpdateAxisUnitLabel()
        {
            VaUnitLabel.Text        = "(µm)";
            VbUnitLabel.Text        = "(µm)";
            VDistanceUnitLabel.Text = "(µm)";
            switch (LocusTabControl.SelectedIndex)
            {
                case (int)GraphID.XZ://XZ
                case (int)GraphID.XY://XY
                case (int)GraphID.YZ://YZ
                    HorizontalScaleUnitLabel.Text = "(µm)";
                    HaUnitLabel.Text = "(µm)";
                    HbUnitLabel.Text = "(µm)";
                    HDistanceUnitLabel.Text = "(µm)";
                    break;
                case (int)GraphID.RADIUS://Radius
                    HorizontalScaleUnitLabel.Text   = "(deg)";
                    HaUnitLabel.Text                = "(deg)";
                    HbUnitLabel.Text                = "(deg)";
                    HDistanceUnitLabel.Text         = "(deg)";
                    break;
                case (int)GraphID.WAVEFORM://Waveform
                    HorizontalScaleUnitLabel.Text   = "(ms)";
                    HaUnitLabel.Text                = "(ms)";
                    HbUnitLabel.Text                = "(ms)";
                    HDistanceUnitLabel.Text         = "(ms)";
                    break;
                default:
                    break;
            }
        }
        private void UpdateAllLocusPosition()
        {
            var HDistance = double.Parse(numericUpDownHDistance.Value.ToString("G"));
            var VDistance = double.Parse(numericUpDownVDistance.Value.ToString("G"));
            
            UpdateLocusPosition(XYplotView, HDistance, VDistance);
            UpdateLocusPosition(XZplotView, HDistance, VDistance);
            UpdateLocusPosition(YZplotView, HDistance, VDistance);            
        }
        private void UpdateLocusPosition(PlotView plotV, double HDistance, double VDistance)
        {
            if( (plotV == null) || (plotV.Model == null))
            {
                return;
            }
            var p = ((LineSeries)plotV.Model.Series[0]).Points[0];

            var xAxis = plotV.Model.Axes[0];
            var yAxis = plotV.Model.Axes[1];

            var currentScreenPoint = new ScreenPoint();
            currentScreenPoint = xAxis.Transform(p.X, p.Y,yAxis);

            var newScreenPoint = new ScreenPoint();
            newScreenPoint = xAxis.Transform(p.X + HDistance, p.Y + VDistance, yAxis);

            var actualHDistance = newScreenPoint.X - currentScreenPoint.X;
            var actualVDistance = newScreenPoint.Y - currentScreenPoint.Y;

            plotV.Model.ResetAllAxes();
            plotV.Model.PanAllAxes(actualHDistance, actualVDistance);
            plotV.InvalidatePlot(true);
        }
        private void UpdateMeasurement()
        {            
            //Update measurement values                       
            if (HCursorCheckBox.Checked == true)
            {
                UpdateMeasurementSetting((int)MeasurementDirection.HMeasure);
                UpdateMeasurementData((int)MeasurementDirection.HMeasure, (int)MeasurementCursor.Cursor_0);
                UpdateMeasurementData((int)MeasurementDirection.HMeasure, (int)MeasurementCursor.Cursor_1);
            }
            if (VCursorCheckBox.Checked == true)
            {
                UpdateMeasurementSetting((int)MeasurementDirection.VMeasure);
                UpdateMeasurementData((int)MeasurementDirection.VMeasure, (int)MeasurementCursor.Cursor_0);
                UpdateMeasurementData((int)MeasurementDirection.VMeasure, (int)MeasurementCursor.Cursor_1);
            }
        }
        #endregion
        #region History process
        private void HistoryOpenFile(bool NextFlag)
        {
            if ((monitoringContractDt == null) || (monitoringContractDt.Count() == 0))
            {
                return;
            }
            var currentDirectory = Path.GetDirectoryName(inputFilePath);
            var inputFiles = Directory.GetFiles(currentDirectory, "*.monitoringdata");
            var currentFileIndex = Array.IndexOf(inputFiles, inputFilePath);
            var openFileIndex = currentFileIndex;
            //Open next file in directory
            if (NextFlag == true)
            {
                openFileIndex++;
            }
            //Open previous file in directory
            else
            {
                openFileIndex--;
            }
            if ((openFileIndex >= 0) && (openFileIndex < inputFiles.Count()))
            {
                ReadInputFile(inputFiles[openFileIndex]);
                UpdateXYZLocus();
            }
        }
        #endregion
        #region Others
        private void ResetDetailGraphSetting()
        {
            //Reset distance setting
            numericUpDownHDistance.Value = 0;
            numericUpDownVDistance.Value = 0;
            numericUpDownHDistance.Enabled = true;
            numericUpDownVDistance.Enabled = true;
            //Reset limit setting
            numericUpDownHLimit.Value = 0;
            numericUpDownVLimit.Value = 0;
            numericUpDownHLimit.Enabled = true;
            numericUpDownVLimit.Enabled = true;
        }
        private void DetailGraphSet(PlotView plotV)
        {
            if ((monitoringContractDt == null) || (monitoringContractDt.Count() == 0))
            {
                return;
            }
            var horizontalDetailMax = double.Parse(numericUpDownHLimit.Value.ToString("G"));
            var verticalDetailMax = double.Parse(numericUpDownVLimit.Value.ToString("G"));

            //Draw for XZ, XY and YZ detail graphs
            var xAxis = plotV.Model.Axes[0];
            var yAxis = plotV.Model.Axes[1];
            if ((horizontalDetailMax != 0) || (verticalDetailMax != 0))
            {
                plotV.Model.PlotType = PlotType.XY;
                if (horizontalDetailMax != 0)
                {
                    xAxis.Minimum = -horizontalDetailMax;
                    xAxis.Maximum = horizontalDetailMax;
                }
                if (verticalDetailMax != 0)
                {
                    yAxis.Minimum = -verticalDetailMax;
                    yAxis.Maximum = verticalDetailMax;
                }
            }
            else
            {
                plotV.Model.PlotType = PlotType.Cartesian;
            }
        }
        private void AddDtToGraph(PlotView plot, LineSeries[] locusSeries, List<GraphCoordData>[] locusAxis)
        {
            for (var index = 0; index < locusSeries.Count(); index++)
            {
                foreach (var dt in locusAxis[index])
                {
                    OxyPlot.DataPoint actualPoint = new OxyPlot.DataPoint(dt.XaxisDt, dt.YaxisDt);
                    locusSeries[index].Points.Add(actualPoint);
                }
                plot.Model.Series.Add(locusSeries[index]);
            }
        }
        private void AddMeasurementDtToGraph(List<GraphCoordData>[] coordData, int horizontalAIndex, int horizontalBIndex, int verticalAIndex, int verticalBIndex, int graphID)
        {            
            var horizontalAValue = double.Parse(HaNumericUpDown.Value.ToString("G"));
            var horizontalBValue = double.Parse(HbNumericUpDown.Value.ToString("G"));
            var verticalMax = measurementLmt[graphID].VerticalMax;
            var verticalMin = measurementLmt[graphID].VerticalMin;
            var horizontalMax = measurementLmt[graphID].HorizontalMax;
            var horizontalMin = measurementLmt[graphID].HorizontalMin;
            //Waveform uses default measurement limits, no need to update
            if(graphID == (int)GraphID.WAVEFORM)
            {
                verticalMax     = GlobalVariable.WaveformVMax;
                verticalMin     = GlobalVariable.WaveformVMin;
                horizontalMax   = GlobalVariable.WaveformHMax;
                horizontalMin   = GlobalVariable.WaveformHMin;
            }
            //Horizontal measurement
            for (var index = verticalMin; index < verticalMax + 0.1;)
            {                
                GraphCoordData horizontalAData;
                horizontalAData.XaxisDt = horizontalAValue;
                horizontalAData.YaxisDt = index;
                coordData[horizontalAIndex].Add(horizontalAData);
                                
                GraphCoordData horizontalBData;
                horizontalBData.XaxisDt = horizontalBValue;
                horizontalBData.YaxisDt = index;
                coordData[horizontalBIndex].Add(horizontalBData);
                index += 0.1;
            }
            //Vertical measurement
            var verticalAValue = double.Parse(VaNumericUpDown.Value.ToString("G"));
            var verticalBValue = double.Parse(VbNumericUpDown.Value.ToString("G"));
            for (var index = horizontalMin; index < horizontalMax + 0.1;)
            {                
                GraphCoordData verticalAData;
                verticalAData.XaxisDt = index;
                verticalAData.YaxisDt = verticalAValue;
                coordData[verticalAIndex].Add(verticalAData);
                
                GraphCoordData verticalBData;
                verticalBData.XaxisDt = index;
                verticalBData.YaxisDt = verticalBValue;
                coordData[verticalBIndex].Add(verticalBData);
                index += 0.1;
            }
        }
        private void UpdateMeasurementLimit(IEnumerable<double> XaxisDt, IEnumerable<double> YaxisDt, int graphID)
        {
            //Waveform uses default measurement limits, no need to update
            var HorizontalMaxLmt = measurementLmt[graphID].HorizontalMax;
            var HorizontalMinLmt = measurementLmt[graphID].HorizontalMin;
            var VerticalMaxLmt = measurementLmt[graphID].VerticalMax;
            var VerticalMinLmt = measurementLmt[graphID].VerticalMin;
            //Waveform uses default measurement limits, no need to update
            if (graphID == (int)GraphID.WAVEFORM)
            {
                measurementLmt[graphID].HorizontalMax = GlobalVariable.WaveformHMax;
                measurementLmt[graphID].HorizontalMin = GlobalVariable.WaveformHMin;
                measurementLmt[graphID].VerticalMax = GlobalVariable.WaveformVMax;
                measurementLmt[graphID].VerticalMin = GlobalVariable.WaveformVMin;
                return;
            }
            var Xmax = XaxisDt.Max();
            var Xmin = XaxisDt.Min();
            var Ymax = YaxisDt.Max();
            var Ymin = YaxisDt.Min();
            if (Xmax > HorizontalMaxLmt)
            {
                HorizontalMaxLmt = Xmax;
            }
            if (Xmin < HorizontalMinLmt)
            {
                HorizontalMinLmt = Xmin;
            }
            if (Ymax > VerticalMaxLmt)
            {
                VerticalMaxLmt = Ymax;
            }
            if (Ymin < VerticalMinLmt)
            {
                VerticalMinLmt = Ymin;
            }

            measurementLmt[graphID].HorizontalMax = HorizontalMaxLmt;
            measurementLmt[graphID].HorizontalMin = HorizontalMinLmt;
            measurementLmt[graphID].VerticalMax = VerticalMaxLmt;
            measurementLmt[graphID].VerticalMin = VerticalMinLmt;
        }
        private void UpdateWaveformStatus()
        {
            var MeasurementStartID = (int)LocusChannel.LOCUS_HA;
            //Update graph status
            var currentPlotView = GetCurrentPlotView();
            if( currentPlotView == waveformsPlotView)
            {
                MeasurementStartID = (int)WaveformChannel.WAV_HA;
                if ((monitoringContractDt != null) && (monitoringContractDt.Count() != 0) && (currentPlotView.Model != null))
                {
                    for (var index = 0; index < GlobalVariable.NumberOfChannels; index++)
                    {
                        currentPlotView.Model.Series[index].IsVisible = waveformChannelCheckbox[index].Checked;
                    }
                    waveformsPlotView.InvalidatePlot(true);
                }
            }
            //Update state for measurement
            if ((monitoringContractDt != null) && (monitoringContractDt.Count() != 0) && (currentPlotView.Model != null))
            {
                var index = MeasurementStartID;
                if (currentPlotView.Model != null)
                {
                    for (var idx = 0; idx < GlobalVariable.NumberOfMeasurements; index++, idx++)
                    {
                        if ((index == (int)LocusChannel.LOCUS_HA) || (index == (int)LocusChannel.LOCUS_HB) || (index == (int)WaveformChannel.WAV_HA) || (index == (int)WaveformChannel.WAV_HB))
                        {
                            currentPlotView.Model.Series[index].IsVisible = measurementCheckbox[(int)MeasurementDirection.HMeasure].Checked;
                        }
                        else if ((index == (int)LocusChannel.LOCUS_VA) || (index == (int)LocusChannel.LOCUS_VB) || (index == (int)WaveformChannel.WAV_VA) || (index == (int)WaveformChannel.WAV_VB))
                        {
                            currentPlotView.Model.Series[index].IsVisible = measurementCheckbox[(int)MeasurementDirection.VMeasure].Checked;
                        }
                        else
                        {
                            /* nothing */
                        }

                    }
                    waveformsPlotView.InvalidatePlot(true);
                }
            }            
        }
        private void UpdateWaveFormsColor(int SeriesID)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                waveformChannelColor[SeriesID].BackColor = colorDialog1.Color;
                ((LineSeries)waveformsPlotView.Model.Series[SeriesID]).Color = colorDialog1.Color.ToOxyColor();
                waveformsPlotView.InvalidatePlot(true);
            }
        }
        private void DisableAllControls()
        {
            toolToolStripMenuItem.Enabled = false;
            toolStripExportImg.Enabled = false;
            toolStripCsv.Enabled = false;
            toolStripButtonPlayVideo.Enabled = false;
            toolStripButtonFrameByFrame.Enabled = false;
            toolStripButtonExtractVideo.Enabled = false;

            //Measurement
            tableLayoutPanelMeasurement.Enabled = false;

            //Waveform settting
            tableLayoutPanelWaveformSetting.Enabled = false;
            //Locus setting
            tableLayoutPanelLocusSetting.Enabled = false;
        }
        private void EnableAllControls()
        {
            toolStripCsv.Enabled            = true;            
            toolStripExportImg.Enabled      = true;
            toolToolStripMenuItem.Enabled   = true;            
            resetGraphbutton.Enabled        = true;
            HistoryNextButton.Enabled       = historyNextBtnState;
            HistoryBackButton.Enabled       = historyBackBtnState;
            //Measurement
            tableLayoutPanelMeasurement.Enabled = true;
            if (HCursorCheckBox.Checked == true)
            {
                HaNumericUpDown.Enabled = true;
                HbNumericUpDown.Enabled = true;
            }
            if (VCursorCheckBox.Checked == true)
            {
                VaNumericUpDown.Enabled = true;
                VbNumericUpDown.Enabled = true;
            }
            //Waveform settting
            tableLayoutPanelWaveformSetting.Enabled = true;

            //Locus setting
            tableLayoutPanelLocusSetting.Enabled = true;
        }
        private void ShowLocusSetting()
        {
            tableLayoutPanelLocusSetting.Visible = true;
        }
        private void HideLocusSetting()
        {
            tableLayoutPanelLocusSetting.Visible = false;  
        }        
        private void ShowWaveformSetting()
        {
            HorizontalScaleNumericUpDown.Visible = true;
            HorizontalScaleUnitLabel.Visible = true;
            HorizontalScaleLabel.Visible = true;
            tableLayoutPanelWaveformSetting.Visible = true;            
        }
        private void HideWaveformSetting()
        {
            HorizontalScaleNumericUpDown.Visible = false;
            HorizontalScaleUnitLabel.Visible = false;
            HorizontalScaleLabel.Visible = false;
            tableLayoutPanelWaveformSetting.Visible = false;
        }
        private void ShowDetailGraphSetting()
        {
            HDetailGraphLabel.Visible = true;
            VDetailGraphLabel.Visible = true;
            labelDetailGraphSetting.Visible = true;
            comboBoxDetailGraphSetting.Visible = true;
            labelDetailSettingNote.Visible = true;
            if (comboBoxDetailGraphSetting.SelectedIndex == 0)
            {
                //Graph limit setting
                numericUpDownHLimit.Visible = true;
                numericUpDownVLimit.Visible = true;
                labelGraphLimit.Visible = true;
                labelGraphLimit2.Visible = true;
 
                //Graph position setting
                numericUpDownHDistance.Visible = false;
                numericUpDownVDistance.Visible = false;
                labelGraphPosition.Visible = false;
                labelGraphPosition2.Visible = false;
                labelHPositionHint.Visible = false;
                labelVPositionHint.Visible = false;
            }
            else
            {
                //Graph limit setting
                numericUpDownHLimit.Visible = false;
                numericUpDownVLimit.Visible = false;
                labelGraphLimit.Visible = false;
                labelGraphLimit2.Visible = false;

                //Graph position setting
                numericUpDownHDistance.Visible = true;
                numericUpDownVDistance.Visible = true;
                labelGraphPosition.Visible = true;
                labelGraphPosition2.Visible = true;
                labelHPositionHint.Visible = true;
                labelVPositionHint.Visible = true;
            }
        }
        private void HideDetailGraphSetting()
        {
            HDetailGraphLabel.Visible = false;
            VDetailGraphLabel.Visible = false;
            labelDetailGraphSetting.Visible = false;
            comboBoxDetailGraphSetting.Visible = false;
            labelDetailSettingNote.Visible = false;
            //Graph limit setting
            numericUpDownHLimit.Visible = false;
            numericUpDownVLimit.Visible = false;            
            labelGraphLimit.Visible = false;
            labelGraphLimit2.Visible = false;
            //Graph position setting
            numericUpDownHDistance.Visible = false;
            numericUpDownVDistance.Visible = false;            
            labelGraphPosition.Visible = false;
            labelGraphPosition2.Visible = false;
            labelHPositionHint.Visible = false;
            labelVPositionHint.Visible = false;
        }
        private PlotView GetCurrentPlotView()
        {
            var currentPlotView = XZplotView;
            switch (LocusTabControl.SelectedIndex)
            {
                case (int)GraphID.XZ: //XZ      
                    currentPlotView = XZplotView;
                    break;
                case (int)GraphID.XY: //XY                                                            
                    currentPlotView = XYplotView;
                    break;
                case (int)GraphID.YZ: //YZ         
                    currentPlotView = YZplotView;
                    break;
                case (int)GraphID.RADIUS: //Radius    
                    currentPlotView = RadiusplotView;
                    break;
                case (int)GraphID.WAVEFORM: //Waveform                    
                    currentPlotView = waveformsPlotView;
                    break;
                default:
                    break;
            }
            return currentPlotView;
        }
        private void DisplayGraphPositionSetting(object sender, EventArgs e)
        {
            MouseEventArgs mouseEvent = (MouseEventArgs)e;
            if(mouseEvent.Button == MouseButtons.Left)
            {
                numericUpDownHDistance.Enabled = false;
                numericUpDownVDistance.Enabled = false;
            }
        }
        #endregion
        #region Drag and Drop event
        private void RadiusplotView_DragDrop(object sender, DragEventArgs e)
        {
            DragDropFile(e);
        }

        private void RadiusplotView_DragEnter(object sender, DragEventArgs e)
        {
            DragEnterFile(e);
        }

        private void XZplotView_DragDrop(object sender, DragEventArgs e)
        {
            DragDropFile(e);
        }

        private void XZplotView_DragEnter(object sender, DragEventArgs e)
        {
            DragEnterFile(e);
        }

        private void tabControl_DragDrop(object sender, DragEventArgs e)
        {
            DragDropFile(e);
        }

        private void tabControl_DragEnter(object sender, DragEventArgs e)
        {
            DragEnterFile(e);
        }

        private void YZplotView_DragDrop(object sender, DragEventArgs e)
        {
            DragDropFile(e);
        }

        private void YZplotView_DragEnter(object sender, DragEventArgs e)
        {
            DragEnterFile(e);
        }
        private void waveformsPlotView_DragDrop(object sender, DragEventArgs e)
        {
            DragDropFile(e);
        }

        private void waveformsPlotView_DragEnter(object sender, DragEventArgs e)
        {
            DragEnterFile(e);
        }
        #endregion
        #region Change waveforms color event
        private void XcmdColorButton_Click(object sender, EventArgs e)
        {
            UpdateWaveFormsColor((int)WaveformChannel.WAV_XCMD);
        }

        private void YcmdColorButton_Click(object sender, EventArgs e)
        {
            UpdateWaveFormsColor((int)WaveformChannel.WAV_YCMD);
        }

        private void ZcmdColorButton_Click(object sender, EventArgs e)
        {
            UpdateWaveFormsColor((int)WaveformChannel.WAV_ZCMD);
        }

        private void XdeviationColorButton_Click(object sender, EventArgs e)
        {
            UpdateWaveFormsColor((int)WaveformChannel.WAV_XDEVIATION);
        }

        private void YdeviationColorButton_Click(object sender, EventArgs e)
        {
            UpdateWaveFormsColor((int)WaveformChannel.WAV_YDEVIATION);
        }

        private void ZdeviationColorButton_Click(object sender, EventArgs e)
        {
            UpdateWaveFormsColor((int)WaveformChannel.WAV_ZDEVIATION);
        }

        private void VxColorButton_Click(object sender, EventArgs e)
        {
            UpdateWaveFormsColor((int)WaveformChannel.WAV_XVELOCITY);
        }

        private void VyColorButton_Click(object sender, EventArgs e)
        {
            UpdateWaveFormsColor((int)WaveformChannel.WAV_YVELOCITY);
        }

        private void VzColorButton_Click(object sender, EventArgs e)
        {
            UpdateWaveFormsColor((int)WaveformChannel.WAV_ZVELOCITY);
        }
        private void Ch1ColorButton_Click(object sender, EventArgs e)
        {
            UpdateWaveFormsColor((int)WaveformChannel.WAV_CH1);
        }
        private void Ch2ColorButton_Click(object sender, EventArgs e)
        {
            UpdateWaveFormsColor((int)WaveformChannel.WAV_CH2);
        }
        private void Ch3ColorButton_Click(object sender, EventArgs e)
        {
            UpdateWaveFormsColor((int)WaveformChannel.WAV_CH3);
        }
        private void Ch4ColorButton_Click(object sender, EventArgs e)
        {
            UpdateWaveFormsColor((int)WaveformChannel.WAV_CH4);
        }

        #endregion
        #region Update measurement event
        private void HaNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateMeasurementData((int)MeasurementDirection.HMeasure, (int)MeasurementCursor.Cursor_0);
        }
        private void HbNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateMeasurementData((int)MeasurementDirection.HMeasure, (int)MeasurementCursor.Cursor_1);
        }
        private void VaNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateMeasurementData((int)MeasurementDirection.VMeasure, (int)MeasurementCursor.Cursor_0);
        }
        private void VbNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateMeasurementData((int)MeasurementDirection.VMeasure, (int)MeasurementCursor.Cursor_1);
        }
        #endregion
        #region waveform checkboxes state changed event
        private void XcmdCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            UpdateWaveformState((int)WaveformChannel.WAV_XCMD);
        }
        private void YcmdCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            UpdateWaveformState((int)WaveformChannel.WAV_YCMD);
        }
        private void ZcmdCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            UpdateWaveformState((int)WaveformChannel.WAV_ZCMD);
        }
        private void XdeviationCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            UpdateWaveformState((int)WaveformChannel.WAV_XDEVIATION);
        }
        private void YdeviationCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            UpdateWaveformState((int)WaveformChannel.WAV_YDEVIATION);
        }
        private void ZdeviationCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            UpdateWaveformState((int)WaveformChannel.WAV_ZDEVIATION);
        }
        private void VxCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            UpdateWaveformState((int)WaveformChannel.WAV_XVELOCITY);
        }
        private void VyCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            UpdateWaveformState((int)WaveformChannel.WAV_YVELOCITY);
        }
        private void VzCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            UpdateWaveformState((int)WaveformChannel.WAV_ZVELOCITY);
        }
        private void Ch1CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            UpdateWaveformState((int)WaveformChannel.WAV_CH1);
        }
        private void Ch2CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            UpdateWaveformState((int)WaveformChannel.WAV_CH2);
        }

        private void Ch3CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            UpdateWaveformState((int)WaveformChannel.WAV_CH3);
        }

        private void Ch4CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            UpdateWaveformState((int)WaveformChannel.WAV_CH4);
        }
        private void HMeasureCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            UpdateMeasurementSetting((int)MeasurementDirection.HMeasure);
        }
        private void VMeasureCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            UpdateMeasurementSetting((int)MeasurementDirection.VMeasure);
        }
        #endregion
        #region Waveform position changed event
        private void XcmdPosNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_XCMD);
        }
        private void YcmdPosNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_YCMD);
        }
        private void ZcmdPosNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_ZCMD);
        }
        private void XdeviationPosNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_XDEVIATION);
        }
        private void YdeviationPosNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_YDEVIATION);
        }
        private void ZdeviationPosNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_ZDEVIATION);
        }
        private void VxPosNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_XVELOCITY);
        }
        private void VyPosNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_YVELOCITY);
        }
        private void VzPosNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_ZVELOCITY);
        }
        private void Ch1PosNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_CH1);
        }
        private void Ch2PosNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_CH2);
        }
        private void Ch3PosNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_CH3);
        }
        private void Ch4PosNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_CH4);
        }

        #endregion
        #region Waveform channel scales event
        private void XcmdScalenumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_XCMD);
        }

        private void YcmdScalenumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_YCMD);
        }

        private void ZcmdScalenumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_ZCMD);
        }

        private void XdeviationScalenumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_XDEVIATION);
        }

        private void YdeviationScalenumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_YDEVIATION);
        }

        private void ZdeviationScalenumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_ZDEVIATION);
        }

        private void VxScalenumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_XVELOCITY);
        }

        private void VyScalenumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_YVELOCITY);
        }

        private void VzScalenumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_ZVELOCITY);
        }
        private void Ch1ScalenumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_CH1);
        }
        private void Ch2ScalenumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_CH2);
        }
        private void Ch3ScalenumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_CH3);
        }
        private void Ch4ScalenumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            UpdateWaveformViewerData((int)WaveformChannel.WAV_CH4);
        }
        private void HorizontalScaleNumericUpDown_ValueChanged(object sender, EventArgs e)
        {
            if (LocusTabControl.SelectedIndex == (int)GraphID.WAVEFORM)
            {
                for (var index = 0; index < GlobalVariable.NumberOfChannels; index++)
                {
                    if (waveformChannelCheckbox[index].Checked == true)
                    {
                        UpdateWaveformViewerData(index);
                    }
                }
            }
        }
        private void numericUpDownDistance_ValueChanged(object sender, EventArgs e)
        {
            UpdateAllLocusPosition();
        }
        #endregion
        #region Video and image processing
        private void ResetFrameViewer()
        {
            toolStripButtonPlayVideo.Enabled = true;
            toolStripButtonFrameByFrame.Enabled = true;
            toolStripButtonExtractVideo.Enabled = true;
            //Reset trackBar cursor to 0
            trackBarPictureBox.Value = 0;
            currentFrameIndex = 0;
            labelCurrentFramePicturebox.Text = "Current frame: " + 0;
            labelCurrentFrameVideo.Text = "Current frame: " + 0;
            if ((extractedFrameImage != null) && (extractedFrameImage.Count() != 0))
            {
                Image img = Image.FromFile(extractedFrameImage[0]);
                pictureBoxFrameByFrame.Image = img;
            }
        }
        private void OpenVideo()
        {            
            try {
                videoOpenFileDialog.FileName = videoFilePath;
                //Open input file (.MonitoringData file)
                if (videoOpenFileDialog.ShowDialog() == DialogResult.OK)
                {   
                    videoFilePath = videoOpenFileDialog.FileName;
                    VideoFileToolStripStatusLabel.Text = videoFilePath;
                    CollectVideoInfo();

                    var imgFilePath = Path.GetDirectoryName(videoFilePath);
                    imgFilePath += @"\Image";

                    if (Directory.Exists(imgFilePath) == true)
                    {
                        GetImageData();
                    }
                    else
                    {
                        ExtractVideoToFrameImages();
                    }
                }
            }
            catch
            {
                MessageBox.Show("Can not open video file!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
         }
        private void CollectVideoInfo()
        {
            try {
                var VideoInfoFilePath = videoFilePath.Replace(".wmv", ".cih");
                string[] str = System.IO.File.ReadAllLines(VideoInfoFilePath);
                foreach (string line in str)
                {
                    //Read frame rate from .cih file
                    if (line.Contains("(fps)"))
                    {
                        cameraFrameRate = int.Parse(Regex.Match(line, @"\d+").Value);
                        labelCameraFrameRate.Text = line;                     
                    }
                    //Read number of frame from file
                    else if (line.Contains("Total Frame"))
                    {
                        numberOfFrame = int.Parse(Regex.Match(line, @"\d+").Value);
                        trackBarPictureBox.Maximum = numberOfFrame;
                        labelTotalFrameVideo.Text = line;
                        labelTotalFramePicturebox.Text = line;
                    }
                }
            }
            catch
            {
                MessageBox.Show("Can not read Video information from .cih file!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
             
        }
        private void PlayVideo()
        {
            tableLayoutPanelVideo.Visible = true;
            tableLayoutPanelPictureBox.Visible = false;
            VideoPlayerControl.URL = videoFilePath;
            try {
                this.Enabled = false;
                progressBar.Enabled = true;
                progressBar.Visible = true;
                labelOperatingProgress.Visible = true;
                labelOperatingProgress.Enabled = true;
                VideoPlayerControl.settings.autoStart = true;
            }
            finally
            {
                progressBar.Visible = false;
                this.Enabled = true;
                labelOperatingProgress.Visible = false;
            }
        }
        private void VideoSeek()
        {
            if ((VideoPlayerControl.playState == WMPPlayState.wmppsPaused) ||
                (VideoPlayerControl.playState == WMPPlayState.wmppsStopped))
            {
                /* Because window media player does not have the feature that using "seek" function on slide while pausing or stopping, so that here is a treat to process "seek" function in this case.
                1. While being "stop" or "pause" state, change video player becomes "play" state in order to play to current position on seek slider.
                2. After "play" to current position on seek slider, return back to "pause" position immediately.
                => It looks like seeking function on slider. */                
                VideoPlayerControl.Ctlcontrols.play();                
                VideoPlayerControl.Ctlcontrols.pause();
                //Update locus and waveform
                UpdateViewerSyncVideo();
            }
        }
        private void UpdateViewerSyncVideo()
        {
            if (VideoPlayerControl.network.encodedFrameRate != 0)
            {
                var videoPlayerFrameRate = VideoPlayerControl.network.encodedFrameRate;
                var currentPosition = VideoPlayerControl.Ctlcontrols.currentPosition;
                var currentFrameNum = (int)(currentPosition * videoPlayerFrameRate);

                labelVideoPlayerFrameRate.Text = "Video player frame rate (fps) :" + videoPlayerFrameRate;
                labelCurrentFrameVideo.Text = "Current frame: " + currentFrameNum.ToString();
                timeStamp = currentFrameNum*1.0 / cameraFrameRate;
                timeStamp *= GlobalVariable.SecondToMiliSecondCof; //Change unit (s -> ms)
                                                    //Update locus and waveform (Draw again)
                UpdateXYZLocus();
            }
        }
        private void UpdateViewerSyncPictureBox()
        {
            if ((extractedFrameImage == null) || (extractedFrameImage.Count() == 0))
            {
                return;
            }
            RemoveCurrentImage();
            if( currentFrameIndex == numberOfFrame)
            {
                currentFrameIndex--;
            }
            Image img = Image.FromFile(extractedFrameImage[currentFrameIndex]);
            labelCurrentFramePicturebox.Text = "Current frame number :" + currentFrameIndex.ToString();
            pictureBoxFrameByFrame.Image = img;

            labelCurrentFramePicturebox.Text = "Current frame: " + currentFrameIndex.ToString();
            timeStamp = currentFrameIndex * 1.0 / cameraFrameRate;
            timeStamp *= GlobalVariable.SecondToMiliSecondCof; //Change unit (s -> ms)
                                                //Update locus and waveform (Draw again)
        }
        private void ExtractVideoToFrameImages()
        {
            // Create instance of video reader
            VideoFileReader reader = new VideoFileReader();
            // Open video file
            reader.Open(videoFilePath);
            var imgFilePath = Path.GetDirectoryName(videoFilePath);            
            imgFilePath += @"\Image";

            if (Directory.Exists(imgFilePath) == true)
            {
                RemoveCurrentImage();
                Directory.Delete(imgFilePath, true);
            }
            Directory.CreateDirectory(imgFilePath);
            imgFilePath += @"\";
            extractedFrameImage = new string[numberOfFrame];
            // read video frames out of it
            try
            {
                this.Enabled = false;
                progressBar.Enabled = true;
                progressBar.Visible = true;
                labelOperatingProgress.Visible = true;
                labelOperatingProgress.Enabled = true;

                for (int idx = 0; idx < numberOfFrame; idx++)
                {
                    var percentage = (100 * idx) / numberOfFrame;
                    progressBar.Value = percentage;
                    Bitmap videoFrame = reader.ReadVideoFrame();
                    var imgRealPath = imgFilePath + idx.ToString() + ".bmp";
                    videoFrame.Save(imgRealPath);
                    // dispose the frame when it is no longer required
                    videoFrame.Dispose();
                    extractedFrameImage[idx] = imgRealPath;
                }
                reader.Close();
            }
            catch
            {
                MessageBox.Show("Can not extract images from video!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                progressBar.Visible = false;
                this.Enabled = true;
                labelOperatingProgress.Visible = false;
            }
        }
        private void FrameByFrameProc()
        {
            tableLayoutPanelPictureBox.Visible = true;
            tableLayoutPanelVideo.Visible = false;
            currentFrameIndex++;
            trackBarPictureBox.Value = currentFrameIndex;
            UpdateViewerSyncPictureBox();
            UpdateXYZLocus();
        }
        private void RemoveCurrentImage()
        {
            Image img = pictureBoxFrameByFrame.Image;
            if (img != null)
            {
                img.Dispose();
                pictureBoxFrameByFrame.Image = null;
            }
        }
        private void GetImageData()
        {
            var imgFilePath = Path.GetDirectoryName(videoFilePath);
            imgFilePath += @"\Image\";
            // read video frames out of it
            try
            {
                this.Enabled = false;
                progressBar.Enabled = true;
                progressBar.Visible = true;
                labelOperatingProgress.Visible = true;
                labelOperatingProgress.Enabled = true;
                extractedFrameImage = new string[numberOfFrame];

                for (int idx = 0; idx < numberOfFrame; idx++)
                {
                    var percentage = (100 * idx) / numberOfFrame;
                    progressBar.Value = percentage;
                    var imgRealPath = imgFilePath + idx.ToString() + ".bmp";
                    if(File.Exists(imgRealPath) == false)
                    {
                        MessageBox.Show("Images data have not found!!! please extract image again!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        toolStripButtonExtractVideo.Enabled = true;
                        tableLayoutPanelVideo.Enabled = true;
                        return;
                    }
                    extractedFrameImage[idx] = imgRealPath;
                }
                ResetFrameViewer();
                tableLayoutPanelVideo.Enabled = true;
            }
            catch
            {
                MessageBox.Show("Images data have problem, please extract image again!", "ERROR", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                progressBar.Visible = false;
                this.Enabled = true;
                labelOperatingProgress.Visible = false;
            }
        }
        #endregion

        private void toolStripButtonExtractVideo_Click(object sender, EventArgs e)
        {
            ExtractVideoToFrameImages();
            ResetFrameViewer();
        }
    }
}
